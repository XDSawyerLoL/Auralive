import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';

import { isGuaranteedFreeOpenRouterModel, isTrustedOpenRouterEndpoint } from '../src/free_federation.js';

function run(script, env = {}) {
  return spawnSync(process.execPath, ['--input-type=module', '-e', script], {
    cwd: new URL('..', import.meta.url).pathname,
    encoding: 'utf8',
    env: {
      ...process.env,
      DB_HOST: '',
      DB_USER: '',
      DB_PASSWORD: '',
      DB_NAME: '',
      DATABASE_URL: '',
      MYSQL_URL: '',
      ...env,
    },
  });
}

test('OpenRouter zero-cost allowlist accepts only intrinsically free model IDs', () => {
  assert.equal(isGuaranteedFreeOpenRouterModel('openrouter/free'), true);
  assert.equal(isGuaranteedFreeOpenRouterModel('nvidia/example:free'), true);
  assert.equal(isGuaranteedFreeOpenRouterModel('anthropic/claude-sonnet'), false);
  assert.equal(isGuaranteedFreeOpenRouterModel('openai/gpt-oss-120b'), false);
  assert.equal(isGuaranteedFreeOpenRouterModel(''), false);
  assert.equal(isTrustedOpenRouterEndpoint('https://openrouter.ai/api/v1'), true);
  assert.equal(isTrustedOpenRouterEndpoint('https://openrouter.ai/api/v1/'), true);
  assert.equal(isTrustedOpenRouterEndpoint('https://example.com/api/v1'), false);
  assert.equal(isTrustedOpenRouterEndpoint('http://openrouter.ai/api/v1'), false);
});

test('AURA zero-cost federation can answer while AI_MODE stays off', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_OPENROUTER_API_KEY='test-free-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';
    process.env.AURA_FREE_FEDERATION_MAX_REQUESTS_PER_DAY='45';

    let request=null;
    global.fetch=async(url, options={})=>{
      request={
        url:String(url),
        auth:String(options.headers?.Authorization || ''),
        body:JSON.parse(String(options.body || '{}')),
      };
      return new Response(JSON.stringify({
        id:'gen-test',
        model:'nvidia/nemotron-free-test',
        choices:[{message:{role:'assistant',content:'réponse gratuite'}}],
        usage:{prompt_tokens:12,completion_tokens:7,cost:0},
      }), {status:200,headers:{'content-type':'application/json'}});
    };

    const { AiClient }=await import('./src/ai.js');
    const ai=new AiClient(null);
    const answer=await ai.generate('question','system',128,'reasoning');
    console.log(JSON.stringify({answer,request,diag:ai.diagnostic()}));
  `;
  const result = run(script);
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(payload.answer, 'réponse gratuite');
  assert.equal(payload.request.url, 'https://openrouter.ai/api/v1/chat/completions');
  assert.equal(payload.request.body.model, 'openrouter/free');
  assert.equal(payload.diag.provider, 'zero-cost-federation');
  assert.equal(payload.diag.zero_cost_mode, true);
  assert.equal(payload.diag.free_federation.financial_guard, 'live-zero-price-proof+intrinsically-free-router');
  assert.match(payload.diag.last_backend, /^zero-cost:openrouter:/);
  assert.doesNotMatch(JSON.stringify(payload.diag), /test-free-key/);
});

test('AURA refuses a non-free OpenRouter model before any network call', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_OPENROUTER_API_KEY='test-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openai/gpt-oss-120b';
    global.fetch=async()=>{ throw new Error('NETWORK_MUST_NOT_RUN'); };
    const { AiClient }=await import('./src/ai.js');
    const ai=new AiClient(null);
    const answer=await ai.generate('question','system',64,'reasoning');
    console.log(JSON.stringify({enabled:ai.enabled,answer,diag:ai.diagnostic()}));
  `;
  const result = run(script);
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(payload.enabled, false);
  assert.equal(payload.answer, '');
  assert.deepEqual(payload.diag.free_federation.configured_models, []);
  assert.deepEqual(payload.diag.free_federation.rejected_models, ['openai/gpt-oss-120b']);
});

test('reported non-zero inference cost quarantines the free provider and never falls through to paid AI', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_OPENROUTER_API_KEY='test-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';
    global.fetch=async()=>new Response(JSON.stringify({
      model:'unexpected-model',
      choices:[{message:{content:'must be discarded'}}],
      usage:{cost:0.001},
    }), {status:200,headers:{'content-type':'application/json'}});
    const { AiClient }=await import('./src/ai.js');
    const ai=new AiClient(null);
    const answer=await ai.generate('question','system',64,'reasoning');
    console.log(JSON.stringify({answer,diag:ai.diagnostic()}));
  `;
  const result = run(script);
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(payload.answer, '');
  assert.deepEqual(payload.diag.free_federation.quarantined, ['openrouter']);
  assert.match(payload.diag.free_federation.last_error, /ZERO_COST_INVARIANT_VIOLATION/);
  assert.equal(payload.diag.last_backend, 'zero-cost-federation-unavailable');
});


test('live catalog routing ignores a :free label when current prices are not zero', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='true';
    process.env.AURA_OPENROUTER_API_KEY='test-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';

    let selected='';
    global.fetch=async(url, options={})=>{
      if (String(url).endsWith('/models')) {
        return new Response(JSON.stringify({data:[
          {
            id:'example/coder:free',
            name:'Example Coder',
            description:'coding software terminal agentic model',
            context_length:262144,
            architecture:{output_modalities:['text']},
            pricing:{prompt:'0',completion:'0'},
            supported_parameters:['tools','max_tokens']
          },
          {
            id:'example/fake-free:free',
            name:'Fake Free',
            description:'coding model',
            context_length:1000000,
            architecture:{output_modalities:['text']},
            pricing:{prompt:'0.0001',completion:'0.0002'},
            supported_parameters:['tools']
          },
          {
            id:'openrouter/free',
            name:'Free Models Router',
            description:'free router',
            context_length:200000,
            architecture:{output_modalities:['text']},
            pricing:{prompt:'0',completion:'0'},
            supported_parameters:['tools']
          }
        ]}), {status:200,headers:{'content-type':'application/json'}});
      }
      const body=JSON.parse(String(options.body || '{}'));
      selected=body.model;
      return new Response(JSON.stringify({
        model:selected,
        choices:[{message:{content:'catalogue ok'}}],
        usage:{cost:0},
      }), {status:200,headers:{'content-type':'application/json'}});
    };

    const { AiClient }=await import('./src/ai.js');
    const ai=new AiClient(null);
    const answer=await ai.generate('écris du code','system',128,'code');
    console.log(JSON.stringify({answer,selected,diag:ai.diagnostic()}));
  `;
  const result = run(script);
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(payload.answer, 'catalogue ok');
  assert.equal(payload.selected, 'example/coder:free');
  assert.notEqual(payload.selected, 'example/fake-free:free');
  assert.equal(payload.diag.free_federation.verified_catalog_models, 2);
});


test('AURA reserves free calls for chat, not just autonomous agents', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='false';
    process.env.AURA_OPENROUTER_API_KEY='mock-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';
    process.env.AURA_FREE_FEDERATION_MAX_REQUESTS_PER_DAY='4';
    process.env.AURA_FREE_FEDERATION_CHAT_RESERVE='3';
    let calls=0;
    global.fetch=async()=>{
      calls++;
      return new Response(JSON.stringify({
        model:'openrouter/free',choices:[{message:{content:'Français naturel'}}],usage:{cost:0},
      }),{status:200});
    };
    const { ZeroCostFederation }=await import('./src/free_federation.js');
    const federation=new ZeroCostFederation();
    const first=await federation.generate('recherche','system',120,'research');
    let rejected=false;
    try { await federation.generate('autre recherche','system',120,'research'); }
    catch (error) { rejected=/reserved for conversation/.test(error.message); }
    const human=await federation.generate('salut','system',120,'french');
    console.log(JSON.stringify({calls,first:first?.answer,human:human?.answer,rejected,
      stats:federation.snapshot()}));
  `;
  const result=run(script);
  assert.equal(result.status,0,result.stderr||result.stdout);
  const out=JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(out.calls,2);
  assert.equal(out.rejected,true);
  assert.equal(out.human,'Français naturel');
  assert.equal(out.stats.chat_reserved_requests,3);
  assert.equal(out.stats.background_request_limit,1);
});

test('HTTP 429 temporarily halts free provider retries', () => {
  const script = `
    process.env.AURA_ZERO_COST_MODE='true';
    process.env.AI_MODE='off';
    process.env.AURA_FREE_FEDERATION_ENABLED='true';
    process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='false';
    process.env.AURA_OPENROUTER_API_KEY='mock-key';
    process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';
    let calls=0;
    global.fetch=async()=>{calls++;return new Response('Rate limit exceeded',
      {status:429,headers:{'retry-after':'90'}});};
    const { ZeroCostFederation }=await import('./src/free_federation.js');
    const federation=new ZeroCostFederation();
    let first='',second='';
    try { await federation.generate('salut','system',120,'french'); } catch(e) { first=e.message; }
    try { await federation.generate('bonjour','system',120,'french'); } catch(e) { second=e.message; }
    console.log(JSON.stringify({calls,first,second,cooldown:federation.snapshot().cooldown_until}));
  `;
  const result=run(script);
  assert.equal(result.status,0,result.stderr||result.stdout);
  const out=JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(out.calls,1);
  assert.match(out.first,/HTTP 429/);
  assert.match(out.second,/cooldown active/);
  assert.ok(Date.parse(out.cooldown)>Date.now());
});

test('startup does not waste nine free requests on the language benchmark', async () => {
  const { readFileSync }=await import('node:fs');
  const server=readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
  assert.doesNotMatch(server,/setImmediate\(\(\) => \{ void kernel\.language\.evaluate/);
  assert.match(server,/post\('\/api\/language\/evaluate'/);
});


test('French free routing avoids mandatory hidden-reasoning models when verified text models exist',()=>{
  const script=[
    "process.env.AURA_ZERO_COST_MODE='true';",
    "process.env.AI_MODE='off';",
    "process.env.AURA_FREE_FEDERATION_ENABLED='true';",
    "process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='true';",
    "process.env.AURA_OPENROUTER_API_KEY='fake-free-key';",
    "process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';",
    "let requested=null;",
    "global.fetch=async(url,opts={})=>{",
    "  if(String(url).endsWith('/models')) return new Response(JSON.stringify({data:[",
    "    {id:'trial/mandatory:free',name:'Multilingual French conversation Qwen reasoning',context_length:128000,pricing:{prompt:'0',completion:'0'},architecture:{output_modalities:['text']},reasoning:{mandatory:true,supported_efforts:['minimal']}},",
    "    {id:'trial/regular:free',name:'Plain instruction model',context_length:32000,pricing:{prompt:'0',completion:'0'},architecture:{output_modalities:['text']},reasoning:{mandatory:false,supported_efforts:['none']}},",
    "  ]}),{status:200});",
    "  requested=JSON.parse(opts.body);",
    "  return new Response(JSON.stringify({model:requested.model,choices:[{message:{content:'Bonjour, je vous réponds.'}}],usage:{cost:0,completion_tokens:16}}),{status:200});",
    "};",
    "const {ZeroCostFederation}=await import('./src/free_federation.js');",
    "const result=await new ZeroCostFederation().generate('Bonjour','Réponds en français',650,'french');",
    "console.log(JSON.stringify({requested,result}));",
  ].join('\n');
  const result=run(script);
  assert.equal(result.status,0,result.stderr||result.stdout);
  const payload=JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(payload.requested.model,'trial/regular:free');
  assert.equal(payload.requested.reasoning.effort,'none');
  assert.ok(payload.requested.max_tokens>=900);
  assert.match(payload.result.answer,/Bonjour/);
  assert.equal(payload.result.costMicrounits,0);
});


test('empty OpenRouter free router reply recovers with a verified free chat model', () => {
  const script = [
    "process.env.AURA_ZERO_COST_MODE='true';",
    "process.env.AI_MODE='off';",
    "process.env.AURA_FREE_FEDERATION_ENABLED='true';",
    "process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='true';",
    "process.env.AURA_OPENROUTER_API_KEY='mock-key';",
    "process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';",
    "let catalogs=0; const called=[];",
    "global.fetch=async(url,opts={})=>{",
    "  if(String(url).endsWith('/models')) {",
    "    catalogs++;",
    "    const data=catalogs===1 ? [] : [",
    "      {id:'trial/conversation:free',name:'French multilingual conversation',context_length:32000,pricing:{prompt:'0',completion:'0'},architecture:{output_modalities:['text']},reasoning:{mandatory:false}},",
    "      {id:'trial/paid:free',name:'French multilingual conversation',context_length:200000,pricing:{prompt:'0.001',completion:'0'},architecture:{output_modalities:['text']}},",
    "    ];",
    "    return new Response(JSON.stringify({data}),{status:200});",
    "  }",
    "  const body=JSON.parse(opts.body);called.push(body.model);",
    "  if(body.model==='openrouter/free') return new Response(JSON.stringify({",
    "    model:'trial/reasoning:free',choices:[{finish_reason:'length',message:{content:null,reasoning:'not visible'}}],",
    "    usage:{cost:0,completion_tokens:900,completion_tokens_details:{reasoning_tokens:900}}",
    "  }),{status:200});",
    "  return new Response(JSON.stringify({model:body.model,choices:[{message:{content:'Bonjour, je peux vous répondre en français.'}}],usage:{cost:0,completion_tokens:20}}),{status:200});",
    "};",
    "const {ZeroCostFederation}=await import('./src/free_federation.js');",
    "const federation=new ZeroCostFederation();",
    "const result=await federation.generate('lu','Tu réponds naturellement',700,'french');",
    "console.log(JSON.stringify({result,called,status:federation.snapshot()}));",
  ].join('\n');
  const completed=run(script);
  assert.equal(completed.status,0,completed.stderr||completed.stdout);
  const data=JSON.parse(completed.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(data.result.answer,'Bonjour, je peux vous répondre en français.');
  assert.deepEqual(data.called,['openrouter/free','trial/conversation:free']);
  assert.equal(data.status.process_requests_today,2);
  assert.match(data.status.last_error,/free model fallback:/);
  assert.equal(data.result.costMicrounits,0);
});

test('OpenRouter authentication errors do not trigger a chargeable or repeated request', () => {
  const script = [
    "process.env.AURA_ZERO_COST_MODE='true';",
    "process.env.AI_MODE='off';",
    "process.env.AURA_FREE_FEDERATION_ENABLED='true';",
    "process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='false';",
    "process.env.AURA_OPENROUTER_API_KEY='invalid-key';",
    "process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';",
    "let calls=0;",
    "global.fetch=async()=>{calls++;return new Response('invalid_api_key',{status:401});};",
    "const {ZeroCostFederation}=await import('./src/free_federation.js');",
    "const federation=new ZeroCostFederation();",
    "let error='';try{await federation.generate('lu','Réponds en français',700,'french');}catch(e){error=e.message;}",
    "console.log(JSON.stringify({calls,error,status:federation.snapshot()}));",
  ].join('\n');
  const completed=run(script);
  assert.equal(completed.status,0,completed.stderr||completed.stdout);
  const data=JSON.parse(completed.stdout.trim().split(/\r?\n/).at(-1));
  assert.equal(data.calls,1);
  assert.match(data.error,/HTTP 401/);
  assert.equal(data.status.process_requests_today,1);
});


test('OpenRouter refuses retries on HTTP 401, 402, 403, 429 even if a free fallback exists', () => {
  for (const status of [401, 402, 403, 429]) {
    const script = [
      "process.env.AURA_ZERO_COST_MODE='true';",
      "process.env.AI_MODE='off';",
      "process.env.AURA_FREE_FEDERATION_ENABLED='true';",
      "process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='false';",
      "process.env.AURA_OPENROUTER_API_KEY='mock-key';",
      "process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';",
      "let calls=0;",
      "global.fetch=async()=>{calls++;return new Response('quota or access rejected',{status:"+status+"});};",
      "const {ZeroCostFederation}=await import('./src/free_federation.js');",
      "const fed=new ZeroCostFederation();",
      "let error='';try{await fed.generate('Bonjour','Réponds',700,'french');}catch(e){error=e.message;}",
      "console.log(JSON.stringify({calls,error,usage:fed.snapshot().process_requests_today}));",
    ].join('\n');
    const completed=run(script);
    assert.equal(completed.status,0,completed.stderr||completed.stdout);
    const actual=JSON.parse(completed.stdout.trim().split(/\r?\n/).at(-1));
    assert.equal(actual.calls,1,'HTTP '+status+' must not repeat inference');
    assert.equal(actual.usage,1);
    assert.match(actual.error,new RegExp('HTTP '+status));
  }
});

test('OpenRouter quota/credit error inside HTTP 200 is terminal, never an empty-response retry', () => {
  for(const upstream of [
    {code:402,message:'Insufficient credits'}, {code:429,message:'quota_exceeded'},
    {code:400,message:'billing account required'},
  ]) {
    const script=[
      "process.env.AURA_ZERO_COST_MODE='true';",
      "process.env.AI_MODE='off';",
      "process.env.AURA_FREE_FEDERATION_ENABLED='true';",
      "process.env.AURA_FREE_FEDERATION_DISCOVER_MODELS='false';",
      "process.env.AURA_OPENROUTER_API_KEY='mock-key';",
      "process.env.AURA_OPENROUTER_FREE_MODELS='openrouter/free';",
      "let calls=0;",
      "global.fetch=async()=>{calls++;return new Response(JSON.stringify({error:"+JSON.stringify(upstream)+"}),{status:200});};",
      "const {ZeroCostFederation}=await import('./src/free_federation.js');",
      "const fed=new ZeroCostFederation();",
      "let error='';try{await fed.generate('Bonjour','Réponds',700,'french');}catch(e){error=e.message;}",
      "console.log(JSON.stringify({calls,error,usage:fed.snapshot().process_requests_today}));",
    ].join('\n');
    const completed=run(script);
    assert.equal(completed.status,0,completed.stderr||completed.stdout);
    const actual=JSON.parse(completed.stdout.trim().split(/\r?\n/).at(-1));
    assert.equal(actual.calls,1,'terminal upstream error must never retry');
    assert.match(actual.error,/OpenRouter free/);
    assert.doesNotMatch(actual.error,/free fallback/);
  }
});

test('terminal-error classifier blocks quota, billing and authorization but not empty text', async () => {
  const {isTerminalFreeProviderFailure}=await import('../src/free_federation.js');
  for(const value of ['HTTP 401','HTTP 402','HTTP 403','HTTP 429',
    'insufficient_quota','rate_limit_exceeded','budget exhausted',
    'billing account required','invalid_api_key','negative balance']) {
    assert.equal(isTerminalFreeProviderFailure(value),true,value);
  }
  assert.equal(isTerminalFreeProviderFailure('OpenRouter free response empty: model=openrouter/free'),false);
});
