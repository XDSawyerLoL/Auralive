import { randomUUID } from 'node:crypto';
import mysql from 'mysql2/promise';
import { config } from './config.js';

let pool;

export const LATEST_SCHEMA_VERSION = 18;

export function getDb() {
  if (pool) return pool;
  pool = config.dbUrl
    ? mysql.createPool({ uri: config.dbUrl, connectionLimit: config.dbConnectionLimit, connectTimeout: config.dbConnectTimeoutMs, charset: 'utf8mb4' })
    : mysql.createPool({
        host: config.dbHost,
        port: config.dbPort,
        user: config.dbUser,
        password: config.dbPassword,
        database: config.dbName,
        connectionLimit: config.dbConnectionLimit,
        connectTimeout: config.dbConnectTimeoutMs,
        charset: 'utf8mb4',
        timezone: 'Z',
      });
  return pool;
}

export async function query(sql, params = []) {
  const [rows] = await getDb().execute(sql, params);
  return rows;
}

export async function one(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

export async function closeDb() {
  if (pool) {
    await pool.end();
    pool = undefined;
  }
}

async function ensureMigrationTable(db) {
  await db.query(`CREATE TABLE IF NOT EXISTS aura_schema_migrations (
    version INT PRIMARY KEY,
    name VARCHAR(240) NOT NULL,
    applied_at VARCHAR(40) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
}

async function ensureColumn(db, table, column, definition) {
  const [rows] = await db.query(`SHOW COLUMNS FROM \`${table}\` LIKE ?`, [column]);
  if (!rows.length) {
    await db.query(`ALTER TABLE \`${table}\` ADD COLUMN ${definition}`);
  }
}

async function ensureIndex(db, table, indexName, definition) {
  const [rows] = await db.query(`SHOW INDEX FROM \`${table}\` WHERE Key_name=?`, [indexName]);
  if (!rows.length) {
    await db.query(`ALTER TABLE \`${table}\` ADD INDEX ${definition}`);
  }
}

async function applyMigrations(db) {
  await ensureMigrationTable(db);
  const [rows] = await db.query('SELECT COALESCE(MAX(version), 0) AS version FROM aura_schema_migrations');
  let current = Number(rows?.[0]?.version || 0);

  if (current < 1) {
    await db.query(
      'INSERT IGNORE INTO aura_schema_migrations(version,name,applied_at) VALUES(1,?,?)',
      ['baseline-cloud-schema', new Date().toISOString()],
    );
    current = 1;
  }

  if (current < 2) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_state_snapshots (
      id CHAR(36) PRIMARY KEY,
      reason VARCHAR(120) NOT NULL,
      schema_version INT NOT NULL,
      payload LONGTEXT NOT NULL,
      payload_bytes BIGINT NOT NULL DEFAULT 0,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_state_snapshots_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_runtime_metric_rollups (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      payload LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_metric_rollups_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(2,?,?)',
      ['resilience-snapshots-and-metrics', new Date().toISOString()],
    );
    current = 2;
  }

  if (current < 3) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_command_services (
      id VARCHAR(80) PRIMARY KEY,
      name VARCHAR(160) NOT NULL,
      kind VARCHAR(80) NOT NULL DEFAULT 'service',
      objective TEXT NOT NULL,
      endpoint VARCHAR(1000) NOT NULL DEFAULT '',
      repository VARCHAR(300) NOT NULL DEFAULT '',
      criticality DOUBLE NOT NULL DEFAULT 0.5,
      enabled TINYINT NOT NULL DEFAULT 1,
      state VARCHAR(40) NOT NULL DEFAULT 'unknown',
      state_detail TEXT NOT NULL,
      last_observed_at VARCHAR(40) NOT NULL DEFAULT '',
      metadata LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_command_services_state(state,criticality)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_initiatives (
      id CHAR(36) PRIMARY KEY,
      fingerprint VARCHAR(64) NOT NULL,
      domain VARCHAR(80) NOT NULL,
      kind VARCHAR(40) NOT NULL,
      title VARCHAR(240) NOT NULL,
      objective TEXT NOT NULL,
      rationale TEXT NOT NULL,
      priority DOUBLE NOT NULL DEFAULT 0.5,
      confidence DOUBLE NOT NULL DEFAULT 0.5,
      requested_risks LONGTEXT NOT NULL,
      action_type VARCHAR(120) NOT NULL DEFAULT '',
      action_payload LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'queued',
      execution_mode VARCHAR(80) NOT NULL DEFAULT '',
      result LONGTEXT NOT NULL,
      error TEXT NOT NULL,
      attempts INT NOT NULL DEFAULT 0,
      last_attempt_at VARCHAR(40) NOT NULL DEFAULT '',
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_initiatives_status(status,priority,updated_at),
      INDEX idx_aura_initiatives_fingerprint(fingerprint,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_command_events (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      initiative_id CHAR(36) NULL,
      kind VARCHAR(80) NOT NULL,
      payload LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_command_events_initiative(initiative_id,created_at),
      INDEX idx_aura_command_events_kind(kind,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(3,?,?)',
      ['autonomous-command-center', new Date().toISOString()],
    );
    current = 3;
  }

  if (current < 4) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_external_memory (
      id VARCHAR(40) PRIMARY KEY,
      query_text TEXT NOT NULL,
      url VARCHAR(1800) NOT NULL,
      host VARCHAR(300) NOT NULL,
      title VARCHAR(500) NOT NULL DEFAULT '',
      excerpt LONGTEXT NOT NULL,
      content_hash VARCHAR(64) NOT NULL,
      source_quality DOUBLE NOT NULL DEFAULT 0.5,
      published_at VARCHAR(80) NOT NULL DEFAULT '',
      fetched_at VARCHAR(40) NOT NULL,
      expires_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_external_memory_host(host,fetched_at),
      INDEX idx_aura_external_memory_expiry(expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_reasoning_sessions (
      id CHAR(36) PRIMARY KEY,
      trigger_name VARCHAR(120) NOT NULL,
      question TEXT NOT NULL,
      hypotheses LONGTEXT NOT NULL,
      plan LONGTEXT NOT NULL,
      conclusion LONGTEXT NOT NULL,
      confidence DOUBLE NOT NULL DEFAULT 0,
      epistemic_status VARCHAR(40) NOT NULL DEFAULT 'unverified',
      evidence_count INT NOT NULL DEFAULT 0,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_reasoning_status(epistemic_status,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_reasoning_evidence (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      session_id CHAR(36) NOT NULL,
      source_url VARCHAR(1800) NOT NULL,
      source_title VARCHAR(500) NOT NULL DEFAULT '',
      source_host VARCHAR(300) NOT NULL DEFAULT '',
      stance VARCHAR(40) NOT NULL DEFAULT 'neutral',
      relevance DOUBLE NOT NULL DEFAULT 0,
      reliability DOUBLE NOT NULL DEFAULT 0,
      excerpt LONGTEXT NOT NULL,
      notes TEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_reasoning_evidence_session(session_id,created_at),
      INDEX idx_aura_reasoning_evidence_host(source_host,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(4,?,?)',
      ['web-substrate-external-memory-and-evidence', new Date().toISOString()],
    );
    current = 4;
  }

  if (current < 5) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_fabric_capabilities (
      id VARCHAR(180) PRIMARY KEY,
      manifest LONGTEXT NOT NULL,
      manifest_hash VARCHAR(64) NOT NULL,
      transport VARCHAR(80) NOT NULL,
      provider VARCHAR(180) NOT NULL DEFAULT '',
      trust DOUBLE NOT NULL DEFAULT 0.5,
      observed_reliability DOUBLE NOT NULL DEFAULT 0.5,
      latency_ms DOUBLE NOT NULL DEFAULT 0,
      cost_microunits BIGINT NOT NULL DEFAULT 0,
      side_effects TINYINT NOT NULL DEFAULT 0,
      last_seen_at VARCHAR(40) NOT NULL DEFAULT '',
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_fabric_caps_transport(transport,provider),
      INDEX idx_aura_fabric_caps_quality(observed_reliability,trust)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_fabric_graphs (
      id VARCHAR(120) PRIMARY KEY,
      objective TEXT NOT NULL,
      graph LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'planned',
      result LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_fabric_graphs_status(status,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_fabric_node_runs (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      graph_id VARCHAR(120) NOT NULL,
      node_id VARCHAR(120) NOT NULL,
      capability_id VARCHAR(180) NOT NULL,
      ok TINYINT NOT NULL,
      elapsed_ms BIGINT NOT NULL DEFAULT 0,
      result LONGTEXT NOT NULL,
      error TEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_fabric_node_graph(graph_id,created_at),
      INDEX idx_aura_fabric_node_capability(capability_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(5,?,?)',
      ['capability-fabric-routing-and-graph-ledger', new Date().toISOString()],
    );
    current = 5;
  }

  if (current < 6) {
    await ensureColumn(
      db,
      'aura_execution_jobs',
      'target_worker_id',
      "target_worker_id VARCHAR(160) NOT NULL DEFAULT '' AFTER requested_risks",
    );
    await ensureColumn(
      db,
      'aura_execution_jobs',
      'required_capabilities',
      "required_capabilities LONGTEXT NULL AFTER target_worker_id",
    );
    await ensureColumn(
      db,
      'aura_execution_jobs',
      'verification_mode',
      "verification_mode VARCHAR(40) NOT NULL DEFAULT 'none' AFTER required_capabilities",
    );
    await ensureColumn(
      db,
      'aura_execution_jobs',
      'quorum',
      "quorum INT NOT NULL DEFAULT 1 AFTER verification_mode",
    );
    await ensureColumn(
      db,
      'aura_execution_jobs',
      'assigned_at',
      "assigned_at BIGINT NOT NULL DEFAULT 0 AFTER lease_until",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'compute_consent',
      "compute_consent TINYINT NOT NULL DEFAULT 0 AFTER version",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'mesh_capabilities',
      "mesh_capabilities LONGTEXT NULL AFTER compute_consent",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'resources',
      "resources LONGTEXT NULL AFTER mesh_capabilities",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'reputation',
      "reputation DOUBLE NOT NULL DEFAULT 0.5 AFTER resources",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'jobs_completed',
      "jobs_completed BIGINT NOT NULL DEFAULT 0 AFTER reputation",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'jobs_failed',
      "jobs_failed BIGINT NOT NULL DEFAULT 0 AFTER jobs_completed",
    );
    await ensureColumn(
      db,
      'aura_execution_workers',
      'avg_latency_ms',
      "avg_latency_ms DOUBLE NOT NULL DEFAULT 0 AFTER jobs_failed",
    );
    await ensureIndex(
      db,
      'aura_execution_jobs',
      'idx_aura_execution_jobs_target',
      'idx_aura_execution_jobs_target(target_worker_id,status,created_at)',
    );
    await ensureIndex(
      db,
      'aura_execution_workers',
      'idx_aura_execution_workers_mesh',
      'idx_aura_execution_workers_mesh(compute_consent,reputation,last_seen_ms)',
    );
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(6,?,?)',
      ['compute-mesh-worker-routing-and-reputation', new Date().toISOString()],
    );
    current = 6;
  }

  if (current < 7) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_mesh_peers (
      peer_id VARCHAR(80) PRIMARY KEY,
      worker_id VARCHAR(160) NOT NULL,
      public_jwk LONGTEXT NOT NULL,
      capabilities LONGTEXT NOT NULL,
      resources LONGTEXT NOT NULL,
      reputation DOUBLE NOT NULL DEFAULT 0.5,
      enabled TINYINT NOT NULL DEFAULT 1,
      last_seen_at VARCHAR(40) NOT NULL,
      last_seen_ms BIGINT NOT NULL DEFAULT 0,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_mesh_peers_seen(enabled,last_seen_ms),
      INDEX idx_aura_mesh_peers_worker(worker_id,last_seen_ms),
      INDEX idx_aura_mesh_peers_reputation(reputation,last_seen_ms)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_mesh_signals (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      session_id VARCHAR(80) NOT NULL,
      from_peer_id VARCHAR(80) NOT NULL,
      to_peer_id VARCHAR(80) NOT NULL,
      signal_type VARCHAR(40) NOT NULL,
      payload LONGTEXT NOT NULL,
      signature LONGTEXT NOT NULL,
      nonce VARCHAR(100) NOT NULL UNIQUE,
      created_at VARCHAR(40) NOT NULL,
      created_ms BIGINT NOT NULL DEFAULT 0,
      consumed TINYINT NOT NULL DEFAULT 0,
      INDEX idx_aura_mesh_signals_target(to_peer_id,id),
      INDEX idx_aura_mesh_signals_session(session_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_mesh_sessions (
      id CHAR(36) PRIMARY KEY,
      capability VARCHAR(80) NOT NULL,
      initiator_peer_id VARCHAR(80) NOT NULL,
      target_peer_id VARCHAR(80) NOT NULL,
      task LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'negotiating',
      result LONGTEXT NOT NULL,
      error TEXT NOT NULL,
      verification LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_mesh_sessions_status(status,updated_at),
      INDEX idx_aura_mesh_sessions_peers(initiator_peer_id,target_peer_id,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(7,?,?)',
      ['peer-mesh-webrtc-signaling-and-cryptographic-identity', new Date().toISOString()],
    );
    current = 7;
  }

  if (current < 8) {
    await ensureColumn(
      db,
      'aura_mesh_peers',
      'jobs_completed',
      "jobs_completed BIGINT NOT NULL DEFAULT 0 AFTER reputation",
    );
    await ensureColumn(
      db,
      'aura_mesh_peers',
      'jobs_failed',
      "jobs_failed BIGINT NOT NULL DEFAULT 0 AFTER jobs_completed",
    );
    await ensureColumn(
      db,
      'aura_mesh_peers',
      'avg_latency_ms',
      "avg_latency_ms DOUBLE NOT NULL DEFAULT 0 AFTER jobs_failed",
    );
    await ensureColumn(
      db,
      'aura_mesh_sessions',
      'started_ms',
      "started_ms BIGINT NOT NULL DEFAULT 0 AFTER status",
    );
    await ensureIndex(
      db,
      'aura_mesh_peers',
      'idx_aura_mesh_peers_quality',
      'idx_aura_mesh_peers_quality(enabled,reputation,avg_latency_ms,last_seen_ms)',
    );
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(8,?,?)',
      ['peer-mesh-quorum-replay-protection-and-quality-routing', new Date().toISOString()],
    );
    current = 8;
  }

  if (current < 9) {
    const [productRows] = await db.query(
      "SELECT id,state,state_detail,last_observed_at,metadata FROM aura_command_services WHERE id IN ('glide','quantic-glide')",
    );
    const legacy = productRows.find((row) => row.id === 'glide');
    const canonical = productRows.find((row) => row.id === 'quantic-glide');
    if (legacy && !canonical) {
      await db.query(
        "UPDATE aura_command_services SET id='quantic-glide',name='Quantic Glide',updated_at=? WHERE id='glide'",
        [new Date().toISOString()],
      );
    } else if (legacy && canonical) {
      let legacyMetadata = {};
      let canonicalMetadata = {};
      try { legacyMetadata = JSON.parse(legacy.metadata || '{}') || {}; } catch {}
      try { canonicalMetadata = JSON.parse(canonical.metadata || '{}') || {}; } catch {}
      const legacyNewer = String(legacy.last_observed_at || '') > String(canonical.last_observed_at || '');
      const source = legacyNewer ? legacy : canonical;
      await db.query(
        "UPDATE aura_command_services SET state=?,state_detail=?,last_observed_at=?,metadata=?,updated_at=? WHERE id='quantic-glide'",
        [
          source.state || 'unknown',
          source.state_detail || '',
          source.last_observed_at || '',
          JSON.stringify({ ...legacyMetadata, ...canonicalMetadata }),
          new Date().toISOString(),
        ],
      );
      await db.query("DELETE FROM aura_command_services WHERE id='glide'");
    }
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(9,?,?)',
      ['canonical-quantic-glide-product-id', new Date().toISOString()],
    );
    current = 9;
  }

  if (current < 10) {
    await ensureColumn(
      db,
      'aura_cloud_messages',
      'session_id',
      "session_id VARCHAR(96) NOT NULL DEFAULT '' AFTER role",
    );
    await ensureIndex(
      db,
      'aura_cloud_messages',
      'idx_aura_cloud_messages_session',
      'idx_aura_cloud_messages_session(session_id,id)',
    );
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(10,?,?)',
      ['conversation-session-isolation', new Date().toISOString()],
    );
    current = 10;
  }

  if (current < 11) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_free_model_scorecards (
      provider VARCHAR(80) NOT NULL,
      model VARCHAR(240) NOT NULL,
      role VARCHAR(80) NOT NULL,
      calls BIGINT NOT NULL DEFAULT 0,
      successes BIGINT NOT NULL DEFAULT 0,
      failures BIGINT NOT NULL DEFAULT 0,
      ema_latency_ms DOUBLE NOT NULL DEFAULT 0,
      ema_quality DOUBLE NULL,
      last_error TEXT NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      PRIMARY KEY(provider,model,role),
      INDEX idx_aura_free_model_quality(provider,role,successes,calls,ema_latency_ms)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_free_provider_usage (
      provider VARCHAR(80) NOT NULL,
      usage_date VARCHAR(10) NOT NULL,
      requests BIGINT NOT NULL DEFAULT 0,
      failures BIGINT NOT NULL DEFAULT 0,
      last_status VARCHAR(120) NOT NULL DEFAULT '',
      updated_at VARCHAR(40) NOT NULL,
      PRIMARY KEY(provider,usage_date),
      INDEX idx_aura_free_usage_date(usage_date,provider)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(11,?,?)',
      ['zero-cost-cloud-federation-ledger', new Date().toISOString()],
    );
    current = 11;
  }


  if (current < 12) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_missions (
      id CHAR(36) PRIMARY KEY,
      source_intention_id CHAR(36) NOT NULL DEFAULT '',
      title VARCHAR(240) NOT NULL,
      objective LONGTEXT NOT NULL,
      success_criteria LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'planning',
      priority DOUBLE NOT NULL DEFAULT 0.7,
      confidence DOUBLE NOT NULL DEFAULT 0.7,
      plan_version INT NOT NULL DEFAULT 1,
      revision_count INT NOT NULL DEFAULT 0,
      max_revisions INT NOT NULL DEFAULT 4,
      current_step_index INT NOT NULL DEFAULT 0,
      progress DOUBLE NOT NULL DEFAULT 0,
      state LONGTEXT NOT NULL,
      last_error TEXT NOT NULL,
      started_at VARCHAR(40) NOT NULL DEFAULT '',
      completed_at VARCHAR(40) NOT NULL DEFAULT '',
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_missions_status(status,priority,updated_at),
      INDEX idx_aura_missions_intention(source_intention_id,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_mission_steps (
      id CHAR(36) PRIMARY KEY,
      mission_id CHAR(36) NOT NULL,
      position DOUBLE NOT NULL DEFAULT 0,
      plan_version INT NOT NULL DEFAULT 1,
      title VARCHAR(240) NOT NULL,
      objective LONGTEXT NOT NULL,
      kind VARCHAR(40) NOT NULL DEFAULT 'reflection',
      requested_risks LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'pending',
      initiative_id CHAR(36) NOT NULL DEFAULT '',
      attempts INT NOT NULL DEFAULT 0,
      max_attempts INT NOT NULL DEFAULT 2,
      expected_signal TEXT NOT NULL,
      result LONGTEXT NOT NULL,
      critique LONGTEXT NOT NULL,
      started_at VARCHAR(40) NOT NULL DEFAULT '',
      completed_at VARCHAR(40) NOT NULL DEFAULT '',
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_mission_steps_mission(mission_id,plan_version,status,position),
      INDEX idx_aura_mission_steps_initiative(initiative_id,status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(12,?,?)',
      ['long-horizon-persistent-missions', new Date().toISOString()],
    );
    current = 12;
  }

  if (current < 13) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_skills (
      id VARCHAR(80) PRIMARY KEY,
      strategy_key VARCHAR(500) NOT NULL,
      name VARCHAR(180) NOT NULL,
      recipe LONGTEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'candidate',
      successes BIGINT NOT NULL DEFAULT 0,
      failures BIGINT NOT NULL DEFAULT 0,
      context_count INT NOT NULL DEFAULT 0,
      confidence DOUBLE NOT NULL DEFAULT 0,
      source VARCHAR(80) NOT NULL DEFAULT 'outcome',
      first_seen_at VARCHAR(40) NOT NULL,
      last_seen_at VARCHAR(40) NOT NULL,
      promoted_at VARCHAR(40) NOT NULL DEFAULT '',
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_skills_status(status,confidence,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_skill_observations (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      skill_id VARCHAR(80) NOT NULL,
      ok TINYINT NOT NULL,
      context_key VARCHAR(240) NOT NULL,
      evidence LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_skill_obs_skill(skill_id,created_at),
      INDEX idx_aura_skill_obs_context(skill_id,context_key,ok)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(13,?,?)',
      ['cross-context-skill-learning', new Date().toISOString()],
    );
    current = 13;
  }

  if (current < 14) {
    // Atomic, database-clock leases prevent duplicate mission dispatch on
    // horizontally scaled instances. No local machine/paid service required.
    await db.query(`CREATE TABLE IF NOT EXISTS aura_mission_leases (
      mission_id CHAR(36) PRIMARY KEY,
      lease_owner VARCHAR(80) NOT NULL DEFAULT '',
      lease_until DATETIME(6) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_mission_leases_until(lease_until)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(14,?,?)',
      ['atomic-mission-leases', new Date().toISOString()],
    );
    current = 14;
  }

  if (current < 15) {
    // Evidence-linked observations; no generated labels passed off as learning.
    await db.query(`CREATE TABLE IF NOT EXISTS aura_reflex_observations (
      id CHAR(36) PRIMARY KEY,
      decision_id CHAR(36) NOT NULL,
      compute_tier VARCHAR(24) NOT NULL,
      difficulty DOUBLE NOT NULL,
      risk DOUBLE NOT NULL,
      novelty DOUBLE NOT NULL,
      uncertainty DOUBLE NOT NULL,
      outcome_ok TINYINT NOT NULL,
      evidence_level VARCHAR(40) NOT NULL DEFAULT 'reported',
      source VARCHAR(120) NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_reflex_decision(decision_id),
      INDEX idx_aura_reflex_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(15,?,?)',
      ['evidence-linked-reflex-observations', new Date().toISOString()],
    );
    current = 15;
  }

  if (current < 16) {
    await db.query(`CREATE TABLE IF NOT EXISTS aura_agent_runs (
      id CHAR(36) PRIMARY KEY,
      mission_id CHAR(36) NOT NULL DEFAULT '',
      role VARCHAR(32) NOT NULL,
      status VARCHAR(32) NOT NULL,
      task_sha256 CHAR(64) NOT NULL,
      provider VARCHAR(120) NOT NULL DEFAULT '',
      latency_ms BIGINT NOT NULL DEFAULT 0,
      error_code VARCHAR(64) NOT NULL DEFAULT '',
      created_at VARCHAR(40) NOT NULL,
      finished_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_agent_runs_mission(mission_id,created_at),
      INDEX idx_aura_agent_runs_status(status,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT INTO aura_schema_migrations(version,name,applied_at) VALUES(16,?,?)',
      ['persistent-agent-role-runs', new Date().toISOString()],
    );
    current = 16;
  }

  if (current < 17) {
    // Authoritative shared knowledge store: never rely on per-instance Hostinger files.
    await db.query(`CREATE TABLE IF NOT EXISTS aura_knowledge_notes (
      id CHAR(36) PRIMARY KEY,
      namespace VARCHAR(40) NOT NULL DEFAULT 'founder',
      title VARCHAR(240) NOT NULL,
      body LONGTEXT NOT NULL,
      kind VARCHAR(32) NOT NULL DEFAULT 'note',
      project VARCHAR(120) NOT NULL DEFAULT '',
      tags LONGTEXT NOT NULL,
      source VARCHAR(320) NOT NULL DEFAULT 'fondateur:manuel',
      confidence DOUBLE NOT NULL DEFAULT 0.5,
      status VARCHAR(32) NOT NULL DEFAULT 'active',
      version INT NOT NULL DEFAULT 1,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_knowledge_scope(namespace,status,project,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(`CREATE TABLE IF NOT EXISTS aura_knowledge_revisions (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      note_id CHAR(36) NOT NULL,
      version INT NOT NULL,
      event VARCHAR(24) NOT NULL,
      snapshot LONGTEXT NOT NULL,
      changed_at VARCHAR(40) NOT NULL,
      UNIQUE KEY uq_aura_knowledge_revisions_version(note_id,version),
      INDEX idx_aura_knowledge_revisions_note(note_id,changed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.query(
      'INSERT IGNORE INTO aura_schema_migrations(version,name,applied_at) VALUES(17,?,?)',
      ['sourced-versioned-founder-knowledge', new Date().toISOString()],
    );
    current = 17;
  }
  if (current < 18) {
    // Immutable episodes and results are separate: predictions precede the
    // action, outcomes are committed at most once after observation.
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_head ("+
      "id TINYINT PRIMARY KEY, last_hash VARCHAR(64) NOT NULL,"+
      "last_episode_id BIGINT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("INSERT IGNORE INTO aura_history_head(id,last_hash,last_episode_id) VALUES(1,'GENESIS',NULL)");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_episodes ("+
      "id BIGINT AUTO_INCREMENT PRIMARY KEY,ts VARCHAR(40) NOT NULL,"+
      "mission_id VARCHAR(120) NULL,kind VARCHAR(24) NOT NULL,"+
      "context_tag VARCHAR(120) NOT NULL,action VARCHAR(120) NOT NULL,"+
      "prediction TEXT NULL,confidence DOUBLE NULL,prev_hash VARCHAR(64) NOT NULL,"+
      "hash CHAR(64) NOT NULL UNIQUE,ablated TINYINT NOT NULL DEFAULT 0,"+
      "UNIQUE KEY uq_aura_history_prev(prev_hash),"+
      "INDEX idx_aura_history_context(context_tag,ts),"+
      "CONSTRAINT chk_aura_ep_conf CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),"+
      "CONSTRAINT chk_aura_ep_kind CHECK (kind IN ('action','misunderstanding','observation')),"+
      "CONSTRAINT chk_aura_ep_live CHECK (ablated=0)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_outcomes ("+
      "episode_id BIGINT PRIMARY KEY,outcome TEXT NOT NULL,success TINYINT NULL,"+
      "source VARCHAR(32) NOT NULL,observed_at VARCHAR(40) NOT NULL,hash CHAR(64) NOT NULL UNIQUE,"+
      "CONSTRAINT fk_aura_history_outcome_episode FOREIGN KEY(episode_id) REFERENCES aura_history_episodes(id),"+
      "CONSTRAINT chk_aura_history_success CHECK (success IS NULL OR success IN (0,1)),"+
      "CONSTRAINT chk_aura_history_source CHECK (source IN ('machine-verified','founder-feedback','external-report'))"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_hypotheses ("+
      "id BIGINT AUTO_INCREMENT PRIMARY KEY,statement TEXT NOT NULL,"+
      "scope_context VARCHAR(120) NOT NULL,predicted_action VARCHAR(32) NOT NULL,"+
      "expected_success TINYINT NOT NULL,confidence DOUBLE NOT NULL,"+
      "status VARCHAR(24) NOT NULL DEFAULT 'candidate',created_ts VARCHAR(40) NOT NULL,"+
      "updated_ts VARCHAR(40) NOT NULL,INDEX idx_aura_history_hyp_context(scope_context,status),"+
      "CONSTRAINT chk_aura_history_hyp_conf CHECK (confidence BETWEEN 0 AND 1),"+
      "CONSTRAINT chk_aura_history_prediction CHECK (predicted_action IN ('respond','verify','clarify','attentive','task_first')),"+
      "CONSTRAINT chk_aura_history_expectation CHECK (expected_success IN (0,1)),"+
      "CONSTRAINT chk_aura_history_hyp_status CHECK (status IN ('candidate','promoted','refuted','ablated'))"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_hypothesis_evidence ("+
      "hypothesis_id BIGINT NOT NULL,episode_id BIGINT NOT NULL,"+
      "polarity VARCHAR(16) NOT NULL,PRIMARY KEY(hypothesis_id,episode_id),"+
      "FOREIGN KEY(hypothesis_id) REFERENCES aura_history_hypotheses(id),"+
      "FOREIGN KEY(episode_id) REFERENCES aura_history_episodes(id),"+
      "CONSTRAINT chk_aura_history_polarity CHECK (polarity IN ('support','contradict'))"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_policies ("+
      "id BIGINT AUTO_INCREMENT PRIMARY KEY,hypothesis_id BIGINT NOT NULL,"+
      "rule_text TEXT NOT NULL,rule_action VARCHAR(32) NOT NULL,"+
      "active TINYINT NOT NULL DEFAULT 1,created_ts VARCHAR(40) NOT NULL,"+
      "FOREIGN KEY(hypothesis_id) REFERENCES aura_history_hypotheses(id),"+
      "CONSTRAINT chk_aura_history_rule CHECK (rule_action IN ('respond','verify','clarify','attentive','task_first')),"+
      "CONSTRAINT chk_aura_history_active CHECK (active IN (0,1))"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_decisions ("+
      "id BIGINT AUTO_INCREMENT PRIMARY KEY,ts VARCHAR(40) NOT NULL,"+
      "run_id VARCHAR(120) NOT NULL,situation_id VARCHAR(120) NOT NULL,"+
      "chosen_action VARCHAR(32) NOT NULL,confidence DOUBLE NULL,raw_output LONGTEXT NULL,"+
      "retrieval_snapshot LONGTEXT NULL,"+
      "INDEX idx_aura_history_decision_run(run_id,situation_id)"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE TABLE IF NOT EXISTS aura_history_decision_provenance ("+
      "decision_id BIGINT NOT NULL,item_type VARCHAR(16) NOT NULL,"+
      "item_id BIGINT NOT NULL,retrieval_rank INT NULL,"+
      "PRIMARY KEY(decision_id,item_type,item_id),"+
      "FOREIGN KEY(decision_id) REFERENCES aura_history_decisions(id),"+
      "CONSTRAINT chk_aura_history_provenance_type CHECK (item_type IN ('episode','hypothesis','policy'))"+
      ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    await db.query("CREATE OR REPLACE VIEW v_aura_history_calibration AS "+
      "SELECT e.context_tag,ROUND(e.confidence,1) AS conf_bin,COUNT(*) AS n,"+
      "AVG(o.success) AS observed_rate FROM aura_history_episodes e "+
      "JOIN aura_history_outcomes o ON o.episode_id=e.id "+
      "WHERE e.kind='action' AND e.confidence IS NOT NULL AND o.success IS NOT NULL "+
      "AND o.source='machine-verified' AND e.ablated=0 "+
      "GROUP BY e.context_tag,ROUND(e.confidence,1)");
    // Deny UPDATE and DELETE even if an application bug issues those queries.
    for (const [name,table,operation] of [
      ['trg_aura_hist_episode_update','aura_history_episodes','UPDATE'],
      ['trg_aura_hist_episode_delete','aura_history_episodes','DELETE'],
      ['trg_aura_hist_outcome_update','aura_history_outcomes','UPDATE'],
      ['trg_aura_hist_outcome_delete','aura_history_outcomes','DELETE'],
    ]) {
      const [existing] = await db.query(
        'SELECT TRIGGER_NAME FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND TRIGGER_NAME=?',[name]);
      if (!existing.length)
        await db.query('CREATE TRIGGER '+name+' BEFORE '+operation+' ON '+table+
          " FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='AURA history is append-only'");
    }
    await db.query(
      'INSERT IGNORE INTO aura_schema_migrations(version,name,applied_at) VALUES(18,?,?)',
      ['immutable-autobiography-causal-provenance', new Date().toISOString()],
    );
    current = 18;
  }

}

export async function initSchema() {
  const db = getDb();
  await ensureMigrationTable(db);
  const statements = [
    `CREATE TABLE IF NOT EXISTS aura_soul_state (
      id TINYINT PRIMARY KEY,
      state LONGTEXT NOT NULL,
      updated_at VARCHAR(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_cognitive_traces (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      kind VARCHAR(80) NOT NULL,
      title VARCHAR(240) NOT NULL DEFAULT '',
      content TEXT NOT NULL,
      context LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_cognitive_traces_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_reflections (
      id CHAR(36) PRIMARY KEY,
      trigger_name VARCHAR(160) NOT NULL,
      title VARCHAR(240) NOT NULL,
      summary TEXT NOT NULL,
      hypothesis TEXT NOT NULL,
      next_action TEXT NOT NULL,
      confidence DOUBLE NOT NULL DEFAULT 0,
      context LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_reflections_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_intentions (
      id CHAR(36) PRIMARY KEY,
      statement TEXT NOT NULL,
      priority DOUBLE NOT NULL DEFAULT 0.5,
      status VARCHAR(32) NOT NULL DEFAULT 'active',
      source VARCHAR(100) NOT NULL DEFAULT 'aura',
      context LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_intentions_status(status, priority, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_lessons (
      id CHAR(36) PRIMARY KEY,
      lesson_key VARCHAR(260) NOT NULL UNIQUE,
      content TEXT NOT NULL,
      confidence DOUBLE NOT NULL DEFAULT 0.5,
      evidence_count INT NOT NULL DEFAULT 1,
      source VARCHAR(100) NOT NULL DEFAULT 'experience',
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_routines (
      id CHAR(36) PRIMARY KEY,
      name VARCHAR(160) NOT NULL UNIQUE,
      prompt TEXT NOT NULL,
      every_seconds INT NOT NULL,
      mode VARCHAR(32) NOT NULL DEFAULT 'reflect',
      enabled TINYINT NOT NULL DEFAULT 1,
      last_run_at BIGINT NOT NULL DEFAULT 0,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_outcomes (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      automation_id VARCHAR(220) NOT NULL,
      event_type VARCHAR(220) NOT NULL,
      ok TINYINT NOT NULL,
      signature VARCHAR(500) NOT NULL,
      report LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_outcomes_automation(automation_id, ok, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_improvement_proposals (
      id CHAR(36) PRIMARY KEY,
      target VARCHAR(500) NOT NULL,
      diagnosis TEXT NOT NULL,
      proposal TEXT NOT NULL,
      validation_plan TEXT NOT NULL,
      risk VARCHAR(80) NOT NULL DEFAULT 'review',
      status VARCHAR(40) NOT NULL DEFAULT 'proposed',
      evidence_count INT NOT NULL DEFAULT 0,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_improvements_status(status, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_cloud_messages (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      author VARCHAR(120) NOT NULL,
      role ENUM('user','assistant') NOT NULL,
      session_id VARCHAR(96) NOT NULL DEFAULT '',
      content TEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_cloud_messages_session(session_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_language_experiences (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      session_id VARCHAR(96) NOT NULL,
      kind VARCHAR(48) NOT NULL,
      note TEXT NOT NULL,
      evidence_status VARCHAR(64) NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_language_experiences_session(session_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_world_beliefs (
      domain_key VARCHAR(220) PRIMARY KEY,
      observations INT NOT NULL DEFAULT 0,
      successes INT NOT NULL DEFAULT 0,
      failures INT NOT NULL DEFAULT 0,
      last_signature VARCHAR(500) NOT NULL DEFAULT '',
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_world_beliefs_observations(observations,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_language_benchmarks (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      score INT NOT NULL,
      dimensions LONGTEXT NOT NULL,
      provider VARCHAR(120) NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_language_benchmarks_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_organism_events (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      kind VARCHAR(80) NOT NULL,
      reason VARCHAR(500) NOT NULL DEFAULT '',
      payload LONGTEXT NOT NULL,
      state LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_organism_events_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_surprise_events (
      kind VARCHAR(240) PRIMARY KEY,
      count BIGINT NOT NULL DEFAULT 0,
      last_surprise DOUBLE NOT NULL DEFAULT 0,
      updated_at VARCHAR(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_surprise_memory (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      kind VARCHAR(240) NOT NULL,
      content TEXT NOT NULL,
      surprise DOUBLE NOT NULL,
      context LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_surprise_memory_score(surprise,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS horizon_bridge_seen (
      signal_id VARCHAR(220) PRIMARY KEY,
      entity_key VARCHAR(300) NOT NULL,
      aura_event VARCHAR(120) NOT NULL,
      observed_at VARCHAR(40) NOT NULL,
      first_seen_at VARCHAR(40) NOT NULL,
      INDEX idx_horizon_seen_first(first_seen_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_evolution_cycles (
      id CHAR(36) PRIMARY KEY,
      trigger_name VARCHAR(80) NOT NULL,
      objective TEXT NOT NULL,
      status VARCHAR(40) NOT NULL,
      research LONGTEXT NOT NULL,
      diagnosis LONGTEXT NOT NULL,
      candidate LONGTEXT NOT NULL,
      validation LONGTEXT NOT NULL,
      promotion LONGTEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_evolution_status(status, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_evolution_canary (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      cycle_id CHAR(36) NOT NULL,
      passed TINYINT NOT NULL,
      observations INT NOT NULL DEFAULT 0,
      metrics LONGTEXT NOT NULL,
      notes TEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_evolution_canary_cycle(cycle_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_execution_jobs (
      id CHAR(36) PRIMARY KEY,
      kind VARCHAR(40) NOT NULL,
      payload LONGTEXT NOT NULL,
      requested_risks LONGTEXT NOT NULL,
      status VARCHAR(32) NOT NULL DEFAULT 'queued',
      attempts INT NOT NULL DEFAULT 0,
      lease_owner VARCHAR(160) NOT NULL DEFAULT '',
      lease_until BIGINT NOT NULL DEFAULT 0,
      result LONGTEXT NOT NULL,
      error TEXT NOT NULL,
      created_at VARCHAR(40) NOT NULL,
      updated_at VARCHAR(40) NOT NULL,
      INDEX idx_aura_execution_jobs_status(status, created_at),
      INDEX idx_aura_execution_jobs_lease(lease_until)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE IF NOT EXISTS aura_execution_workers (
      worker_id VARCHAR(160) PRIMARY KEY,
      capabilities LONGTEXT NOT NULL,
      model VARCHAR(240) NOT NULL DEFAULT '',
      voice VARCHAR(240) NOT NULL DEFAULT '',
      version VARCHAR(120) NOT NULL DEFAULT '',
      last_seen_at VARCHAR(40) NOT NULL,
      last_seen_ms BIGINT NOT NULL DEFAULT 0,
      INDEX idx_aura_execution_workers_seen(last_seen_ms)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  ];
  for (const sql of statements) await db.query(sql);
  await applyMigrations(db);
}

export async function schemaStatus() {
  await ensureMigrationTable(getDb());
  const row = await one('SELECT COALESCE(MAX(version), 0) AS version FROM aura_schema_migrations');
  return {
    current: Number(row?.version || 0),
    latest: LATEST_SCHEMA_VERSION,
    ready: Number(row?.version || 0) === LATEST_SCHEMA_VERSION,
  };
}

export async function createLogicalBackup(reason = 'scheduled') {
  const timestamp = new Date().toISOString();
  const [soul, intentions, lessons, routines, improvements, evolution, commandServices, initiatives, reasoningSessions, fabricCapabilities, fabricGraphs, skills, knowledgeNotes] = await Promise.all([
    query('SELECT id,state,updated_at FROM aura_soul_state ORDER BY id'),
    query('SELECT * FROM aura_intentions ORDER BY updated_at DESC LIMIT 200'),
    query('SELECT * FROM aura_lessons ORDER BY updated_at DESC LIMIT 300'),
    query('SELECT * FROM aura_routines ORDER BY updated_at DESC LIMIT 200'),
    query('SELECT * FROM aura_improvement_proposals ORDER BY updated_at DESC LIMIT 150'),
    query('SELECT * FROM aura_evolution_cycles ORDER BY updated_at DESC LIMIT 100'),
    query('SELECT * FROM aura_command_services ORDER BY criticality DESC,name ASC'),
    query('SELECT * FROM aura_initiatives ORDER BY updated_at DESC LIMIT 200'),
    query('SELECT id,trigger_name,question,conclusion,confidence,epistemic_status,evidence_count,created_at,updated_at FROM aura_reasoning_sessions ORDER BY updated_at DESC LIMIT 100'),
    query('SELECT id,manifest_hash,transport,provider,trust,observed_reliability,latency_ms,cost_microunits,side_effects,last_seen_at,updated_at FROM aura_fabric_capabilities ORDER BY observed_reliability DESC LIMIT 200'),
    query('SELECT id,objective,status,created_at,updated_at FROM aura_fabric_graphs ORDER BY updated_at DESC LIMIT 100'),
    query('SELECT id,strategy_key,name,recipe,status,successes,failures,context_count,confidence,source,promoted_at,updated_at FROM aura_skills ORDER BY confidence DESC,updated_at DESC LIMIT 200'),
    query("SELECT * FROM aura_knowledge_notes WHERE namespace='founder' ORDER BY updated_at DESC LIMIT 500"),
  ]);
  const payload = JSON.stringify({
    format: 'aura-cognitive-snapshot-v1',
    created_at: timestamp,
    schema_version: LATEST_SCHEMA_VERSION,
    soul,
    intentions,
    lessons,
    routines,
    improvements,
    evolution,
    command_services: commandServices,
    initiatives,
    reasoning_sessions: reasoningSessions,
    fabric_capabilities: fabricCapabilities,
    fabric_graphs: fabricGraphs,
    skills,
    knowledge_notes: knowledgeNotes,
  });
  const id = randomUUID();
  await query(
    `INSERT INTO aura_state_snapshots(
      id,reason,schema_version,payload,payload_bytes,created_at
    ) VALUES(?,?,?,?,?,?)`,
    [id, String(reason).slice(0, 120), LATEST_SCHEMA_VERSION, payload, Buffer.byteLength(payload), timestamp],
  );
  const keep = Math.max(3, Number(config.backupRetentionCount || 28));
  await query(
    `DELETE FROM aura_state_snapshots
     WHERE id NOT IN (
       SELECT id FROM (
         SELECT id FROM aura_state_snapshots ORDER BY created_at DESC LIMIT ?
       ) AS recent_snapshots
     )`,
    [keep],
  );
  return { id, reason: String(reason), bytes: Buffer.byteLength(payload), created_at: timestamp };
}

export async function listLogicalBackups(limit = 20) {
  return query(
    'SELECT id,reason,schema_version,payload_bytes,created_at FROM aura_state_snapshots ORDER BY created_at DESC LIMIT ?',
    [Math.max(1, Math.min(Number(limit) || 20, 100))],
  );
}

export async function getLogicalBackup(id) {
  return one(
    'SELECT id,reason,schema_version,payload,payload_bytes,created_at FROM aura_state_snapshots WHERE id=?',
    [String(id)],
  );
}

export async function recordMetricRollup(name, payload) {
  await query(
    'INSERT INTO aura_runtime_metric_rollups(name,payload,created_at) VALUES(?,?,?)',
    [String(name).slice(0, 120), JSON.stringify(payload || {}).slice(0, 64000), new Date().toISOString()],
  );
}

export async function dbHealth() {
  const row = await one('SELECT 1 AS ok');
  return Boolean(row?.ok);
}
