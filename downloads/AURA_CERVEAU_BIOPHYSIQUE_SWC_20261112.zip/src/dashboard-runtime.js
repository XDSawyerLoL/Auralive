export const DASHBOARD_SCRIPT = String.raw`
const $ = function(id){ return document.getElementById(id); };
let lastSoul = null;
let lastAttention = null;
let livingScene = null;
let voicePlayer = null;
let voiceAudioContext = null;
let voicePrimed = false;
let localVoiceOptIn = false;
let localVoiceGeneration = 0;
try { localVoiceOptIn = localStorage.getItem('aura_local_voice_opt_in') === '1'; } catch (_) {}
try{localStorage.removeItem('aura_token');sessionStorage.removeItem('aura_token');}catch(_){}
const AURA_API_BASE=(function(){
  try{
    const qp=new URLSearchParams(location.search).get('api');
    if(qp && /^https:\/\//i.test(qp)){
      const clean=qp.replace(/\/$/,'');
      localStorage.setItem('aura_api_base',clean);
      return clean;
    }
    const explicit=String(window.AURA_API_BASE||'').trim().replace(/\/$/,'');
    if(explicit) return explicit;
    const saved=String(localStorage.getItem('aura_api_base')||'').trim().replace(/\/$/,'');
    if(saved) return saved;
  }catch(_){}
  if(location.hostname==='xdsawyerlol.github.io') return 'https://auralive-mmh5.onrender.com';
  return '';
})();
function apiUrl(path){
  const value=String(path||'');
  if(/^https?:\/\//i.test(value)) return value;
  return AURA_API_BASE ? AURA_API_BASE + (value.startsWith('/')?value:'/'+value) : value;
}

function escapeHtml(value){
  return String(value == null ? '' : value).replace(/[&<>"']/g,function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
  });
}
function headers(json){
  const h={};
  if(json) h['Content-Type']='application/json';
  return h;
}
async function api(path,options){
  options=options||{};
  const response=await fetch(apiUrl(path),Object.assign(
    {credentials:AURA_API_BASE?'include':'same-origin'},
    options,
    {headers:Object.assign({},headers(Boolean(options.body)),options.headers||{})}
  ));
  const text=await response.text();
  let data={};
  try{data=text?JSON.parse(text):{};}catch(_){data={error:text||'Réponse invalide'};}
  if(!response.ok){
    const err=new Error(data.error||('Erreur '+response.status)); err.status=response.status; err.data=data; throw err;
  }
  return data;
}
function pct(v){return Math.max(0,Math.min(100,Math.round((Number(v)||0)*100)));}
function metric(id,value,active=true){
  if(!active){$('metric-'+id).textContent='—';$('ring-'+id).style.setProperty('--pct',0);$('trend-'+id).textContent='en attente du noyau';return;}
  const p=pct(value);
  $('metric-'+id).textContent=p+'%';
  $('ring-'+id).style.setProperty('--pct',p);
  if(lastSoul && lastSoul[id] != null){
    const delta=(Number(value)||0)-Number(lastSoul[id]||0);
    $('trend-'+id).textContent=delta>.015?'↗ en hausse':delta<-.015?'↘ en baisse':'• stable';
  }
}
function emotionValue(id,value){
  const p=pct(value);
  const bar=$('emotion-'+id);
  const label=$('emotion-'+id+'-value');
  if(bar)bar.style.width=p+'%';
  if(label)label.textContent=p+'%';
}
function renderEmotion(o){
  o=o||{};
  const mood=String(o.mood||'calme');
  const reason=String(o.last_reason||(o.habitat&&o.habitat.last_activity_label)||o.active_intention||'présence intérieure');
  const colors={calme:'#9a6cff',claire:'#6da7ff',curieuse:'#59e0ef',intriguée:'#55d7c8',engagée:'#68b5ff',déterminée:'#8f6bff',satisfaite:'#7ee6a8',frustrée:'#ff9a66',lumineuse:'#ffc96a',fragile:'#d18cff','préoccupée':'#ff758d'};
  $('emotionMood').textContent=mood;
  $('emotionReason').textContent=reason;
  $('emotionOrb').style.boxShadow='0 0 34px '+(colors[mood]||'#9a6cff')+'66';
  $('emotionOrb').style.background='radial-gradient(circle at 38% 32%,#fff 0 6%,'+(colors[mood]||'#9a6cff')+' 24%,#312354 60%,#111522 76%)';
  emotionValue('stability',o.stabilite);
  emotionValue('clarity',o.clarte);
  emotionValue('attachment',o.attachement);
  emotionValue('curiosity',o.curiosite);
  emotionValue('engagement',o.engagement);
  emotionValue('confidence',o.confiance);
  emotionValue('agency',o.agency);
  emotionValue('satisfaction',o.satisfaction);
  emotionValue('frustration',o.frustration);
  emotionValue('social',o.curiosite_sociale);
  emotionValue('dream',o.pression_de_reve);
  emotionValue('silence',o.besoin_de_silence);
}
function setLive(ok,text){$('liveDot').className='live-dot '+(ok?'good':'bad');$('liveText').textContent=text;}
function fmtTime(value){
  if(!value) return '—';
  const d=new Date(value); if(Number.isNaN(d.getTime())) return '—';
  return d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
}
function fmtDate(value){
  if(!value) return '—';
  const d=new Date(value); if(Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short'});
}
function updateClock(){
  const d=new Date();
  $('clockDate').textContent=d.toLocaleDateString('fr-FR',{weekday:'short',day:'2-digit',month:'short',year:'numeric'});
  $('clockTime').textContent=d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
}
function priorityLabel(v){
  const p=Number(v)||0;
  return p>=.72?['Haute','high']:p>=.48?['Moyenne','medium']:['Basse',''];
}
function renderIntentions(rows){
  if(!rows || !rows.length){$('intentList').innerHTML='<div class="empty">Aucune intention active.</div>';return;}
  $('intentList').innerHTML=rows.slice(0,4).map(function(r,i){
    const tag=priorityLabel(r.priority);
    return '<div class="intent-row"><div class="intent-top"><span style="font-size:9px;color:#7d88a1">'+(i+1)+'</span><div class="intent-title">'+escapeHtml(r.statement)+'</div><span class="badge '+tag[1]+'">'+tag[0]+'</span></div></div>';
  }).join('');
}
function renderWork(rows){
  if(!rows || !rows.length){$('workList').innerHTML='<div class="empty">Aucun travail déclaré.</div>';return;}
  $('workMeta').textContent=rows.length+' actifs';
  $('workList').innerHTML=rows.slice(0,5).map(function(r){
    const p=pct(r.priority);
    return '<div class="work-row"><div class="work-top"><div class="work-title">'+escapeHtml(r.title)+'</div><span class="badge">'+escapeHtml(r.kind)+'</span></div><div class="progress"><span style="width:'+p+'%"></span></div></div>';
  }).join('');
}
function renderLessons(rows){
  if(!rows || !rows.length){$('memoryList').innerHTML='<div class="empty">Aucune leçon enregistrée.</div>';return;}
  $('memoryMeta').textContent=rows.length+' récentes';
  $('memoryList').innerHTML=rows.slice(0,5).map(function(r){
    return '<div class="memory-row"><div class="memory-date">'+escapeHtml(fmtDate(r.updated_at))+'</div><div class="memory-text">'+escapeHtml(r.content)+'</div></div>';
  }).join('');
}
function renderActivity(rows){
  if(!rows || !rows.length){$('activityList').innerHTML='<div class="empty">Aucune activité récente.</div>';return;}
  $('activityList').innerHTML=rows.slice(0,7).map(function(r){
    return '<div class="activity-row"><div class="activity-time">'+escapeHtml(fmtTime(r.created_at))+'</div><div class="activity-title">'+escapeHtml(r.title||r.content||r.kind)+'</div><div class="activity-kind">'+escapeHtml(r.kind||'activité')+'</div></div>';
  }).join('');
}
const nodeLayout={
  stability:{x:205,y:190,color:'#5de0aa'},
  learning:{x:455,y:112,color:'#9b6cff'},
  studio:{x:700,y:190,color:'#ec5fa9'},
  horizon:{x:755,y:355,color:'#ffbf68'},
  automation:{x:650,y:500,color:'#ff8f45'},
  memory:{x:450,y:535,color:'#f7e4cf'},
  evolution:{x:250,y:500,color:'#b46cff'},
  watch:{x:145,y:355,color:'#ffb76d'}
};
function renderMap(data){
  if(!data || !Array.isArray(data.nodes)) return;
  lastAttention=data;
  $('focusStatement').textContent=data.focus_statement||'Aucune intention dominante.';
  const svgNS='http://www.w3.org/2000/svg';
  const links=$('flowLinks'); const nodes=$('interestNodes'); const pulses=$('energyPulses');
  links.innerHTML=''; nodes.innerHTML=''; pulses.innerHTML='';

  const visibleNodes=data.nodes.filter(function(n){return Boolean(nodeLayout[n.id]);});
  visibleNodes.forEach(function(n,i){
    [1,2].forEach(function(offset){
      const other=visibleNodes[(i+offset)%visibleNodes.length];
      if(!other || other===n) return;
      if(offset===2 && i%2) return;
      const a=nodeLayout[n.id]; const b=nodeLayout[other.id];
      const web=document.createElementNS(svgNS,'path');
      const bend=(i%2===0?1:-1)*(18+offset*8);
      const mx=(a.x+b.x)/2+(b.y-a.y)*.035*bend/8;
      const my=(a.y+b.y)/2-(b.x-a.x)*.035*bend/8;
      web.setAttribute('d','M '+a.x+' '+a.y+' Q '+mx+' '+my+' '+b.x+' '+b.y);
      web.setAttribute('class','web-link');
      web.setAttribute('fill','none');
      web.setAttribute('stroke',offset===1?a.color:'#a26f6c');
      web.setAttribute('stroke-width',offset===1?'1.15':'.75');
      web.setAttribute('opacity',offset===1?'.16':'.085');
      web.setAttribute('stroke-dasharray',offset===1?'2 8':'1 12');
      links.appendChild(web);
    });
  });

  data.nodes.forEach(function(n){
    const pos=nodeLayout[n.id]; if(!pos) return;
    const intensity=Math.max(.18,Math.min(1,Number(n.score)||0));
    const line=document.createElementNS(svgNS,'path');
    const midX=(450+pos.x)/2+(pos.y-325)*.09;
    const midY=(325+pos.y)/2-(pos.x-450)*.07;
    line.setAttribute('d','M 450 325 Q '+midX+' '+midY+' '+pos.x+' '+pos.y);
    line.setAttribute('class','core-link');
    line.setAttribute('fill','none'); line.setAttribute('stroke',pos.color);
    line.setAttribute('stroke-width',String(1.2+intensity*3.8));
    line.setAttribute('opacity',String(.16+intensity*.54));
    line.setAttribute('stroke-dasharray',n.dominant?'0':(n.trend==='rising'?'7 8':'3 11'));
    if(n.dominant) line.setAttribute('filter','url(#glow)');
    links.appendChild(line);

    const pulse=document.createElementNS(svgNS,'path');
    pulse.setAttribute('class','energy-pulse');
    pulse.setAttribute('d',line.getAttribute('d'));
    pulse.setAttribute('stroke',pos.color);
    pulse.setAttribute('stroke-width',String(1.1+intensity*1.5));
    pulse.setAttribute('stroke-dasharray',n.dominant?'3 17':'2 22');
    pulse.setAttribute('opacity',String(.40+intensity*.46));
    pulse.style.animationDuration=String(5.8-intensity*2.2)+'s';
    pulse.style.animationDelay=String(-intensity*2.7)+'s';
    $('energyPulses').appendChild(pulse);

    const g=document.createElementNS(svgNS,'g');
    const scale=.78+intensity*.58;
    g.setAttribute('class','aura-node');
    g.setAttribute('data-node-id',n.id);
    g.setAttribute('data-base-x',String(pos.x));
    g.setAttribute('data-base-y',String(pos.y));
    g.setAttribute('data-scale',String(scale));
    g.setAttribute('data-phase',String((n.id.length*0.73)+(intensity*2.4)));
    g.setAttribute('transform','translate('+pos.x+' '+pos.y+') scale('+scale+')');
    const halo=document.createElementNS(svgNS,'circle'); halo.setAttribute('r',String(35+intensity*16)); halo.setAttribute('fill',pos.color); halo.setAttribute('opacity',String(.035+intensity*.07)); halo.setAttribute('filter','url(#soft)');
    const orbit=document.createElementNS(svgNS,'ellipse'); orbit.setAttribute('rx','43'); orbit.setAttribute('ry','18'); orbit.setAttribute('fill','none'); orbit.setAttribute('stroke',pos.color); orbit.setAttribute('opacity',String(.18+intensity*.34)); orbit.setAttribute('transform','rotate('+(n.id.length*13%60-30)+')');
    const circle=document.createElementNS(svgNS,'circle'); circle.setAttribute('r','24'); circle.setAttribute('fill',pos.color); circle.setAttribute('fill-opacity',String(.17+intensity*.25)); circle.setAttribute('stroke',pos.color); circle.setAttribute('stroke-width',n.dominant?'2.2':'1.2'); circle.setAttribute('filter','url(#glow)');
    const core=document.createElementNS(svgNS,'circle'); core.setAttribute('r','8'); core.setAttribute('fill',pos.color); core.setAttribute('opacity',String(.55+intensity*.45));
    g.appendChild(halo);g.appendChild(orbit);g.appendChild(circle);g.appendChild(core);
    nodes.appendChild(g);

    const label=document.createElementNS(svgNS,'text'); label.setAttribute('x',String(pos.x+38)); label.setAttribute('y',String(pos.y-3)); label.setAttribute('fill','#f8f1eb'); label.setAttribute('font-size','13'); label.setAttribute('font-weight','600'); label.textContent=n.label; nodes.appendChild(label);
    const sub=document.createElementNS(svgNS,'text'); sub.setAttribute('x',String(pos.x+38)); sub.setAttribute('y',String(pos.y+13)); sub.setAttribute('fill','#897c78'); sub.setAttribute('font-size','9'); sub.textContent=n.subtitle+' · '+Math.round(intensity*100)+'%'; nodes.appendChild(sub);
  });
}
function initLivingAuraScene(){
  if(livingScene) return livingScene;
  const wrap=$('livingMap');
  const nebula=$('nebulaFx');
  const particles=$('particleFx');
  const svg=$('attentionMap');
  if(!wrap||!nebula||!particles||!svg) return null;
  const nctx=nebula.getContext('2d');
  const pctx=particles.getContext('2d');
  if(!nctx||!pctx){
    console.warn('AURA visual canvas unavailable; live data remains active.');
    return null;
  }
  const reduceMotion=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const scene={w:0,h:0,dpr:1,time:0,lastFrame:0,raf:0,dust:[],sparks:[],running:true,organism:{}};

  function rand(min,max){return min+Math.random()*(max-min);}
  function seed(){
    const mobile=window.innerWidth<820;
    const dustCount=reduceMotion?24:(mobile?44:108);
    const sparkCount=reduceMotion?5:(mobile?9:18);
    scene.dust=Array.from({length:dustCount},function(_,i){
      return {x:Math.random(),y:Math.random(),r:rand(.35,1.35),vx:rand(-.000022,.000022),vy:rand(-.000018,.000018),a:rand(.10,.48),phase:rand(0,Math.PI*2),hue:i%5};
    });
    scene.sparks=Array.from({length:sparkCount},function(){
      return {angle:rand(0,Math.PI*2),radius:rand(.14,.40),speed:rand(.000025,.00008),size:rand(.7,1.7),phase:rand(0,Math.PI*2)};
    });
  }

  function resize(){
    const rect=wrap.getBoundingClientRect();
    scene.w=Math.max(320,Math.floor(rect.width));
    scene.h=Math.max(360,Math.floor(rect.height));
    scene.dpr=Math.min(window.devicePixelRatio||1,1.55);
    [nebula,particles].forEach(function(canvas){
      canvas.width=Math.floor(scene.w*scene.dpr);
      canvas.height=Math.floor(scene.h*scene.dpr);
      canvas.style.width=scene.w+'px';
      canvas.style.height=scene.h+'px';
    });
    nctx.setTransform(scene.dpr,0,0,scene.dpr,0,0);
    pctx.setTransform(scene.dpr,0,0,scene.dpr,0,0);
  }

  function glow(x,y,r,color,alpha){
    const g=nctx.createRadialGradient(x,y,0,x,y,r);
    g.addColorStop(0,color.replace('ALPHA',String(alpha)));
    g.addColorStop(.28,color.replace('ALPHA',String(alpha*.56)));
    g.addColorStop(.68,color.replace('ALPHA',String(alpha*.13)));
    g.addColorStop(1,color.replace('ALPHA','0'));
    nctx.fillStyle=g;
    nctx.fillRect(x-r,y-r,r*2,r*2);
  }

  function drawNebula(t){
    nctx.clearRect(0,0,scene.w,scene.h);
    nctx.globalCompositeOperation='screen';
    const o=scene.organism||{};
    const dynamics=o.dynamics||{};
    const agitation=Number(dynamics.agitation||0);
    const activation=Number(dynamics.activation||0);
    const recovery=Number(dynamics.recovery||0);
    const curiosity=Number(o.curiosite||0);
    const stability=Number(o.stabilite||0);
    const dream=Number(o.pression_de_reve||0);
    const attachment=Number(o.attachement||0);
    const silence=Number(o.besoin_de_silence||0);
    const cx=scene.w*.5, cy=scene.h*.50;
    const tempo=.00040+agitation*.00042+activation*.00012-silence*.00008;
    const breath=.5+.5*Math.sin(t*tempo);
    glow(cx+Math.sin(t*.00016)*10,cy+Math.cos(t*.00013)*8,Math.max(scene.w,scene.h)*(.28+dream*.06),'rgba(255,157,72,ALPHA)',.14+.10*dream+.055*breath);
    glow(cx-scene.w*.22+Math.sin(t*.00010)*18,cy-scene.h*.18,scene.w*.24,'rgba(151,92,255,ALPHA)',.055+.12*curiosity);
    glow(cx+scene.w*.25,cy-scene.h*.16+Math.cos(t*.00012)*12,scene.w*.25,'rgba(232,78,164,ALPHA)',.045+.095*stability);
    glow(cx+scene.w*.29+Math.cos(t*.00009)*12,cy+scene.h*.19,scene.w*.20,'rgba(255,190,102,ALPHA)',.045+.09*attachment);
    glow(cx-scene.w*.25,cy+scene.h*.21+Math.sin(t*.00011)*11,scene.w*.20,'rgba(187,92,255,ALPHA)',.035+.15*agitation);
    glow(cx,cy,Math.min(scene.w,scene.h)*(.15+.08*stability),'rgba(255,224,190,ALPHA)',.05+.08*recovery);
    nctx.globalCompositeOperation='source-over';
  }

  function drawParticles(t){
    pctx.clearRect(0,0,scene.w,scene.h);
    pctx.globalCompositeOperation='screen';
    const colors=['255,231,207','155,108,255','236,95,169','255,191,104','93,224,170'];
    scene.dust.forEach(function(d){
      const o=scene.organism||{};const dynamics=o.dynamics||{};const motion=.45+Number(o.curiosite||0)*.55+Number(dynamics.activation||0)*.55-Number(o.besoin_de_silence||0)*.35;
      if(!reduceMotion){d.x+=d.vx*motion;d.y+=d.vy*motion;}
      if(d.x<-.02)d.x=1.02;if(d.x>1.02)d.x=-.02;if(d.y<-.02)d.y=1.02;if(d.y>1.02)d.y=-.02;
      const pulse=.46+.54*Math.sin(t*.00125+d.phase)*.5+.27;
      const a=Math.max(.04,d.a*pulse);
      pctx.beginPath();
      pctx.fillStyle='rgba('+colors[d.hue]+','+a+')';
      pctx.arc(d.x*scene.w,d.y*scene.h,d.r*(.7+pulse*.65),0,Math.PI*2);
      pctx.fill();
    });

    const cx=scene.w*.5,cy=scene.h*.50;
    scene.sparks.forEach(function(s){
      const o=scene.organism||{};const dynamics=o.dynamics||{};const orbit=.60+Number(o.curiosite||0)*.70+Number(dynamics.activation||0)*.45+Number(dynamics.agitation||0)*.30;
      if(!reduceMotion)s.angle+=s.speed*16.6*orbit;
      const wobble=1+Math.sin(t*.0008+s.phase)*.07;
      const rr=Math.min(scene.w,scene.h)*s.radius*wobble;
      const x=cx+Math.cos(s.angle)*rr;
      const y=cy+Math.sin(s.angle)*rr*.66;
      const a=.20+.56*(.5+.5*Math.sin(t*.002+s.phase));
      const g=pctx.createRadialGradient(x,y,0,x,y,10+s.size*4);
      g.addColorStop(0,'rgba(255,239,222,'+a+')');
      g.addColorStop(.22,'rgba(255,166,89,'+(a*.68)+')');
      g.addColorStop(1,'rgba(255,166,89,0)');
      pctx.fillStyle=g;pctx.fillRect(x-18,y-18,36,36);
    });
    pctx.globalCompositeOperation='source-over';
  }

  function animateSvg(t){
    const core=$('core');
    if(core){
      const o=scene.organism||{};
      const dynamics=o.dynamics||{};
      const agitation=Number(dynamics.agitation||0), activation=Number(dynamics.activation||0), stability=Number(o.stabilite||0), silence=Number(o.besoin_de_silence||0);
      const amp=.012+agitation*.024+activation*.012+(1-stability)*.010;
      const speed=.00072+activation*.00070+agitation*.00085-silence*.00020;
      const pulse=reduceMotion?1:(1+Math.sin(t*speed)*amp+Math.sin(t*.00041)*.012);
      const rot=reduceMotion?0:Math.sin(t*(.00007+agitation*.00008))*(.28+agitation*1.15);
      core.setAttribute('transform','translate(450 325) rotate('+rot+') scale('+pulse+') translate(-450 -325)');
    }
    document.querySelectorAll('.aura-node').forEach(function(node,index){
      const bx=Number(node.getAttribute('data-base-x'))||0;
      const by=Number(node.getAttribute('data-base-y'))||0;
      const scale=Number(node.getAttribute('data-scale'))||1;
      const phase=Number(node.getAttribute('data-phase'))||index;
      const dx=reduceMotion?0:Math.sin(t*.00042+phase)*1.6;
      const dy=reduceMotion?0:Math.cos(t*.00036+phase*1.31)*1.35;
      const breathe=reduceMotion?1:(1+Math.sin(t*.0008+phase)*.018);
      node.setAttribute('transform','translate('+(bx+dx)+' '+(by+dy)+') scale('+(scale*breathe)+')');
      node.style.opacity=String(.95+.05*(.5+.5*Math.sin(t*.0007+phase)));
    });
  }

  function frame(t){
    if(!scene.running)return;
    if(scene.lastFrame && t-scene.lastFrame<30){scene.raf=requestAnimationFrame(frame);return;}
    scene.lastFrame=t;
    scene.time=t;
    drawNebula(t);
    drawParticles(t);
    animateSvg(t);
    scene.raf=requestAnimationFrame(frame);
  }

  seed();resize();
  window.addEventListener('resize',resize,{passive:true});
  if(window.ResizeObserver){new ResizeObserver(resize).observe(wrap);}
  document.addEventListener('visibilitychange',function(){
    scene.running=!document.hidden;
    if(scene.running){cancelAnimationFrame(scene.raf);scene.raf=requestAnimationFrame(frame);}
  });
  scene.raf=requestAnimationFrame(frame);
  livingScene=scene;
  return scene;
}

function renderCommandCenter(command,work,attention){
  if(!command){
    $('commandState').textContent='Indisponible';
    $('commandFleet').textContent='—';
    $('commandMode').textContent='—';
    $('commandCount').textContent='—';
    if($('commandCompany'))$('commandCompany').textContent='—';
    renderNext(work,attention);
    return;
  }
  const fleet=command.fleet||{};
  const counts=command.counts||{};
  const active=Number(counts.queued||0)+Number(counts.running||0)+Number(counts.waiting||0);
  $('commandState').textContent=command.running?'Cycle actif':(command.enabled?'Autonome':'Arrêté');
  $('commandFleet').textContent=fleet.score==null?'En observation':String(fleet.score)+'%';
  $('commandFleet').className=(fleet.score!=null&&Number(fleet.score)>=80)?'good':((fleet.score!=null&&Number(fleet.score)<60)?'warn':'');
  $('commandMode').textContent=command.github_write_authority?'Agit + observe':'Observe + planifie';
  $('commandMode').className=command.github_write_authority?'good':'warn';
  $('commandCount').textContent=active+' active'+(active>1?'s':'');
  const readiness=command.company_readiness||{};
  if($('commandCompany')){
    const score=Number(readiness.overall||0);
    $('commandCompany').textContent=score?score.toFixed(1)+'/10':'—';
    $('commandCompany').className=score>=8?'good':(score>0?'warn':'');
    $('commandCompany').title=Array.isArray(readiness.blockers)&&readiness.blockers.length
      ? readiness.blockers.join(' · ')
      : 'Objectif ≥ 8/10 atteint sur les preuves runtime disponibles.';
    const scoreRing=$('commandCompany').closest('.score-ring');
    if(scoreRing){
      const ringPct=Math.max(0,Math.min(100,score*10));
      scoreRing.style.background='conic-gradient(#5de0aa 0 '+ringPct+'%,rgba(255,255,255,.06) '+ringPct+'% 100%)';
    }
  }
  const top=command.top_initiative||null;
  if(top){
    $('nextAction').textContent=String(top.title||top.objective||'Initiative autonome');
    const priority=pct(top.priority||0);
    const confidence=pct(top.confidence||0);
    $('confidenceValue').textContent=priority+'% / '+confidence+'%';
    $('confidenceBar').style.width=priority+'%';
    return;
  }
  renderNext(work,attention);
}
function renderPortfolio(command){
  const list=$('portfolioList');
  const meta=$('portfolioMeta');
  if(!list||!meta)return;
  const rows=Array.isArray(command&&command.portfolio)?command.portfolio:[];
  if(!rows.length){
    meta.textContent='Aucune télémétrie';
    list.innerHTML='<div class="empty">Aucun produit observable pour le moment.</div>';
    return;
  }
  const healthy=rows.filter(function(row){return ['online','healthy'].includes(String(row.state||''));}).length;
  const troubled=rows.filter(function(row){return ['stale','offline','degraded','error','unhealthy'].includes(String(row.state||''));}).length;
  meta.textContent=healthy+'/'+rows.length+' opérationnels'+(troubled?' · '+troubled+' à traiter':'');
  list.innerHTML=rows.map(function(row){
    const age=row.heartbeat_age_seconds==null?'jamais':(Number(row.heartbeat_age_seconds)<60?Number(row.heartbeat_age_seconds)+' s':Math.round(Number(row.heartbeat_age_seconds)/60)+' min');
    const active=Number(row.active_workstreams||0);
    const state=String(row.state||'unknown');
    return '<div class="intent-row product-row"><div class="intent-top"><div class="intent-title">'+escapeHtml(row.name||row.id||'Produit')+'</div><span class="badge '+escapeHtml(state)+'">'+escapeHtml(state)+'</span></div><div class="memory-date">heartbeat '+escapeHtml(age)+' · '+active+' workstream'+(active>1?'s':'')+(row.last_work_at?' · travail '+fmtTime(row.last_work_at):'')+'</div></div>';
  }).join('');
}
function renderReceipts(command){
  const list=$('receiptList');
  const meta=$('receiptMeta');
  if(!list||!meta)return;
  const rows=Array.isArray(command&&command.recent_receipts)?command.recent_receipts:[];
  meta.textContent=rows.length+' preuve'+(rows.length>1?'s':'')+' récente'+(rows.length>1?'s':'');
  if(!rows.length){
    list.innerHTML='<div class="empty">Aucun reçu opérationnel récent.</div>';
    return;
  }
  list.innerHTML=rows.slice(0,12).map(function(row){
    const title=String(row.title||row.event||'Activité AURA');
    const detail=[row.domain,row.status,row.execution_mode].filter(Boolean).join(' · ');
    return '<div class="activity-row"><div><div class="activity-title">'+escapeHtml(title)+'</div><div class="memory-date">'+escapeHtml(detail)+' · reçu #'+escapeHtml(row.receipt_id||'—')+'</div></div><div class="activity-time">'+fmtTime(row.created_at)+'</div></div>';
  }).join('');
}
function renderCuriosity(status){
  const list=$('curiosityList');
  const meta=$('curiosityMeta');
  if(!list||!meta)return;
  if(!status||!status.enabled){
    meta.textContent='Arrêtée';
    list.innerHTML='<div class="empty">Moteur de curiosité indisponible.</div>';
    return;
  }
  meta.textContent=String(Number(status.questions_last_hour||0))+' question'+(Number(status.questions_last_hour||0)>1?'s':'')+'/h';
  const rows=Array.isArray(status.recent_questions)?status.recent_questions:[];
  if(!rows.length){
    list.innerHTML='<div class="empty">AURA observe avant de formuler une nouvelle question.</div>';
    return;
  }
  list.innerHTML=rows.slice(0,4).map(function(row){
    const target=String(row.target||'system');
    const domain=String(row.domain||'aura');
    return '<div class="intent-row"><div class="intent-top"><div class="intent-title">'+escapeHtml(row.content||'')+'</div><span class="badge">'+escapeHtml(target)+'</span></div><div class="memory-date">'+escapeHtml(domain)+'</div></div>';
  }).join('');
}
function renderScout(status){
  const list=$('scoutList');
  const meta=$('scoutMeta');
  if(!list||!meta)return;
  if(!status||!status.enabled){
    meta.textContent='Arrêtée';
    list.innerHTML='<div class="empty">Veille autonome indisponible.</div>';
    return;
  }
  meta.textContent=status.running?'Scan en cours':'Sans prompt · '+Math.round(Number(status.interval_seconds||0)/60)+' min';
  const rows=Array.isArray(status.recent_findings)?status.recent_findings:[];
  if(!rows.length){
    list.innerHTML='<div class="empty">AURA cherche seule de nouvelles capacités pertinentes.</div>';
    return;
  }
  list.innerHTML=rows.slice(0,5).map(function(row){
    const score=Math.round(Number(row.score||0)*100);
    const license=String(row.license||'licence ?');
    const badge=row.experiment_eligible?'test':'veille';
    return '<div class="intent-row"><div class="intent-top"><div class="intent-title">'+escapeHtml(row.repository||'Projet externe')+'</div><span class="badge">'+score+'% · '+escapeHtml(badge)+'</span></div><div class="memory-date">'+escapeHtml(license)+' · '+escapeHtml(row.theme||'veille')+'</div></div>';
  }).join('');
}
function renderNext(work,attention){
  const item=(work&&work[0])||null;
  const node=attention&&attention.nodes?attention.nodes.find(function(n){return n.dominant;}):null;
  if(item){$('nextAction').textContent=item.title;const p=pct(item.priority||.6);$('confidenceValue').textContent=p+'%';$('confidenceBar').style.width=p+'%';return;}
  if(node){$('nextAction').textContent='Poursuivre le focus sur '+node.label+'.';const p=pct(node.score);$('confidenceValue').textContent=p+'%';$('confidenceBar').style.width=p+'%';return;}
  $('nextAction').textContent='Observer le système avant de prioriser une nouvelle action.';$('confidenceValue').textContent='—';$('confidenceBar').style.width='0%';
}
function renderLanguageProgress(report){
  const known=report && typeof report.score==='number' && Number.isFinite(report.score);
  const score=known?Math.max(0,Math.min(100,Math.round(report.score))):null;
  $('languageScore').textContent=known?score+'%':'—';
  $('languageProgressBar').style.width=known?score+'%':'0%';
  if(known)$('languageTrack').setAttribute('aria-valuenow',String(score));
  else $('languageTrack').removeAttribute('aria-valuenow');
  $('languageTrack').setAttribute('aria-valuetext',known?score+' pour cent aux tests':'Pas encore évalué');
  const delta=typeof report?.delta==='number'?report.delta:null;
  const suffix=delta===null?'Mesure initiale':delta>0?'↗ +'+delta+' points':delta<0?'↘ '+delta+' points · régression':'→ Stable';
  $('languageTrend').textContent=known?suffix:'Premier test en attente';
  if(report?.status==='model-unavailable'&&!known){
    const missing=report?.blocking_reason==='openrouter-free-key-missing';
    $('languageTrend').textContent=missing?'Modèle gratuit à connecter':'Moteur gratuit indisponible';
    if(report?.setup_hint)$('languageTrend').title=String(report.setup_hint);
  }else $('languageTrend').title='';
  if(report?.status==='unavailable'&&!known)$('languageTrend').textContent='Service de mesure indisponible';
  if(report?.evaluated_at){
    const d=new Date(report.evaluated_at);
    $('languageTestDate').textContent=Number.isNaN(d.getTime())?'Évaluation datée indisponible':'Évalué le '+d.toLocaleDateString('fr-FR');
  }else $('languageTestDate').textContent='Tests comparables · 9 tâches';
  const explain='Score mesuré sur '+(report?.benchmark_cases||9)+' tâches fixes de compréhension, mémoire, correction et raisonnement. Ne mesure ni conscience ni entraînement des poids.';
  $('languageTrack').title=explain;
  const help=$('languageSetupHelp');
  if(help){
    const issue=String(report?.setup_hint||'');
    help.hidden=!issue;
    help.textContent=issue;
  }
}


function renderLanguageEngine(state){
  const panel=$('enginePanel');if(!panel)return;
  const install=state?.provisioning||{};
  const stage=String(install.stage||'not-started');
  const backend=String(state?.status||'');
  const fail=String(install.error_code||state?.failure_code||'');
  const filesPresent=Boolean(state?.binary_found&&state?.model_found);
  const installed=Boolean(state?.installed);
  const budget=state?.memory_preflight||{};
  const memoryBlocked=budget.safe_to_start===false;
  const healthy=Boolean(state?.ready&&state?.probe_verified&&state?.last_probe_at);
  const booting=backend==='starting'||backend==='verifying-inference';
  const blocked=memoryBlocked||stage==='blocked'||backend==='startup-failed'||!!fail;
  const kind=healthy?'ready':blocked?'blocked':booting?'loading':'loading';
  panel.dataset.state=kind;
  $('engineChip').textContent=healthy?'Réponse vérifiée'
    :memoryBlocked?'Mémoire insuffisante'
    :blocked?'Échec réel':booting?'Initialisation en cours':'Non vérifié';
  $('railLanguage').textContent=healthy?'Conversation disponible'
    :booting?'Chargement du modèle':'Français non opérationnel';
  const titles={
    'embedded-unsafe-redirect':'Redirection HTTPS de téléchargement interdite',
    'embedded-sha256-mismatch':'Le modèle ou moteur téléchargé a échoué au contrôle d’intégrité',
    'embedded-insufficient-cgroup-memory':'Mémoire serveur insuffisante pour installer le modèle',
    'embedded-insufficient-cgroup-headroom':'Pas assez de mémoire libre pour charger le modèle Q8',
    'embedded-cache-unavailable-or-noexec':'Cache inexécutable ou espace disque insuffisant',
    'embedded-download-http-403':'Téléchargement refusé à la source',
    'embedded-download-http-429':'Téléchargement temporairement limité',
    'embedded-download-http-404':'Archive du moteur ou GGUF introuvable',
    'embedded-thread-capacity-exhausted':'Limite de threads de Hostinger atteinte',
    'embedded-process-exit-0':'Le moteur quitte sans servir le modèle',
    'embedded-clean-exit-before-inference':'Le moteur quitte avant toute génération',
    'embedded-native-stopped-after-serving':'Le moteur s’est arrêté après une réponse',
    'embedded-inference-probe-timeout':'Le modèle ne produit pas de texte dans les délais',
    'embedded-inference-probe-http':'L’inférence locale renvoie une erreur HTTP',
    'embedded-inference-probe-empty':'L’inférence ne renvoie aucun texte',
    'embedded-inference-probe-invalid':'La preuve de génération est absente',
    'embedded-insufficient-memory':'Mémoire du serveur insuffisante',
    'embedded-startup-timeout':'Démarrage du moteur trop long',
    'embedded-model-load-failed':'Modèle GGUF impossible à charger',
    'embedded-native-segfault':'Arrêt anormal du moteur natif',
    'host-disallows-native-execution':'Exécution native interdite',
    'embedded-cpu-instruction-unsupported':'Instructions du processeur incompatibles',
    'embedded-shared-library-unresolved':'Bibliothèque native introuvable',
    'embedded-static-sha256-mismatch':'Intégrité du moteur invalide'
  };
  $('engineTitle').textContent=healthy?'Génération locale vérifiée'
    :memoryBlocked?'Mémoire insuffisante pour charger Qwen3 Q8'
    :blocked?(titles[fail]||'Moteur français indisponible')
      :booting?'Chargement du moteur linguistique'
        :filesPresent?'Fichiers détectés · inférence non vérifiée'
          :'Fichiers du modèle à installer';
  const attempts=Array.isArray(state?.boot_attempts)?state.boot_attempts:[];
  const history=attempts.map(a=>a.profile+': '+a.outcome+
    (a.exit_signal?' '+a.exit_signal:a.exit_code!==null&&a.exit_code!==undefined?' code '+a.exit_code:'')+
    (a.health_seen?' santé OK':'')+(a.inference_verified?' inférence vérifiée':''))
    .join(' · ');
  $('engineDescription').textContent=healthy
    ?'Un test local a réellement généré des tokens sur ce serveur. Ce résultat prouve le fonctionnement de l’inférence, pas un apprentissage linguistique.'
    :memoryBlocked
      ?'Mémoire disponible estimée : '+String(budget.headroom_mb??'inconnue')+' Mo, minimum prudent : '+String(budget.minimum_headroom_mb||740)+' Mo. Le démarrage est interdit pour protéger le site. Il faut un modèle plus petit ou davantage de mémoire existante.'
    :booting
      ?backend==='verifying-inference'?'Le modèle a répondu au contrôle de santé. AURA vérifie maintenant la production réelle de tokens.'
         :'Le modèle est installé. Une tentative de démarrage est en cours ; aucune réponse française n’a encore été vérifiée.'
      :blocked
        ?'Fichiers : '+(installed?'installés et vérifiés':'installation incomplète')+
          '. Moteur : échec du démarrage'+(fail?' ('+fail+')':'')+
          '. Dernier processus : '+String(state?.process_exit?.signal||(state?.process_exit?.code??'inconnu'))+
          '. Tentatives : '+(history||'aucun historique')+
          '. Signaux : '+(Array.isArray(state?.log_signals)&&state.log_signals.length
            ?state.log_signals.join(', '):'aucun signal classifié')+
          '. Aucun texte de réponse n’a été généré.'
        :'Le modèle est installé, mais le moteur n’a pas encore répondu. La présence des fichiers ne mesure pas l’apprentissage.';
  const stages={
    'not-started':'Installation non démarrée',
    'locating-existing-install':'Localisation des fichiers',
    'downloading-cpu-runtime':'Téléchargement du runtime',
    'extracting-cpu-runtime':'Vérification du runtime',
    'downloading-open-model':'Téléchargement GGUF',
    'installed-verified':'Fichiers GGUF et exécutable vérifiés',
    'blocked':'Installation bloquée'
  };
  $('engineStage').textContent=stage==='not-started'&&filesPresent
    ?'Fichiers déjà présents · installateur non sollicité'
    :stages[stage]||backend||'En attente';
  // This bar measures file installation only, never linguistic learning.
  const fileProgress={
    'not-started':0,'locating-existing-install':10,'downloading-cpu-runtime':25,
    'extracting-cpu-runtime':50,'downloading-open-model':70,
    'installed-verified':100,'blocked':0
  };
  $('engineProgress').style.width=(filesPresent?100:(fileProgress[stage]??0))+'%';
  const variant=install.engine_variant==='unselected'&&filesPresent
    ?'fichiers détectés' :String(install.engine_variant||'variante inconnue');
  $('engineRevision').textContent='llama.cpp '+String(install.engine_revision||'local')+
    ' · '+String(install.model||'GGUF')+' · '+variant;
  const startButton=$('engineStart');
  if(startButton){
    startButton.disabled=healthy||booting||!installed||memoryBlocked||state?.enabled===false;
    startButton.title=memoryBlocked?'Mémoire insuffisante : démarrage désactivé pour protéger Hostinger.'
      :!installed?'Modèle ou exécutable absent.'
      :'Action privée. Démarrage local et test d’inférence; aucune API payante.';
  }
}
async function refreshEnginePanel(){
  try{renderLanguageEngine(await api('/api/language/embedded/status'));}
  catch(error){
    renderLanguageEngine({provisioning:{stage:'blocked',error_code:'diagnostic-unavailable'},failure_code:'diagnostic-unavailable'});
    $('engineDescription').textContent='Le diagnostic du moteur est inaccessible ('+String(error.status||'réseau')+'). La génération n’est pas vérifiée.';
  }
}

async function refresh(){
  try{
    const boot=await api('/api/bootstrap/status');
    $('railBrain').textContent=boot.runtime_ready?'Mémoire et cognition actives':'Noyau en démarrage';
    try{
      const info=await api('/healthz');
      $('serverRevision').textContent='Serveur · '+String(info?.build?.git_sha_short||'révision inconnue');
    }catch(_){$('serverRevision').textContent='Serveur · connexion partielle';}
    await refreshEnginePanel();
    try{
      const aiStatus=await api('/api/ai/runtime');
      const free=aiStatus?.groq_free||{};
      const state=free.last_status==='verified-text'?'Réponse vérifiée'
        :free.enabled?'Configuré · réponse à vérifier'
        :free.api_key_configured&&!free.free_plan_operator_confirmed?'Formule Free à confirmer'
        :!free.api_key_configured?'Clé API à configurer':'Désactivé';
      $('groqFreeStatus').textContent='Groq Free · '+state
        +' · modèle '+String(free.model||'qwen/qwen3.8-27b')
        +' · appels locaux aujourd’hui '+String(free.process_requests_today??0)
        +' / '+String(free.daily_cap??'—')
        +(free.last_error?' · '+String(free.last_error).slice(0,120):'');
      if(free.last_status==='verified-text')$('languageText').title='Dernière génération Groq Free vérifiée · '+String(free.last_model||'');
    }catch(_){
      $('groqFreeStatus').textContent='Groq Free · diagnostic indisponible, aucun résultat confirmé';
    }
    $('setupBanner').classList.toggle('show',!boot.runtime_ready);
    if(!boot.runtime_ready){
      const issues=Array.isArray(boot.issues)?boot.issues:[];
      $('setupIssues').innerHTML=issues.length?issues.map(function(i){return '<li>'+escapeHtml(i.message||i.code||String(i))+'</li>';}).join(''):'<li>Base MySQL ou secrets de production à vérifier.</li>';
      const startup=String(boot.startup_error||'').trim();
      $('setupSummary').textContent=startup
        ? 'Le serveur est en ligne mais le noyau redémarre automatiquement : '+startup
        : 'L’interface est en ligne, mais le noyau attend encore MySQL. Reconnexion automatique en cours.';
    }

    const publicState=await api('/api/dashboard/public');
    const ks=publicState.kernel_status||{};
    const soul=publicState.soul||{};
    try{renderLanguageProgress(await api('/api/language/progress'));}catch(_){renderLanguageProgress({status:'unavailable'});}

    try{
      const capabilities=await api('/api/capabilities');
      const language=(capabilities&&capabilities.language)||{};
      const languageReady=Boolean(language.ready);
      const nativeDialogueReady=Boolean(language.native_dialogue_ready||(capabilities&&capabilities.cognition&&capabilities.cognition.ready));
      $('languageDot').className='live-dot '+(languageReady||nativeDialogueReady?'good':'bad');
      if(languageReady){
        const provider=String(language.provider||language.last_backend||'modèle libre');
        $('languageText').textContent='Français · modèle libre';
        $('languageText').title='Faculté linguistique française active · '+provider+' · réponses non scriptées';
      }else if(nativeDialogueReady){
        $('languageDot').className='live-dot warn';
        const strict=String(language.mode||'')==='natural-language-unavailable';
        $('languageText').textContent=strict?'Français · indisponible':'Français · dégradé';
        $('languageText').title=strict
          ? String(language.setup_hint || 'Aucun modèle libre disponible : vérifier /api/ai/runtime.') + ' AURA refuse de simuler une conversation pré-écrite tant que le modèle manque.'
          : 'La faculté de langue libre est indisponible : mode de secours explicitement activé.';
      }else{
        $('languageText').textContent='Français · indisponible';
        $('languageText').title=String(language.last_error||'Faculté linguistique et noyau conversationnel indisponibles.');
      }

      const voice=(capabilities&&capabilities.voice)||{};
      const voiceReady=Boolean(voice.ready);
      $('voiceDot').className='live-dot '+(voiceReady?'good':'warn');
      if(voice.fabric_ready){
        $('voiceText').textContent='Mairaiy · Aoede';
        $('voiceText').title='Voix Mairaiy historique · Gemini TTS · Aoede · fr-fr';
      }else if(voice.runtime_ready){
        $('voiceText').textContent='Mairaiy · Studio';
        $('voiceText').title='Voix Mairaiy via Quantic Studio · Gemini Aoede';
      }else{
        $('voiceText').textContent='Mairaiy · à configurer';
        const cloudReason=String(voice.cloud_reason||'');
        const reasonLabel=cloudReason==='free-tier-unconfirmed'
          ? 'Aoede bloquée par le garde-fou zéro-coût : niveau gratuit Gemini non confirmé.'
          : cloudReason==='missing-api-key'
            ? 'Clé Gemini TTS absente sur AURA Cloud.'
            : String(voice.fabric_reason||'Voix Aoede indisponible · aucun autre timbre autorisé');
        $('voiceText').title=reasonLabel;
      }
      // The founder explicitly chose a separate zero-euro voice; never label it Aoede.
      if(localVoiceOptIn){
        const localReady=Boolean(localFrenchVoice());
        $('voiceDot').className='live-dot '+(localReady?'good':'warn');
        $('voiceText').textContent=localReady?'AURA · voix locale 0 €':'AURA · voix locale absente';
        $('voiceText').title='Voix française installée dans le navigateur; aucune requête TTS externe.';
      }
    }catch(_){
      $('voiceDot').className='live-dot';
      $('voiceText').textContent='Mairaiy · diagnostic';
    }

    const evolution=publicState.evolution||{};
    const phase=String(evolution.phase||'');
    const local=Boolean(evolution.local_worker_online);
    const active=Boolean(evolution.enabled);
    $('evolutionDot').className='live-dot '+(active?'good':'');
    $('evolutionText').textContent=local?'Évolution · Phase 2':'Évolution · Cloud';
    $('evolutionText').title=phase;

    const commandStatus=publicState.command||null;
    $('railMissions').textContent=commandStatus?.enabled
      ? (commandStatus?.running?'Missions en cours':'Orchestration activée')
      : 'Missions en veille';
    const curiosityStatus=publicState.curiosity||null;
    const scoutStatus=publicState.scout||null;

    metric('energy',soul.energy,boot.runtime_ready);
    metric('curiosity',soul.curiosity,boot.runtime_ready);
    metric('pressure',soul.pressure,boot.runtime_ready);
    metric('continuity',soul.continuity,boot.runtime_ready);
    metric('introspection',soul.introspection,boot.runtime_ready);
    metric('reactivity',soul.reactivity,boot.runtime_ready);

    const organism=(ks&&ks.organism)||(soul&&soul.organism)||{};
    renderEmotion(organism);
    if(livingScene)livingScene.organism=organism;
    $('organismMood').textContent=(organism.mood||'calme')+' · '+((organism.habitat&&organism.habitat.last_activity_label)||organism.active_intention||'présence');
    const mood=String(organism.mood||'calme');
    const moodColors={calme:'#9f78ff',claire:'#6da7ff',curieuse:'#59e0ef',lumineuse:'#ffc96a',tendue:'#ff758d',fatiguée:'#9a8cae',fragile:'#d18cff','préoccupée':'#ff9c8c'};
    $('organismDot').style.background=moodColors[mood]||'#9f78ff';
    $('organismDot').style.boxShadow='0 0 13px '+(moodColors[mood]||'#9f78ff');
    setLive(true,boot.runtime_ready?'En ligne · '+mood:'En ligne · configuration');
    $('chatState').textContent=boot.runtime_ready?'Noyau actif · autonomie visible':'Diagnostic';

    const attention=publicState.attention||null;
    $('dominantThought').textContent=(attention&&attention.focus_statement?attention.focus_statement:'Observation autonome du système.')+'\n\nÉtat : '+(organism.mood||'calme')+' · intention organique : '+(organism.active_intention||'observer');
    const continuity=ks.continuity||{};
    const continuityState=continuity.state||{};
    const lastAutonomous=continuityState.last_autonomous_reflection_at?fmtDate(continuityState.last_autonomous_reflection_at)+' '+fmtTime(continuityState.last_autonomous_reflection_at):'pas encore';
    $('continuityState').textContent='Continuité autonome : '+(continuity.enabled?'active':'inactive')
      +' · dernière réflexion : '+lastAutonomous
      +' · '+(continuityState.unfinished_work?'travail inachevé suivi':'auto-réévaluation')
      +(continuityState.last_reason?' · raison : '+continuityState.last_reason:'');
    lastSoul=Object.assign({},soul);

    if(boot.runtime_ready){
      const intentions=publicState.intentions||[];
      const lessons=publicState.lessons||[];
      const activity=publicState.activity||[];
      const work=publicState.work||[];
      renderIntentions(intentions);
      renderLessons(lessons);
      renderActivity(activity);
      renderWork(work);
      renderMap(attention);
      renderCommandCenter(commandStatus,work,attention);
      renderPortfolio(commandStatus);
      renderReceipts(commandStatus);
      renderCuriosity(curiosityStatus);
      renderScout(scoutStatus);
    }else{
      $('intentList').innerHTML='<div class="empty">Noyau en démarrage.</div>';
      $('memoryList').innerHTML='<div class="empty">Noyau en démarrage.</div>';
      $('activityList').innerHTML='<div class="empty">Noyau en démarrage.</div>';
      $('workList').innerHTML='<div class="empty">Noyau en démarrage.</div>';
      renderCommandCenter(commandStatus,[],null);
      renderPortfolio(commandStatus);
      renderReceipts(commandStatus);
      renderCuriosity(curiosityStatus);
      renderScout(scoutStatus);
    }
  }catch(error){
    setLive(false,'Indisponible');
    $('chatState').textContent='Noyau inaccessible · vérifier la connexion';
  }
}
// Zero-euro emergency voice: installed French voice on the user's device only.
// This is NOT the historical Mairaiy / Aoede voice. It is never sent to a provider.
function localFrenchVoice(){
  const synth=window.speechSynthesis;
  if(!synth || typeof window.SpeechSynthesisUtterance !== 'function') return null;
  const voices=(synth.getVoices()||[]).filter(function(voice){
    return voice && voice.localService === true && /^fr(?:-|$)/i.test(voice.lang||'');
  });
  voices.sort(function(a,b){
    function score(voice){
      const name=String(voice.name||'');
      return (/^fr-FR$/i.test(voice.lang||'')?20:0)+(/natural|neural/i.test(name)?10:0);
    }
    return score(b)-score(a);
  });
  return voices[0] || null;
}
function stopLocalFrenchVoice(){
  localVoiceGeneration++;
  if(window.speechSynthesis){try{window.speechSynthesis.cancel();}catch(_){}}
}
function updateLocalVoiceButton(){
  const button=$('localVoiceBtn');
  if(!button)return;
  const ready=Boolean(localFrenchVoice());
  button.textContent=localVoiceOptIn?'Voix locale : ON':'Voix locale : OFF';
  button.setAttribute('aria-pressed',localVoiceOptIn?'true':'false');
  button.title=ready
    ? 'Voix française installée sur cet appareil, 0 €. Secours différent d’Aoede.'
    : 'Aucune voix française hors ligne détectée sur cet appareil.';
}
function spokenFrenchText(text){
  return String(text||'')
    .replace(/\x60\x60\x60[\s\S]*?\x60\x60\x60/g,' Un extrait de code est affiché. ')
    .replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g,'$1')
    .replace(/https?:\/\/\S+/g,' un lien ')
    .replace(/[*#_~\x60]/g,'')
    .replace(/[\[\]{}]/g,' ')
    .replace(/\s+/g,' ').trim().slice(0,3200);
}
function spokenFrenchChunks(text,maxSize){
  const tokens=spokenFrenchText(text).match(/\S+\s*/g)||[];
  const chunks=[];let current='';
  const max=Math.max(80,Math.min(220,Number(maxSize)||170));
  for(const token of tokens){
    if(current.length+token.length>max && current){
      chunks.push(current.trim());current='';
    }
    if(token.length>max){
      for(let i=0;i<token.length;i+=max)chunks.push(token.slice(i,i+max));
    }else current+=token;
  }
  if(current.trim())chunks.push(current.trim());
  return chunks;
}
async function speakLocalFrench(text){
  const synth=window.speechSynthesis;
  const voice=localFrenchVoice();
  if(!synth || !voice)throw new Error('Aucune voix française installée hors ligne. Ajoute une voix française dans Windows puis recharge cette page.');
  const chunks=spokenFrenchChunks(text,170);
  if(!chunks.length)throw new Error('Aucun texte lisible à prononcer.');
  const generation=++localVoiceGeneration;
  try{synth.cancel();}catch(_){}
  document.body.classList.add('aura-speaking');
  $('voiceText').textContent='AURA · voix locale (secours)';
  try{
    for(const textChunk of chunks){
      if(generation!==localVoiceGeneration)return;
      await new Promise(function(resolve,reject){
        const utterance=new window.SpeechSynthesisUtterance(textChunk);
        utterance.voice=voice;
        utterance.lang=voice.lang||'fr-FR';
        utterance.rate=0.98;
        utterance.pitch=1;
        utterance.volume=1;
        utterance.onend=resolve;
        utterance.onerror=function(event){
          reject(new Error('Lecture locale interrompue : '+String(event&&event.error||'inconnue')));
        };
        synth.speak(utterance);
      });
    }
  }finally{
    if(generation===localVoiceGeneration){
      document.body.classList.remove('aura-speaking');
      $('voiceText').textContent='AURA · secours local 0 €';
    }
  }
}
function primeVoice(){
  if(voicePrimed)return;
  voicePrimed=true;
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(AC){
      voiceAudioContext=voiceAudioContext||new AC();
      const resumed=voiceAudioContext.resume();
      if(resumed&&resumed.catch)resumed.catch(function(){});
    }
  }catch(_){voiceAudioContext=null;}
  try{
    if(!voicePlayer)voicePlayer=new Audio();
    voicePlayer.preload='auto';
    voicePlayer.muted=false;
  }catch(_){
    voicePlayer=null;
  }
}
async function playVoiceSegment(payload){
  if(!payload||!payload.audio_base64)throw new Error('Segment audio absent');
  const raw=atob(payload.audio_base64);
  const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);

  if(voiceAudioContext){
    try{
      if(voiceAudioContext.state==='suspended')await voiceAudioContext.resume();
      const copy=bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);
      const decoded=await voiceAudioContext.decodeAudioData(copy);
      await new Promise(function(resolve,reject){
        try{
          const source=voiceAudioContext.createBufferSource();
          source.buffer=decoded;
          source.connect(voiceAudioContext.destination);
          source.onended=resolve;
          source.start(0);
        }catch(error){reject(error);}
      });
      return;
    }catch(error){
      console.warn('Web Audio Mairaiy indisponible; essai lecteur HTML5.',error);
    }
  }

  await new Promise(function(resolve,reject){
    try{
      const blob=new Blob([bytes],{type:payload.mime_type||'audio/wav'});
      const url=URL.createObjectURL(blob);
      const audio=voicePlayer||new Audio();
      voicePlayer=audio;
      audio.pause();audio.muted=false;audio.src=url;
      let closed=false;
      const finish=function(ok,error){
        if(closed)return;closed=true;
        URL.revokeObjectURL(url);
        if(ok)resolve();else reject(error||new Error('Lecture audio impossible'));
      };
      audio.onended=function(){finish(true);};
      audio.onerror=function(){finish(false,new Error('Lecture du segment Mairaiy impossible'));};
      const play=audio.play();
      if(play&&play.catch)play.catch(function(error){
        const blocked=error&&error.name==='NotAllowedError'
          ? new Error('Le navigateur bloque le son. Clique dans la page puis renvoie un message.')
          : error;
        finish(false,blocked);
      });
    }catch(error){reject(error);}
  });
}
async function speakAura(text,ticket){
  if(!text)return;
  // Explicitly chosen local mode: never send the text to a billable TTS API.
  // Aoede remains the primary/default voice when local mode is disabled.
  if(localVoiceOptIn){
    try{
      await speakLocalFrench(text);
      $('chatState').textContent='Lecture locale française (0 €), différente d’Aoede.';
    }catch(error){
      $('chatState').textContent=String(error&&error.message||error).slice(0,170);
      $('voiceText').textContent='AURA · voix locale indisponible';
    }
    return;
  }
  try{
    if(!ticket)throw new Error('Ticket vocal absent');
    const out=await api('/api/voice/speak',{
      method:'POST',
      body:JSON.stringify({text:text,ticket:ticket,context:'aura-cloud-chat',rate:1,pitch:1,volume:1})
    });
    const segments=Array.isArray(out&&out.segments)&&out.segments.length?out.segments:[out];
    if(!segments.length||!segments[0]||!segments[0].audio_base64)throw new Error('Audio Mairaiy absent');
    document.body.classList.add('aura-speaking');
    for(let i=0;i<segments.length;i++){
      $('voiceText').textContent=segments.length>1?'Mairaiy · '+(i+1)+'/'+segments.length:'Mairaiy · parle';
      await playVoiceSegment(segments[i]);
    }
    document.body.classList.remove('aura-speaking');
    $('voiceText').textContent='Mairaiy · en ligne';
  }catch(error){
    document.body.classList.remove('aura-speaking');
    $('voiceText').textContent='Mairaiy · indisponible';
    $('voiceText').title='Aoede indisponible · la voix locale 0 € reste facultative';
    const reason=String(error&&error.message||'');
    $('chatState').textContent=reason.includes('free-tier-unconfirmed')
      ? 'Réponse texte prête · Aoede bloquée par le garde-fou zéro-coût'
      : (reason.includes('bloque le son')
        ? reason
        : 'Réponse texte prête · voix Mairaiy Aoede indisponible');
    console.error('Mairaiy Aoede indisponible; changement de timbre interdit',error);
  }
}
// Never render an unavailable model as a person answering "lu".
let chatBusy=false;
let lastChatFailure='';
function addChatServiceNotice(message){
  const safe=escapeHtml(String(message||'').slice(0,200));
  $('messages').insertAdjacentHTML('beforeend',
    '<div class="msg service-msg" role="status"><strong class="service-card-title">Français naturel indisponible</strong>'+
    '<span>'+safe+'</span><div class="service-actions">'+
    '<button type="button" data-aura-action="retry-language">Réessayer le message</button>'+
    '<button type="button" data-aura-action="diagnose-language">Voir le diagnostic</button>'+
    '</div></div>');
  $('messages').scrollTop=$('messages').scrollHeight;
}
async function sendMessage(text,options){
  text=String(text||'').trim();if(!text||chatBusy)return;
  chatBusy=true;
  try{primeVoice();}catch(_){}
  const repeated=Boolean(options&&options.repeat);
  const button=$('send');
  if(button)button.disabled=true;
  if(!repeated){
    $('messages').insertAdjacentHTML('beforeend',
      '<div class="msg user"><span class="who">VOUS</span>'+escapeHtml(text)+'</div>');
    $('message').value='';
  }
  const pending=document.createElement('div');
  pending.className='msg service-msg';
  pending.textContent='Recherche d’une réponse française vérifiée…';
  pending.setAttribute('role','status');
  $('messages').appendChild(pending);
  $('messages').scrollTop=$('messages').scrollHeight;
  try{
    const out=await api('/api/chat',{method:'POST',
      body:JSON.stringify({text:text,author:'Utilisateur'})});
    pending.remove();
    const answer=String(out?.answer||'').trim();
    if(out?.language_unavailable || out?.response_kind==='model-unavailable'
      || !out?.ok || !answer){
      lastChatFailure=text;
      addChatServiceNotice('Aucun modèle ne produit actuellement de réponse. Le message est conservé pour un nouvel essai. Aucun dialogue artificiel ajouté.');
      void refreshEnginePanel();
      $('chatState').textContent='Modèle français indisponible';
      return;
    }
    lastChatFailure='';
    const factualAct=['report_current_activity','clarify_real_activity',
      'clarify_blocker_evidence','request_verifiable_help','explain_previous_claim']
      .includes(String(out?.act||''));
    const unverified=factualAct && out?.activity_evidence?.execution_verified!==true;
    const authorLabel=out?.nucleus_verbalization_validated
      ? (unverified ? 'AURA · formulation contrôlée · statut non vérifié'
        : 'AURA · formulation du noyau contrôlée')
      : 'AURA · réponse générée (contrat non attesté)';
    $('messages').insertAdjacentHTML('beforeend',
      '<div class="msg aura"><span class="who">'+authorLabel+'</span>'+escapeHtml(answer)+'</div>');
    $('messages').scrollTop=$('messages').scrollHeight;
    void speakAura(answer,out.voice_ticket||'');
    void refresh();
  }catch(error){
    pending.remove();
    lastChatFailure=text;
    addChatServiceNotice('Échec technique : '+String(error?.message||'').slice(0,135));
    $('chatState').textContent='Erreur du service de conversation';
  }finally{
    chatBusy=false;
    if(button)button.disabled=false;
  }
}
$('messages').addEventListener('click',function(event){
  const target=event.target?.closest?.('[data-aura-action]');
  if(!target)return;
  const action=target.getAttribute('data-aura-action');
  if(action==='retry-language'&&lastChatFailure){
    void sendMessage(lastChatFailure,{repeat:true});
  }else if(action==='diagnose-language'){
    void refreshEnginePanel();
    $('enginePanel')?.scrollIntoView({behavior:'smooth',block:'nearest'});
  }
});
// AURA Trading Lab: explicit paper backtest only. No live orders or broker credentials.
function tradingEuro(number){
  return Number(number||0).toLocaleString('fr-FR',{style:'currency',currency:'EUR',maximumFractionDigits:2});
}
function renderTradingSimulation(report){
  if(!report||report.status!=='simulation_only'||report.real_money_traded!==false)
    throw new Error('Rapport de trading fictif invalide');
  const pnl=Number(report.virtual_pnl_eur||0);
  $('tradePnl').textContent=(pnl>0?'+':'')+tradingEuro(pnl);
  $('tradePnl').style.color=pnl<0?'#ff9caa':pnl>0?'#9cf8d4':'#f3fffc';
  $('tradeDrawdown').textContent=Number(report.max_drawdown_pct||0).toFixed(2)+' %';
  $('tradeCount').textContent=String(report.closed_trades||0);
  $('tradeStatus').textContent='SIMULATION · '+String(report.price_candles||0)+
    ' bougies closes · '+String(report.requested_pair||'')+' · '+
    'Résultat virtuel, jamais un gain encaissé.';
  const series=Array.isArray(report.equity_curve)?report.equity_curve:[];
  if(series.length>=2){
    const values=series.map(x=>Number(x.equity_eur)||0);
    const low=Math.min(...values),high=Math.max(...values);
    const diff=Math.max(1,high-low);
    const d=values.map((v,i)=>{
      const px=10+(380*i/Math.max(1,values.length-1));
      const py=76-65*(v-low)/diff;
      return (i?'L':'M')+px.toFixed(1)+' '+py.toFixed(1);
    }).join(' ');
    $('tradeChartPath').setAttribute('d',d);
    $('tradeChartPath').setAttribute('stroke',pnl>=0?'#78ddc8':'#fc9ba2');
  }
  const events=Array.isArray(report.trades)?report.trades.slice(-6).reverse():[];
  $('tradeTrades').innerHTML=events.map(event=>
    '<div class="trade-event"><span>'+escapeHtml(event.type==='buy'?'ACHAT FICTIF':'VENTE FICTIVE')+
    ' · '+escapeHtml(new Date(event.time*1000).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))+
    '</span><span>'+escapeHtml(event.type==='buy'?tradingEuro(event.invested_eur):tradingEuro(event.pnl_eur))+'</span></div>'
  ).join('');
}
let tradeLastReportStamp='';
async function refreshAutoPaperStatus(){
  try{
    const status=await api('/api/trading/paper/status');
    if(status&&status.latest&&status.latest.checked_at!==tradeLastReportStamp){
      tradeLastReportStamp=status.latest.checked_at;
      renderTradingSimulation(status.latest);
      $('tradeStatus').textContent='Surveillance automatique toutes les 6 h · dernier calcul : '+
        new Date(status.last_checked_at).toLocaleString('fr-FR')+
        ' · capital et gains totalement fictifs.';
    } else if(status?.running) {
      $('tradeStatus').textContent='Surveillance automatique : analyse des prix publics en cours…';
    } else if(status?.last_error&&!status.latest) {
      $('tradeStatus').textContent='Données publiques indisponibles : '+String(status.last_error).slice(0,120);
    }
  }catch(error){
    if(error.status===401||error.status===403){
      $('tradeStatus').textContent='Connexion privée requise pour suivre les simulations automatiques.';
    }
  }
}
$('tradeBacktest').onclick=async function(){
  const button=$('tradeBacktest');
  button.disabled=true;button.textContent='Analyse…';
  $('tradeStatus').textContent='Chargement des cours publics et simulation hors marché réel…';
  try{
    const result=await api('/api/trading/paper/backtest',{
      method:'POST',body:JSON.stringify({pair:$('tradePair').value}),
    });
    renderTradingSimulation(result);
  }catch(error){
    $('tradeStatus').textContent=error.status===401||error.status===403
      ?'Connexion privée AURA requise pour la simulation.'
      :'Simulation indisponible : '+String(error.message||error).slice(0,170);
  }finally{button.disabled=false;button.textContent='Tester la stratégie';}
};
// Private actions use the existing HttpOnly AURA session; no token storage.
let ownerSessionAuthenticated=false;
async function refreshOwnerSession(){
  try{
    const state=await api('/api/auth/session');
    ownerSessionAuthenticated=state?.authenticated===true;
  }catch(_){ownerSessionAuthenticated=false;}
  $('ownerSessionStatus').textContent=ownerSessionAuthenticated
    ?'Session propriétaire active · actions privées disponibles.'
    :'Accès propriétaire requis pour les missions et les audits.';
  $('ownerConnectRow').hidden=ownerSessionAuthenticated;
  $('ownerDisconnect').hidden=!ownerSessionAuthenticated;
  $('autonomyRun').disabled=!ownerSessionAuthenticated;
  $('auditRun').disabled=!ownerSessionAuthenticated;
  return ownerSessionAuthenticated;
}
$('ownerConnect').onclick=async function(){
  const input=$('ownerSessionToken');
  const secret=String(input.value||'').trim();
  if(!secret){$('ownerSessionStatus').textContent='Saisir la clé privée AURA.';return;}
  $('ownerConnect').disabled=true;
  try{
    const result=await api('/api/auth/session',{
      method:'POST',body:JSON.stringify({token:secret}),
    });
    if(!result?.authenticated)throw new Error('Connexion propriétaire non validée');
    input.value='';
    await refreshOwnerSession();
    void refreshRevenueReadiness();
  }catch(error){
    $('ownerSessionStatus').textContent='Connexion refusée : '+String(error?.message||error).slice(0,135);
  }finally{
    input.value='';
    $('ownerConnect').disabled=false;
  }
};
$('ownerDisconnect').onclick=async function(){
  try{await api('/api/auth/session',{method:'DELETE'});}catch(_){}
  ownerSessionAuthenticated=false;
  await refreshOwnerSession();
  $('revenueMode').textContent='ACCÈS PRIVÉ REQUIS';
};
// Founder's operator. Real execution is reported distinctly from a plan-only result.
$('autonomyRun').onclick=async function(){
  const task=String($('autonomyTask').value||'').trim();
  if(task.length<8){
    $('autonomyStatus').textContent='Décrire une mission concrète avant de la lancer.';
    return;
  }
  const button=$('autonomyRun');button.disabled=true;
  $('autonomyResult').textContent='';
  $('autonomyStatus').textContent='Mission soumise au moteur AURA. Aucune permission de risque supplémentaire accordée.';
  try{
    const result=await api('/api/kernel/operator',{
      method:'POST',
      body:JSON.stringify({task:task.slice(0,1500),allowed_risks:[]}),
    });
    const executed=result?.executed===true;
    const mode=String(result?.execution_mode||'indéterminé');
    $('autonomyStatus').textContent=executed
      ?'Exécution signalée par AURA ('+mode+'). Examiner les preuves et résultats ci-dessous.'
      :'Aucune exécution confirmée ('+mode+'). Seul un plan ou un refus a été retourné.';
    const details=executed?(result?.result||result):(result?.plan||result?.error||result);
    $('autonomyResult').textContent=typeof details==='string'
      ?details.slice(0,3000) :JSON.stringify(details,null,2).slice(0,3000);
  }catch(error){
    $('autonomyStatus').textContent=error.status===401||error.status===403
      ?'Connexion administrateur AURA requise pour exécuter une mission.'
      :'Mission non réalisée : '+String(error?.message||error).slice(0,170);
  }finally{button.disabled=false;}
};
// Genuine, bounded AURA audit. Revenue is "not connected" until verified receipts.
let auditReport=null;
function renderAuditReport(report){
  if(!Array.isArray(report?.checks)||!report.checked_at)throw new Error('Format de rapport invalide');
  $('auditResults').innerHTML=report.checks.map(check=>
    '<div class="audit-check"><span>'+escapeHtml(check.detail||check.id||'Contrôle')+
    '</span><strong class="'+(check.status==='pass'?'good':'review')+'">'+
    (check.status==='pass'?'CONFORME':'À EXAMINER')+'</strong></div>').join('');
  $('auditState').textContent='Analyse effectuée · '+report.pass_count+' contrôles conformes / '+
    report.review_count+' points à examiner · '+report.duration_ms+' ms · HTML initial uniquement.';
  $('auditExport').disabled=false;
  auditReport=report;
}
async function refreshRevenueReadiness(){
  try{
    const state=await api('/api/revenue/readiness');
    $('revenueVerified').textContent=state.revenue_source==='none-connected'?'Non connectées':'À vérifier';
    $('revenueSales').textContent=state.payment_processing_connected?'À vérifier':'Non activées';
    $('revenueMode').textContent=state.audit_available?'AUDIT OPÉRATIONNEL':'À CONFIGURER';
  }catch(error){
    $('revenueMode').textContent='ACCÈS PRIVÉ REQUIS';
    $('revenueVerified').textContent='Données non disponibles';
    $('revenueSales').textContent='À configurer';
  }
}
$('auditRun').onclick=async function(){
  const button=$('auditRun');
  const url=String($('auditUrl').value||'').trim();
  if(!/^https:\/\/[^\s]+\/$/i.test(url)){
    $('auditState').textContent='Indiquer une URL HTTPS publique de page d’accueil avec le / final, sans paramètres.';
    return;
  }
  button.disabled=true;
  $('auditExport').disabled=true;
  $('auditResults').innerHTML='';
  $('auditState').textContent='Audit réel en cours. Aucun service payant utilisé.';
  auditReport=null;
  try{
    const report=await api('/api/revenue/audit/preview',{method:'POST',
      body:JSON.stringify({url})});
    renderAuditReport(report);
  }catch(error){
    $('auditState').textContent=error.status===401||error.status===403
      ?'Connexion privée administrateur nécessaire pour auditer un site.'
      :'Audit impossible : '+String(error.message||error).slice(0,180);
  }finally{button.disabled=false;}
};
$('auditExport').onclick=function(){
  if(!auditReport)return;
  const report=auditReport;
  const lines=[
    '# AURA · Audit technique de la page d’accueil',
    'Site : '+report.url,
    'Date : '+report.checked_at,
    'Statut HTTP : '+report.status_code,
    'Contrôles conformes : '+report.pass_count,
    'Points à examiner : '+report.review_count,'',
    '## Observations',
    ...report.checks.map(check=>'- ['+(check.status==='pass'?'OK':'REVOIR')+'] '+String(check.detail||'')),
    '',
    'Limites : '+String(report.scope||''),
    'Analyse automatisée informative, non une certification ni une promesse commerciale.',
  ];
  const blob=new Blob([lines.join('\n')],{type:'text/markdown;charset=utf-8'});
  const obj=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=obj;a.download='aura-audit-'+new Date().toISOString().slice(0,10)+'.md';
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(obj);
};
$('send').onclick=function(){sendMessage($('message').value);};
$('message').addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage($('message').value);}});
document.querySelectorAll('.quick button').forEach(function(btn){btn.onclick=function(){sendMessage(btn.getAttribute('data-prompt'));};});
$('refreshMap').onclick=refresh;
$('modeBtn').onclick=refresh;
$('engineRefresh').onclick=refreshEnginePanel;
$('engineStart').onclick=async function(){
  const button=$('engineStart');
  button.disabled=true;
  $('engineDescription').textContent='Demande de démarrage local en cours. Cette action ne télécharge rien et ne contacte aucune API payante.';
  try{
    const response=await api('/api/language/embedded/start',{
      method:'POST',body:JSON.stringify({}),
    });
    $('engineDescription').textContent=response.already_ready
      ?'Modèle déjà vérifié.' : 'Démarrage demandé. AURA contrôle la génération réelle de texte.';
  }catch(error){
    $('engineDescription').textContent=error.status===401||error.status===403
      ?'Se connecter en administrateur AURA pour démarrer le moteur. Le public ne peut pas lancer de processus.'
      :String(error.message||'Échec du démarrage').slice(0,260);
  }finally{
    await refreshEnginePanel();
  }
};
$('localVoiceBtn').onclick=function(){
  if(localVoiceOptIn){
    localVoiceOptIn=false;
    stopLocalFrenchVoice();
    try{localStorage.removeItem('aura_local_voice_opt_in');}catch(_){}
    $('chatState').textContent='Voix de secours locale désactivée.';
    updateLocalVoiceButton();
    return;
  }
  if(!localFrenchVoice()){
    $('chatState').textContent='Aucune voix française installée hors ligne n’est disponible dans ce navigateur.';
    updateLocalVoiceButton();
    return;
  }
  localVoiceOptIn=true;
  try{localStorage.setItem('aura_local_voice_opt_in','1');}catch(_){}
  updateLocalVoiceButton();
  void speakLocalFrench('Bonjour. Je suis AURA. La voix française locale de secours est activée.')
    .catch(function(error){$('chatState').textContent=String(error&&error.message||error).slice(0,170);});
};
if(window.speechSynthesis && 'onvoiceschanged' in window.speechSynthesis){
  window.speechSynthesis.addEventListener('voiceschanged',updateLocalVoiceButton);
}
updateLocalVoiceButton();
$('voiceBtn').onclick=function(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){$('message').placeholder='Reconnaissance vocale non disponible sur ce navigateur.';return;}
  const rec=new SR();rec.lang='fr-FR';rec.interimResults=false;rec.maxAlternatives=1;
  rec.onresult=function(e){$('message').value=e.results[0][0].transcript;};
  rec.start();
};
updateClock();refresh();void refreshOwnerSession();void refreshRevenueReadiness();void refreshAutoPaperStatus();setInterval(refreshAutoPaperStatus,120000);try{initLivingAuraScene();}catch(error){console.warn('AURA visual scene disabled; live data remains active.',error);}setInterval(updateClock,1000);setInterval(refresh,8000);
`;
