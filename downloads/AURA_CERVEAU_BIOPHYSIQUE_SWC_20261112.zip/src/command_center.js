import { createHash, randomUUID } from 'node:crypto';
import { config } from './config.js';
import { one, query } from './db.js';
import { clamp } from './policy.js';
import { LongHorizonMissionEngine } from './long_horizon.js';
import { classifyInitiativeResult } from './outcome_truth.js';

const now = () => new Date().toISOString();

function initiativeSemanticKey(domain, kind, title, objective = '') {
  const normalize = (value) => String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('fr-FR')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return [
    normalize(domain),
    normalize(kind),
    normalize(title).slice(0, 240),
    normalize(objective).slice(0, 500),
  ].join('|');
}

const DEFAULT_SERVICES = [
  {
    id: 'aura',
    name: 'AURA',
    kind: 'core',
    objective: 'Maintenir le noyau AURA disponible, cohérent, apprenant et capable d’agir.',
    criticality: 1,
  },
  {
    id: 'aura-runtime',
    name: 'AURA Runtime',
    kind: 'execution-plane',
    objective: 'Fournir à AURA les capacités locales universelles : modèles, outils machine, opérateur, voix/image, sandbox et calcul local.',
    criticality: 0.98,
  },
  {
    id: 'quantic-studio',
    name: 'Quantic Studio',
    kind: 'product',
    objective: 'Maintenir le studio de diffusion vivant, observable et pilotable par AURA.',
    criticality: 0.84,
  },
  {
    id: 'identity-vault',
    name: 'Identity Vault',
    kind: 'product',
    objective: 'Maintenir le coffre d’identité Quantic disponible, portable et sûr.',
    criticality: 0.93,
  },
  {
    id: 'horizon',
    name: 'HORIZON',
    kind: 'intelligence',
    objective: 'Apporter des signaux vérifiés et du contexte prédictif sans transformer les hypothèses en faits.',
    criticality: 0.86,
  },
  {
    id: 'quantic-news',
    name: 'Quantic News',
    kind: 'information',
    objective: 'Transformer les informations utiles en contexte exploitable pour l’écosystème.',
    criticality: 0.72,
  },
  {
    id: 'zoon',
    name: 'ZOON',
    kind: 'social',
    objective: 'Maintenir la couche sociale de Quantic Sillage exploitable, observable et cohérente.',
    criticality: 0.68,
  },
  {
    id: 'quantic-mail',
    name: 'Quantic Mail',
    kind: 'communication',
    objective: 'Maintenir une messagerie souveraine et exploitable par l’écosystème.',
    criticality: 0.76,
  },
  {
    id: 'quantic-glide',
    name: 'Quantic Glide',
    kind: 'browser',
    objective: 'Fournir un accès Web privé, portable et compatible à l’écosystème.',
    criticality: 0.72,
  },
  {
    id: 'providence',
    name: 'Providence',
    kind: 'knowledge',
    objective: 'Transformer les documents et informations en connaissances utilisables.',
    criticality: 0.66,
  },
  {
    id: 'quantic-os',
    name: 'Quantic OS',
    kind: 'platform',
    objective: 'Servir de couche système cohérente aux produits Quantic Sillage.',
    criticality: 0.74,
  },
];

const ACTIVE_STATUSES = new Set(['queued', 'running', 'waiting']);

function safeOperationalError(value, limit = 5000) {
  return String(value?.message || value || '')
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, 'Bearer [REDACTED]')
    .replace(/\b(?:sk-|AIza)[A-Za-z0-9_-]{12,}\b/g, '[REDACTED]')
    .replace(/\bgh[opsu]_[A-Za-z0-9_]{16,}\b/g, '[REDACTED]')
    .replace(/\bgithub_pat_[A-Za-z0-9_]{16,}\b/g, '[REDACTED]')
    .replace(/([?&](?:key|token|api_key|access_token)=)[^&\s]+/gi, '$1[REDACTED]')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, Math.max(64, Number(limit || 5000)));
}

const BAD_SERVICE_STATES = new Set(['degraded', 'offline', 'error', 'unhealthy', 'stale']);
const BAD_WORKFLOW_CONCLUSIONS = new Set([
  'failure',
  'timed_out',
  'action_required',
  'startup_failure',
]);

export function productHeartbeatHealth(row = {}, {
  nowMs = Date.now(),
  staleSeconds = config.commandCenterProductStaleSeconds,
  offlineSeconds = config.commandCenterProductOfflineSeconds,
} = {}) {
  const state = String(row.state || 'unknown').toLowerCase();
  const observedAt = Date.parse(String(row.last_observed_at || ''));
  if (!Number.isFinite(observedAt)) {
    return { state, next_state: state, age_seconds: null, transition: false };
  }
  const ageSeconds = Math.max(0, Math.round((Number(nowMs) - observedAt) / 1000));
  let nextState = state;
  if (!['error','unhealthy','degraded','offline'].includes(state)) {
    if (ageSeconds >= Number(offlineSeconds)) nextState = 'offline';
    else if (ageSeconds >= Number(staleSeconds) && state === 'online') nextState = 'stale';
  }
  return {
    state,
    next_state: nextState,
    age_seconds: ageSeconds,
    transition: nextState !== state,
  };
}
const REPO_SERVICE_MAP = new Map([
  ['xdsawyerlol/auralive', 'aura'],
  ['xdsawyerlol/quanticsillage', 'quantic-sillage'],
  ['xdsawyerlol/quanticmail', 'quantic-mail'],
  ['xdsawyerlol/quantic-os', 'quantic-os'],
  ['xdsawyerlol/quantic-browser', 'quantic-glide'],
  ['xdsawyerlol/human-agency-engine', 'providence'],
]);
const REPO_PRODUCT_LABELS = new Map([
  ['xdsawyerlol/auralive', 'AURA'],
  ['xdsawyerlol/quanticsillage', 'Quantic Sillage'],
  ['xdsawyerlol/quanticmail', 'Quantic Mail'],
  ['xdsawyerlol/quantic-os', 'Quantic OS'],
  ['xdsawyerlol/quantic-browser', 'Quantic Glide'],
  ['xdsawyerlol/human-agency-engine', 'Providence'],
]);

export function summarizeWorkflowRuns(rows = []) {
  const ordered = [...rows].sort((a, b) =>
    String(b?.created_at || '').localeCompare(String(a?.created_at || '')));
  const groups = new Map();
  for (const row of ordered) {
    const name = String(row?.name || row?.workflow_id || 'workflow');
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(row);
  }
  return [...groups.entries()].map(([name, history]) => {
    const latest = history[0] || {};
    let failureStreak = 0;
    for (const run of history) {
      if (BAD_WORKFLOW_CONCLUSIONS.has(String(run?.conclusion || '').toLowerCase())) failureStreak += 1;
      else break;
    }
    return {
      name,
      id: Number(latest.id || 0),
      conclusion: String(latest.conclusion || ''),
      status: String(latest.status || ''),
      html_url: String(latest.html_url || ''),
      head_sha: String(latest.head_sha || ''),
      head_branch: String(latest.head_branch || ''),
      run_attempt: Number(latest.run_attempt || 1),
      created_at: String(latest.created_at || ''),
      updated_at: String(latest.updated_at || ''),
      failure_streak: failureStreak,
    };
  });
}

export function repositoryHealth(meta = {}, workflowRuns = []) {
  const workflows = summarizeWorkflowRuns(workflowRuns);
  const failed = workflows.filter((item) =>
    BAD_WORKFLOW_CONCLUSIONS.has(String(item.conclusion || '').toLowerCase()));
  const repeated = failed.filter((item) => item.failure_streak >= 2);
  const pushedAt = Date.parse(String(meta.pushed_at || ''));
  const staleDays = Number.isFinite(pushedAt)
    ? Math.max(0, (Date.now() - pushedAt) / 86_400_000)
    : 0;
  let score = 100;
  score -= Math.min(60, failed.length * 22);
  score -= Math.min(20, repeated.length * 8);
  if (staleDays > 120) score -= 8;
  if (meta.archived) score -= 30;
  score = Math.max(0, Math.min(100, Math.round(score)));
  return {
    score,
    state: failed.length ? 'degraded' : (meta.archived ? 'offline' : 'healthy'),
    workflows,
    failing_workflows: failed,
    repeated_failures: repeated.length,
    stale_days: Math.round(staleDays),
  };
}

function parseJson(value, fallback) {
  try {
    const parsed = JSON.parse(value || '');
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function fingerprint(parts) {
  return createHash('sha256')
    .update(parts.map((item) => String(item || '').trim().toLowerCase()).join('|'))
    .digest('hex')
    .slice(0, 40);
}

function normalizeRisks(value) {
  const source = value instanceof Set ? [...value] : Array.from(value || []);
  return [...new Set(source.map((item) => String(item).trim().toLowerCase()).filter(Boolean))];
}

export function safeGithubChangePath(value) {
  const path = String(value || '').replace(/\\/g, '/').replace(/^\/+/, '').trim();
  if (!path || path.length > 500 || path.includes('..') || path.includes('\0')) return '';
  const lower = path.toLowerCase();
  const basename = lower.split('/').pop() || '';
  if (
    lower === '.env'
    || lower.startsWith('.env.')
    || lower.startsWith('.git/')
    || lower.startsWith('.github/')
    || lower.startsWith('scripts/')
    || lower.startsWith('installer/')
    || lower.startsWith('deploy/')
    || ['dockerfile','docker-compose.yml','docker-compose.yaml','makefile'].includes(lower)
    || ['package.json','package-lock.json','pnpm-lock.yaml','yarn.lock','requirements.txt','requirements-desktop.txt'].includes(basename)
    || /(^|\/)(secrets?|credentials?|tokens?)(\.|\/|$)/i.test(path)
    || /\.(pem|p12|pfx|key|keystore|jks|ps1|sh|bat|cmd)$/i.test(path)
  ) return '';
  return path;
}

function encodeGithubPath(value) {
  return String(value || '').split('/').map((part) => encodeURIComponent(part)).join('/');
}

function githubBranchName(fingerprintValue) {
  return 'aura/change-' + String(fingerprintValue || '').replace(/[^a-z0-9]/gi, '').slice(0, 16).toLowerCase();
}

export function needsExternalEvidence(value) {
  const text = String(value || '').toLowerCase();
  return [
    'marché','marche','concurrent','technolog','documentation',' api ','actualité','actualite',
    'recherche','scientif','benchmark','compatib','version','norme','réglement','reglement',
    'sécurité','securite','performance','prix','licence','standard',
  ].some((token) => text.includes(token));
}

export class CommandCenter {
  static VERSION = 'aura-command-center-v2-long-horizon';

  constructor(
    kernel,
    evolution,
    bridge,
    webSubstrate = null,
    fabric = null,
    dagCompiler = null,
    graphExecutor = null,
    expertBridge = null,
  ) {
    this.kernel = kernel;
    this.evolution = evolution;
    this.bridge = bridge;
    this.webSubstrate = webSubstrate;
    this.fabric = fabric;
    this.dagCompiler = dagCompiler;
    this.graphExecutor = graphExecutor;
    this.expertBridge = expertBridge;
    this.longHorizon = new LongHorizonMissionEngine(kernel);
    this.started = false;
    this.running = false;
    this.timer = null;
    this.warmupTimer = null;
    this.lastCycleAt = '';
    this.lastActionAt = '';
    this.lastFleetPollAt = '';
    this.lastFleetPollMs = 0;
    this.lastDirectorPromotionMs = 0;
    this.fleetSnapshot = [];
    this.lastError = '';
  }

  async dedupeActiveInitiatives() {
    const rows = await query(
      `SELECT * FROM aura_initiatives
       WHERE status IN ('queued','running','waiting')
       ORDER BY
         CASE status WHEN 'running' THEN 0 WHEN 'waiting' THEN 1 ELSE 2 END,
         priority DESC,confidence DESC,updated_at DESC LIMIT 300`,
    );
    const keepers = new Map();
    const duplicates = [];
    for (const row of rows) {
      const key = initiativeSemanticKey(row.domain, row.kind, row.title, row.objective);
      if (!key) continue;
      if (!keepers.has(key)) {
        keepers.set(key, row);
        continue;
      }
      duplicates.push(row);
    }
    const stamp = now();
    for (const row of duplicates) {
      await query(
        `UPDATE aura_initiatives
         SET status='superseded',error='semantic duplicate cleaned by Director Mode',updated_at=?
         WHERE id=? AND status IN ('queued','waiting')`,
        [stamp, row.id],
      );
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [
          row.id,
          'initiative-superseded',
          JSON.stringify({ reason: 'semantic-duplicate', director_mode: true }).slice(0, 30000),
          stamp,
        ],
      );
    }
    return { active: keepers.size, superseded: duplicates.length };
  }

  async init() {
    const stamp = now();
    for (const service of DEFAULT_SERVICES) {
      await query(
        `INSERT INTO aura_command_services(
          id,name,kind,objective,endpoint,repository,criticality,enabled,state,state_detail,
          last_observed_at,metadata,created_at,updated_at
        ) VALUES(?,?,?,?, '', '', ?,1,'unknown','', '', '{}',?,?)
        ON DUPLICATE KEY UPDATE
          name=VALUES(name),
          kind=VALUES(kind),
          objective=IF(objective='' OR objective IS NULL, VALUES(objective), objective),
          criticality=GREATEST(criticality, VALUES(criticality)),
          updated_at=VALUES(updated_at)`,
        [
          service.id,
          service.name,
          service.kind,
          service.objective,
          clamp(service.criticality),
          stamp,
          stamp,
        ],
      );
    }
    await this.dedupeActiveInitiatives();
    await this.longHorizon.init();
  }

  async start() {
    if (this.started) return;
    await this.init();
    this.started = true;
    if (!config.commandCenterEnabled) return;
    const run = () => this.runCycle('autonomous').catch((error) => {
      this.lastError = String(error?.message || error).slice(0, 1000);
    });
    this.warmupTimer = setTimeout(
      run,
      Math.min(120_000, Math.max(15_000, config.commandCenterWarmupSeconds * 1000)),
    );
    this.timer = setInterval(run, config.commandCenterTickSeconds * 1000);
    this.warmupTimer.unref?.();
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    if (this.warmupTimer) clearTimeout(this.warmupTimer);
    this.timer = null;
    this.warmupTimer = null;
    this.started = false;
  }

  get githubToken() {
    return String(config.commandCenterGithubToken || '').trim();
  }

  async github(path, { method = 'GET', body = null } = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), config.commandCenterRequestTimeoutMs);
    try {
      const headers = {
        Accept: 'application/vnd.github+json',
        'User-Agent': 'AURA-Command-Center',
        'X-GitHub-Api-Version': '2022-11-28',
      };
      if (this.githubToken) headers.Authorization = `Bearer ${this.githubToken}`;
      if (body != null) headers['Content-Type'] = 'application/json';
      const response = await fetch(`https://api.github.com${path}`, {
        method,
        headers,
        body: body == null ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
      const text = await response.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
      if (!response.ok) {
        const error = new Error(
          `GitHub ${method} ${path}: ${data?.message || response.status}`,
        );
        error.status = response.status;
        error.data = data;
        throw error;
      }
      return { status: response.status, data };
    } finally {
      clearTimeout(timeout);
    }
  }

  async scanRepository(repository) {
    const repo = String(repository || '').trim();
    if (!repo.includes('/')) return { repository: repo, state: 'error', error: 'nom de dépôt invalide' };
    try {
      const metaResponse = await this.github(`/repos/${repo}`);
      const meta = metaResponse.data || {};
      const branch = String(meta.default_branch || 'main');
      const runsResponse = await this.github(
        `/repos/${repo}/actions/runs?branch=${encodeURIComponent(branch)}&per_page=12`,
      ).catch((error) => {
        if (error?.status === 404) return { data: { workflow_runs: [] } };
        throw error;
      });
      const runs = Array.isArray(runsResponse?.data?.workflow_runs)
        ? runsResponse.data.workflow_runs
        : [];
      const health = repositoryHealth(meta, runs);
      return {
        repository: repo,
        name: String(meta.name || repo.split('/').pop() || repo),
        private: Boolean(meta.private),
        default_branch: branch,
        pushed_at: String(meta.pushed_at || ''),
        html_url: String(meta.html_url || ''),
        archived: Boolean(meta.archived),
        state: health.state,
        health_score: health.score,
        stale_days: health.stale_days,
        workflows: health.workflows,
        failing_workflows: health.failing_workflows,
        repeated_failures: health.repeated_failures,
        observed_at: now(),
      };
    } catch (error) {
      const status = Number(error?.status || 0);
      return {
        repository: repo,
        name: repo.split('/').pop() || repo,
        private: status === 404,
        state: status === 404 ? 'unknown' : 'error',
        health_score: status === 404 ? 50 : 0,
        workflows: [],
        failing_workflows: [],
        repeated_failures: 0,
        observed_at: now(),
        error: status === 404 && !this.githubToken
          ? 'Dépôt privé ou non visible sans identité machine GitHub.'
          : String(error?.message || error).slice(0, 500),
      };
    }
  }

  async syncRepositoryService(snapshot) {
    const repoKey = String(snapshot.repository || '').toLowerCase();
    const mapped = REPO_SERVICE_MAP.get(repoKey);
    const serviceId = mapped || `repo-${repoKey.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70)}`;
    const existing = await one('SELECT id,name,kind,objective,criticality FROM aura_command_services WHERE id=?', [serviceId]);
    if (!existing) {
      await this.upsertService({
        id: serviceId,
        name: snapshot.name || snapshot.repository,
        kind: 'repository',
        objective: `Maintenir ${snapshot.repository} sain, testable et livrable.`,
        repository: snapshot.repository,
        criticality: snapshot.repository === 'XDSawyerLoL/Auralive' ? 1 : 0.72,
        state: snapshot.state,
        state_detail: snapshot.error || '',
        last_observed_at: snapshot.observed_at,
        metadata: { github: snapshot },
      });
      return;
    }
    await query(
      `UPDATE aura_command_services
       SET repository=?,state=?,state_detail=?,last_observed_at=?,metadata=?,updated_at=?
       WHERE id=?`,
      [
        snapshot.repository,
        snapshot.state,
        String(snapshot.error || (
          snapshot.failing_workflows?.length
            ? `${snapshot.failing_workflows.length} workflow(s) en échec sur ${snapshot.default_branch}`
            : `Santé GitHub ${snapshot.health_score}%`
        )).slice(0, 4000),
        snapshot.observed_at,
        JSON.stringify({ github: snapshot }).slice(0, 20000),
        now(),
        serviceId,
      ],
    );
  }

  async scanGithubFleet({ force = false } = {}) {
    const due = force
      || !this.lastFleetPollMs
      || Date.now() - this.lastFleetPollMs >= config.commandCenterFleetPollSeconds * 1000;
    if (!due) return this.fleetSnapshot;

    const snapshot = [];
    for (const repo of config.commandCenterGithubRepos) {
      const item = await this.scanRepository(repo);
      snapshot.push(item);
      await this.syncRepositoryService(item).catch(() => {});
    }
    this.fleetSnapshot = snapshot;
    this.lastFleetPollMs = Date.now();
    this.lastFleetPollAt = now();
    await query(
      'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(NULL,?,?,?)',
      [
        'fleet-scan',
        JSON.stringify({
          repositories: snapshot.map((item) => ({
            repository: item.repository,
            state: item.state,
            health_score: item.health_score,
            failing_workflows: item.failing_workflows?.map((run) => ({
              name: run.name,
              id: run.id,
              conclusion: run.conclusion,
              failure_streak: run.failure_streak,
            })) || [],
          })),
        }).slice(0, 30000),
        now(),
      ],
    );
    return snapshot;
  }

  githubCandidates(snapshot = []) {
    const candidates = [];
    for (const repo of snapshot) {
      if (!Array.isArray(repo.failing_workflows) || !repo.failing_workflows.length) continue;
      const repoKey = String(repo.repository || '').toLowerCase();
      const productName = REPO_PRODUCT_LABELS.get(repoKey) || repo.name || repo.repository;
      const criticality = repo.repository === 'XDSawyerLoL/Auralive' ? 1 : 0.78;
      for (const run of repo.failing_workflows.slice(0, 2)) {
        if (run.id) {
          candidates.push(this.candidate({
            domain: REPO_SERVICE_MAP.get(String(repo.repository).toLowerCase()) || 'quantic-sillage',
            kind: 'github',
            action_type: 'github.rerun_failed_jobs',
            action_payload: {
              repository: repo.repository,
              run_id: run.id,
              workflow: run.name,
              head_sha: run.head_sha,
              run_attempt: run.run_attempt,
            },
            title: `Relancer le CI défaillant de ${productName}`,
            objective:
              `Relancer uniquement les jobs en échec du workflow ${run.name} sur ${repo.repository}, puis observer le résultat avant toute autre action.`,
            rationale:
              `Workflow ${run.name}=${run.conclusion}; série d’échecs=${run.failure_streak}.`,
            priority: Math.min(0.98, 0.72 + criticality * 0.18 + Math.min(run.failure_streak, 3) * 0.025),
            confidence: 0.96,
            requested_risks: ['safe'],
            signature: `github-rerun:${repo.repository}:${run.id}:${run.run_attempt}`,
          }));
        }

        if (run.failure_streak >= 2 || run.run_attempt >= 2) {
          candidates.push(this.candidate({
            domain: REPO_SERVICE_MAP.get(String(repo.repository).toLowerCase()) || 'quantic-sillage',
            kind: 'github',
            action_type: 'github.create_failure_issue',
            action_payload: {
              repository: repo.repository,
              workflow: run.name,
              head_sha: run.head_sha,
              run_id: run.id,
              failure_streak: run.failure_streak,
              html_url: run.html_url,
            },
            title: `Documenter l’échec persistant de ${productName}`,
            objective:
              `Créer un ticket de diagnostic traçable pour le workflow ${run.name} de ${repo.repository}. Ne modifier aucun code et ne déclencher aucun déploiement.`,
            rationale:
              `Échec persistant détecté automatiquement; série=${run.failure_streak}, tentative=${run.run_attempt}.`,
            priority: Math.min(0.96, 0.77 + criticality * 0.12 + Math.min(run.failure_streak, 4) * 0.02),
            confidence: 0.97,
            requested_risks: ['safe'],
            signature: `github-issue:${repo.repository}:${run.name}:${run.head_sha}`,
          }));
        }

        if (run.failure_streak >= 2) {
          const isAura = repoKey === 'xdsawyerlol/auralive';
          candidates.push(this.candidate({
            domain: REPO_SERVICE_MAP.get(repoKey) || 'quantic-sillage',
            kind: 'evolution',
            action_payload: {
              repository: repo.repository,
              base_branch: repo.default_branch || 'main',
              workflow: run.name,
              head_sha: run.head_sha,
              failure_streak: run.failure_streak,
              fleet_mode: !isAura,
            },
            title: isAura
              ? 'Auto-réparer AURA après échecs CI répétés'
              : `Préparer une correction Evolution Fleet pour ${productName}`,
            objective: isAura
              ? `AURA détecte ${run.failure_streak} échecs consécutifs du workflow ${run.name} sur son propre dépôt. Diagnostiquer la cause, produire le correctif minimal, valider par sandbox + CI + canary avant toute promotion.`
              : `AURA détecte ${run.failure_streak} échecs consécutifs du workflow ${run.name} sur ${repo.repository}. Lire le code du produit, diagnostiquer la cause et préparer une correction minimale via branche dédiée et pull request. Ne jamais fusionner automatiquement ce dépôt en mode Fleet v1.`,
            rationale: isAura
              ? 'Le centre de commande déclenche Evolution sur une preuve opérationnelle répétée.'
              : 'Evolution Fleet est déclenché par un signal CI répété et reste soumis à la CI/revue du dépôt cible.',
            priority: isAura ? 0.99 : Math.min(0.97, 0.80 + criticality * 0.15),
            confidence: 0.94,
            requested_risks: [],
            signature: `${isAura ? 'self-repair' : 'fleet-repair'}:${repo.repository}:${run.name}:${run.head_sha}`,
          }));
        }
      }
    }
    return candidates;
  }

  async executeGithubInitiative(initiative) {
    const admission=this.kernel.authorizeAutonomous('command-center');
    if(!admission.allowed)
      return {status:'waiting',execution_mode:'workspace-denied',
        result:{reason:admission.reason}};
    if (!this.githubToken) {
      return {
        status: 'waiting',
        execution_mode: 'github-readonly',
        result: {
          reason: 'AURA_COMMAND_GITHUB_TOKEN absent: observation autonome active, écriture GitHub verrouillée.',
        },
      };
    }
    const action = String(initiative.action_type || '');
    const payload = initiative.action_payload || {};
    const repository = String(payload.repository || '');
    if (!repository.includes('/')) throw new Error('dépôt GitHub manquant');

    if (action === 'github.rerun_failed_jobs') {
      if (!config.commandCenterAutoRerunFailedCi) {
        return {
          status: 'waiting',
          execution_mode: 'github-action-disabled',
          result: { reason: 'AURA_COMMAND_AUTO_RERUN_FAILED_CI=false' },
        };
      }
      const runId = Number(payload.run_id || 0);
      if (!runId) throw new Error('run_id GitHub manquant');
      const response = await this.github(
        `/repos/${repository}/actions/runs/${runId}/rerun-failed-jobs`,
        { method: 'POST' },
      );
      return {
        status: 'completed',
        execution_mode: 'github-safe-rerun',
        result: {
          executed: true,
          repository,
          run_id: runId,
          status_code: response.status,
        },
      };
    }

    if (action === 'github.propose_file_change') {
      if (!config.commandCenterAutoCreateChangePr) {
        return {
          status: 'waiting',
          execution_mode: 'github-change-pr-disabled',
          result: { reason: 'AURA_COMMAND_AUTO_CREATE_CHANGE_PR=false' },
        };
      }
      if (Number(initiative.confidence || 0) < config.commandCenterChangePrMinConfidence) {
        return {
          status: 'waiting',
          execution_mode: 'github-change-confidence-gate',
          result: {
            reason: 'confiance insuffisante pour créer une PR de modification',
            confidence: Number(initiative.confidence || 0),
            minimum: config.commandCenterChangePrMinConfidence,
          },
        };
      }
      const allowedRepos = new Set(config.commandCenterGithubRepos.map((item) => String(item).toLowerCase()));
      if (!allowedRepos.has(repository.toLowerCase())) {
        throw new Error('dépôt hors allowlist AURA: ' + repository);
      }
      const requestedFiles = Array.isArray(payload.files) ? payload.files : [];
      if (!requestedFiles.length) throw new Error('aucun fichier de modification fourni');
      if (requestedFiles.length > config.commandCenterChangePrMaxFiles) {
        throw new Error('trop de fichiers dans une seule proposition AURA');
      }

      const files = requestedFiles.map((item) => {
        const path = safeGithubChangePath(item?.path);
        const content = String(item?.content ?? '');
        if (!path) throw new Error('chemin de fichier interdit pour AURA');
        if (Buffer.byteLength(content, 'utf8') > config.commandCenterChangePrMaxFileBytes) {
          throw new Error('fichier trop volumineux pour une modification autonome AURA: ' + path);
        }
        return {
          path,
          content,
          message: String(item?.message || payload.commit_message || 'AURA: proposition de modification').slice(0, 240),
        };
      });

      const meta = (await this.github(`/repos/${repository}`)).data || {};
      const baseBranch = String(meta.default_branch || 'main');
      const baseRef = await this.github(
        `/repos/${repository}/git/ref/heads/${encodeGithubPath(baseBranch)}`,
      );
      const baseSha = String(baseRef.data?.object?.sha || '');
      if (!baseSha) throw new Error('SHA de branche de base introuvable');

      const branch = githubBranchName(initiative.fingerprint);
      try {
        await this.github(
          `/repos/${repository}/git/ref/heads/${encodeGithubPath(branch)}`,
        );
      } catch (error) {
        if (Number(error?.status || 0) !== 404) throw error;
        await this.github(
          `/repos/${repository}/git/refs`,
          { method: 'POST', body: { ref: 'refs/heads/' + branch, sha: baseSha } },
        );
      }

      const changedFiles = [];
      for (const file of files) {
        const endpoint = `/repos/${repository}/contents/${encodeGithubPath(file.path)}`;
        let existingSha = '';
        try {
          const existing = await this.github(endpoint + '?ref=' + encodeURIComponent(branch));
          existingSha = String(existing.data?.sha || '');
        } catch (error) {
          if (Number(error?.status || 0) !== 404) throw error;
        }
        const body = {
          message: file.message,
          content: Buffer.from(file.content, 'utf8').toString('base64'),
          branch,
        };
        if (existingSha) body.sha = existingSha;
        const write = await this.github(endpoint, { method: 'PUT', body });
        changedFiles.push({
          path: file.path,
          commit_sha: String(write.data?.commit?.sha || ''),
        });
      }

      const owner = repository.split('/')[0];
      const existingPrs = await this.github(
        `/repos/${repository}/pulls?state=open&head=${encodeURIComponent(owner + ':' + branch)}&per_page=10`,
      );
      let pull = Array.isArray(existingPrs.data) ? existingPrs.data[0] : null;
      if (!pull) {
        const marker = `<!-- aura-change:${initiative.fingerprint} -->`;
        const title = String(payload.title || initiative.title || 'AURA change proposal').slice(0, 240);
        const body = [
          marker,
          String(payload.body || initiative.objective || '').slice(0, 12000),
          '',
          'Modification proposée automatiquement par AURA.',
          'Politique: branche dédiée uniquement; aucun push direct sur la branche principale; aucun auto-merge.',
          'La promotion reste conditionnée aux validations CI/canary du dépôt.',
        ].join('\n');
        const created = await this.github(
          `/repos/${repository}/pulls`,
          { method: 'POST', body: { title, body, head: branch, base: baseBranch } },
        );
        pull = created.data;
      }
      return {
        status: 'completed',
        execution_mode: 'github-bounded-change-pr',
        result: {
          executed: true,
          repository,
          base_branch: baseBranch,
          branch,
          changed_files: changedFiles,
          pull_request_number: Number(pull?.number || 0),
          pull_request_url: String(pull?.html_url || ''),
          auto_merge: false,
        },
      };
    }

    if (action === 'github.create_failure_issue') {
      if (!config.commandCenterAutoCreateFailureIssue) {
        return {
          status: 'waiting',
          execution_mode: 'github-action-disabled',
          result: { reason: 'AURA_COMMAND_AUTO_CREATE_FAILURE_ISSUE=false' },
        };
      }
      const marker = `<!-- aura-command:${initiative.fingerprint} -->`;
      const title = `[AURA AutoOps] ${payload.workflow || 'Workflow'} en échec persistant`.slice(0, 240);
      const body = [
        marker,
        'AURA a détecté automatiquement un échec CI persistant.',
        '',
        `- Dépôt: ${repository}`,
        `- Workflow: ${payload.workflow || 'inconnu'}`,
        `- Commit: ${payload.head_sha || 'inconnu'}`,
        `- Série d’échecs: ${Number(payload.failure_streak || 0)}`,
        payload.html_url ? `- Exécution: ${payload.html_url}` : '',
        '',
        'Action automatique volontairement limitée: diagnostic et traçabilité uniquement. '
          + 'Aucun merge, déploiement, suppression ou changement de secret n’a été effectué.',
      ].filter(Boolean).join('\n');
      const response = await this.github(
        `/repos/${repository}/issues`,
        { method: 'POST', body: { title, body } },
      );
      return {
        status: 'completed',
        execution_mode: 'github-safe-issue',
        result: {
          executed: true,
          repository,
          issue_number: Number(response.data?.number || 0),
          issue_url: String(response.data?.html_url || ''),
        },
      };
    }

    throw new Error(`action GitHub autonome non autorisée: ${action}`);
  }

  async proposeGithubChange(payload = {}) {
    const repository = String(payload.repository || '').trim();
    const title = String(payload.title || 'AURA · proposition de modification').trim().slice(0, 240);
    const files = Array.isArray(payload.files) ? payload.files : [];
    const candidate = this.candidate({
      domain: REPO_SERVICE_MAP.get(repository.toLowerCase()) || 'quantic-sillage',
      kind: 'github',
      title,
      objective: String(payload.objective || payload.body || title).slice(0, 8000),
      rationale: String(payload.rationale || 'Modification structurée proposée par AURA.').slice(0, 5000),
      priority: payload.priority ?? 0.82,
      confidence: payload.confidence ?? 0.82,
      requested_risks: ['safe', 'local-write'],
      action_type: 'github.propose_file_change',
      action_payload: {
        repository,
        files,
        title,
        body: String(payload.body || '').slice(0, 12000),
        commit_message: String(payload.commit_message || 'AURA: proposition de modification').slice(0, 240),
      },
      signature: String(payload.signature || `change:${repository}:${files.map((item) => item?.path || '').join(',')}:${title}`),
    });
    const persisted = await this.persistInitiative(candidate);
    const initiative = persisted.initiative;
    if (!persisted.created) return { created: false, initiative };
    if (!config.commandCenterAutoExecute) return { created: true, initiative };
    return { created: true, initiative: await this.executeInitiative(initiative) };
  }

  async setServiceState(id, state, detail = '', metadata = {}) {
    const stamp = now();
    const current = await one(
      'SELECT state,state_detail,metadata FROM aura_command_services WHERE id=?',
      [String(id)],
    );
    if (!current) return null;
    const normalizedState = String(state || 'unknown').slice(0, 40);
    const normalizedDetail = String(detail || '').slice(0, 4000);
    const mergedMetadata = {
      ...parseJson(current.metadata, {}),
      ...(metadata && typeof metadata === 'object' ? metadata : {}),
    };
    const normalizedMetadata = JSON.stringify(mergedMetadata).slice(0, 20000);
    const changed = String(current.state || '') !== normalizedState
      || String(current.state_detail || '') !== normalizedDetail
      || String(current.metadata || '{}') !== normalizedMetadata;
    await query(
      `UPDATE aura_command_services
       SET state=?,state_detail=?,last_observed_at=?,metadata=?,updated_at=?
       WHERE id=?`,
      [normalizedState, normalizedDetail, stamp, normalizedMetadata, stamp, String(id)],
    );
    if (changed) {
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(NULL,?,?,?)',
        [
          'service-state-change',
          JSON.stringify({
            service_id: String(id),
            state: normalizedState,
            detail: normalizedDetail,
            metadata,
          }).slice(0, 30000),
          stamp,
        ],
      );
    }
    return { id: String(id), state: normalizedState, changed };
  }

  async syncCoreServices() {
    const bridgeStatus = this.bridge?.status
      ? await this.bridge.status().catch(() => ({ enabled: false, worker_online: false }))
      : { enabled: false, worker_online: false };
    await this.setServiceState(
      'aura',
      'online',
      'Noyau Cloud actif et centre de commande en exécution.',
      { command_center: CommandCenter.VERSION },
    );
    await this.setServiceState(
      'aura-runtime',
      bridgeStatus.worker_online ? 'online' : 'standby',
      bridgeStatus.worker_online
        ? 'AURA Runtime worker connecté et disponible pour les actions locales autorisées.'
        : 'AURA Runtime worker absent; AURA Cloud poursuit ses décisions et met en attente les actions locales.',
      {
        worker_online: Boolean(bridgeStatus.worker_online),
        worker_version: String(bridgeStatus?.worker?.version || ''),
        execution_plane: 'aura-runtime',
        runtime_role: String(bridgeStatus?.worker?.runtime_role || 'aura-runtime'),
        runtime_packaging: String(bridgeStatus?.worker?.runtime_packaging || ''),
        compatibility_host: String(bridgeStatus?.worker?.host_product || ''),
      },
    );
    const hostProduct = String(bridgeStatus?.worker?.host_product || '').toLowerCase();
    const runtimePackaging = String(bridgeStatus?.worker?.runtime_packaging || '').toLowerCase();
    const studioHosted = Boolean(
      bridgeStatus.worker_online
      && (hostProduct.includes('studio') || runtimePackaging.includes('studio'))
    );
    if (studioHosted) {
      await this.setServiceState(
        'quantic-studio',
        'online',
        'Quantic Studio héberge actuellement un AURA Runtime actif.',
        {
          worker_online: true,
          worker_version: String(bridgeStatus?.worker?.version || ''),
          runtime_host_product: String(bridgeStatus?.worker?.host_product || 'Quantic Studio'),
          runtime_packaging: String(bridgeStatus?.worker?.runtime_packaging || ''),
          telemetry_source: 'aura-runtime-heartbeat',
        },
      );
    } else if (
      hostProduct.includes('studio')
      || runtimePackaging.includes('embedded-compatibility-host')
    ) {
      await this.setServiceState(
        'quantic-studio',
        'offline',
        'Le dernier AURA Runtime hébergé par Quantic Studio ne répond plus.',
        {
          worker_online: false,
          worker_version: String(bridgeStatus?.worker?.version || ''),
          runtime_host_product: String(bridgeStatus?.worker?.host_product || 'Quantic Studio'),
          runtime_packaging: String(bridgeStatus?.worker?.runtime_packaging || ''),
          telemetry_source: 'aura-runtime-heartbeat',
        },
      );
    }

    const horizonStatus = this.kernel?.horizon?.status?.() || {};
    await this.setServiceState(
      'horizon',
      horizonStatus.enabled ? (horizonStatus.last_error ? 'degraded' : 'online') : 'standby',
      horizonStatus.enabled
        ? (horizonStatus.last_error ? 'HORIZON signale une erreur récente.' : 'HORIZON actif.')
        : 'HORIZON non configuré; AURA fonctionne sans lui.',
      {
        enabled: Boolean(horizonStatus.enabled),
        last_success_at: String(horizonStatus.last_success_at || ''),
      },
    );
    return bridgeStatus;
  }

  async refreshProductHealth() {
    const stamp = Date.now();
    const staleMs = config.commandCenterProductStaleSeconds * 1000;
    const offlineMs = config.commandCenterProductOfflineSeconds * 1000;
    const rows = await query(
      `SELECT id,name,state,state_detail,last_observed_at,metadata
       FROM aura_command_services
       WHERE enabled=1 AND kind='quantic-product'`,
    );
    const transitions = [];
    for (const row of rows) {
      const health = productHeartbeatHealth(row, {
        nowMs: stamp,
        staleSeconds: config.commandCenterProductStaleSeconds,
        offlineSeconds: config.commandCenterProductOfflineSeconds,
      });
      const state = health.state;
      const next = health.next_state;
      const ageSeconds = health.age_seconds;
      if (!health.transition || ageSeconds == null) continue;
      const detail = next === 'offline'
        ? `Aucun heartbeat produit depuis ${ageSeconds} s; seuil offline=${config.commandCenterProductOfflineSeconds}s.`
        : `Heartbeat produit périmé depuis ${ageSeconds} s; seuil stale=${config.commandCenterProductStaleSeconds}s.`;
      const metadata = parseJson(row.metadata, {});
      const result = await query(
        `UPDATE aura_command_services
         SET state=?,state_detail=?,metadata=?,updated_at=?
         WHERE id=? AND last_observed_at=?`,
        [
          next,
          detail,
          JSON.stringify({
            ...metadata,
            health_transition_source: 'heartbeat-ttl',
            heartbeat_age_seconds: ageSeconds,
          }).slice(0, 20000),
          now(),
          row.id,
          row.last_observed_at,
        ],
      );
      if (Number(result.affectedRows || 0)) {
        transitions.push({ id: row.id, from: state, to: next, age_seconds: ageSeconds });
        await query(
          'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(NULL,?,?,?)',
          [
            'service-heartbeat-expired',
            JSON.stringify(transitions[transitions.length - 1]).slice(0, 30000),
            now(),
          ],
        );
      }
    }
    return transitions;
  }

  async services() {
    const rows = await query(
      `SELECT id,name,kind,objective,endpoint,repository,criticality,enabled,state,state_detail,
              last_observed_at,metadata,created_at,updated_at
       FROM aura_command_services
       ORDER BY criticality DESC,name ASC`,
    );
    return rows.map((row) => ({
      ...row,
      criticality: Number(row.criticality || 0),
      enabled: Boolean(row.enabled),
      metadata: parseJson(row.metadata, {}),
    }));
  }

  async upsertService(payload = {}) {
    const id = String(payload.id || '').trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(0, 80);
    const name = String(payload.name || '').trim().slice(0, 160);
    if (!id || !name) throw new Error('id et name sont requis');
    const stamp = now();
    const current = await one(
      'SELECT state,state_detail,last_observed_at,metadata FROM aura_command_services WHERE id=?',
      [id],
    );
    const mergedMetadata = {
      ...parseJson(current?.metadata, {}),
      ...(payload.metadata && typeof payload.metadata === 'object' ? payload.metadata : {}),
    };
    const effectiveState = String(payload.state ?? current?.state ?? 'unknown').slice(0, 40);
    const effectiveDetail = String(payload.state_detail ?? current?.state_detail ?? '').slice(0, 4000);
    const effectiveObservedAt = String(payload.last_observed_at ?? current?.last_observed_at ?? '');
    await query(
      `INSERT INTO aura_command_services(
        id,name,kind,objective,endpoint,repository,criticality,enabled,state,state_detail,
        last_observed_at,metadata,created_at,updated_at
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?, ?,?,?)
      ON DUPLICATE KEY UPDATE
        name=VALUES(name),
        kind=VALUES(kind),
        objective=VALUES(objective),
        endpoint=VALUES(endpoint),
        repository=VALUES(repository),
        criticality=VALUES(criticality),
        enabled=VALUES(enabled),
        state=VALUES(state),
        state_detail=VALUES(state_detail),
        last_observed_at=VALUES(last_observed_at),
        metadata=VALUES(metadata),
        updated_at=VALUES(updated_at)`,
      [
        id,
        name,
        String(payload.kind || 'service').slice(0, 80),
        String(payload.objective || '').slice(0, 4000),
        String(payload.endpoint || '').slice(0, 1000),
        String(payload.repository || '').slice(0, 300),
        clamp(payload.criticality ?? 0.5),
        payload.enabled === false ? 0 : 1,
        effectiveState,
        effectiveDetail,
        effectiveObservedAt,
        JSON.stringify(mergedMetadata).slice(0, 20000),
        stamp,
        stamp,
      ],
    );
    return one('SELECT * FROM aura_command_services WHERE id=?', [id]);
  }

  async observeService(id, payload = {}) {
    const serviceId = String(id || '').trim().slice(0, 80);
    const current = await one('SELECT metadata FROM aura_command_services WHERE id=?', [serviceId]);
    if (!current) throw new Error('service inconnu');
    const state = String(payload.state || 'unknown').trim().toLowerCase().slice(0, 40);
    const detail = String(payload.detail || payload.state_detail || '').slice(0, 4000);
    const mergedMetadata = {
      ...parseJson(current.metadata, {}),
      ...(payload.metadata && typeof payload.metadata === 'object' ? payload.metadata : {}),
    };
    const metadata = JSON.stringify(mergedMetadata).slice(0, 20000);
    const stamp = now();
    const result = await query(
      `UPDATE aura_command_services
       SET state=?,state_detail=?,last_observed_at=?,metadata=?,updated_at=?
       WHERE id=?`,
      [state, detail, stamp, metadata, stamp, serviceId],
    );
    if (!Number(result.affectedRows || 0)) throw new Error('service inconnu');
    await query(
      'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(NULL,?,?,?)',
      [
        'service-observation',
        JSON.stringify({ service_id: serviceId, state, detail, metadata: mergedMetadata }).slice(0, 30000),
        stamp,
      ],
    );
    return one('SELECT * FROM aura_command_services WHERE id=?', [serviceId]);
  }

  async initiatives(limit = 30, status = '') {
    const max = Math.max(1, Math.min(Number(limit) || 30, 100));
    const normalizedStatus = String(status || '').trim().slice(0, 40);
    const rows = normalizedStatus
      ? await query(
        `SELECT * FROM aura_initiatives WHERE status=? ORDER BY priority DESC,updated_at DESC LIMIT ?`,
        [normalizedStatus, max],
      )
      : await query(
        `SELECT * FROM aura_initiatives ORDER BY updated_at DESC LIMIT ?`,
        [max],
      );
    return rows.map((row) => ({
      ...row,
      priority: Number(row.priority || 0),
      confidence: Number(row.confidence || 0),
      attempts: Number(row.attempts || 0),
      requested_risks: parseJson(row.requested_risks, []),
      action_payload: parseJson(row.action_payload, {}),
      result: parseJson(row.result, {}),
    }));
  }

  async countRecentInitiatives() {
    const threshold = new Date(Date.now() - 3600_000).toISOString();
    const row = await one(
      'SELECT COUNT(*) AS total FROM aura_initiatives WHERE created_at>=?',
      [threshold],
    );
    return Number(row?.total || 0);
  }

  async existingInitiative(candidate) {
    const active = await one(
      `SELECT * FROM aura_initiatives
       WHERE fingerprint=? AND status IN ('queued','running','waiting')
       ORDER BY updated_at DESC LIMIT 1`,
      [candidate.fingerprint],
    );
    if (active) return active;
    const threshold = new Date(Date.now() - config.commandCenterCooldownSeconds * 1000).toISOString();
    return one(
      `SELECT * FROM aura_initiatives
       WHERE fingerprint=? AND updated_at>=?
       ORDER BY updated_at DESC LIMIT 1`,
      [candidate.fingerprint, threshold],
    );
  }

  candidate(input) {
    const policyRisks = new Set(normalizeRisks(config.commandCenterAllowedRisks));
    const requested = input.requested_risks == null
      ? [...policyRisks]
      : normalizeRisks(input.requested_risks);
    const risks = requested.filter((risk) => policyRisks.has(risk));
    const domain = String(input.domain || 'aura').slice(0, 80);
    const kind = String(input.kind || 'reflection').slice(0, 40);
    const objective = String(input.objective || '').replace(/\s+/g, ' ').trim().slice(0, 8000);
    return {
      ...input,
      domain,
      kind,
      objective,
      title: String(input.title || objective || 'Initiative AURA').slice(0, 240),
      rationale: String(input.rationale || '').slice(0, 5000),
      priority: clamp(input.priority ?? 0.5),
      confidence: clamp(input.confidence ?? 0.5),
      requested_risks: risks,
      action_type: String(input.action_type || '').slice(0, 120),
      action_payload: input.action_payload && typeof input.action_payload === 'object'
        ? input.action_payload
        : {},
      fingerprint: fingerprint([domain, kind, input.signature || objective]),
    };
  }

  async buildCandidates() {
    const syncedBridgeStatus = await this.syncCoreServices();
    await this.refreshProductHealth();
    const [intentions, improvements, outcomes, services, bridgeStatus, recentReasoning] = await Promise.all([
      this.kernel.intentions(8),
      this.kernel.improvements(8),
      query(
        `SELECT automation_id,event_type,ok,signature,created_at
         FROM aura_outcomes ORDER BY id DESC LIMIT 24`,
      ),
      this.services(),
      Promise.resolve(syncedBridgeStatus || { enabled: false, worker_online: false }),
      query(
        `SELECT question,confidence,epistemic_status,evidence_count,updated_at
         FROM aura_reasoning_sessions ORDER BY updated_at DESC LIMIT 24`,
      ).catch(() => []),
    ]);
    const candidates = [];

    for (const service of services) {
      if (!service.enabled || !BAD_SERVICE_STATES.has(String(service.state || '').toLowerCase())) continue;
      candidates.push(this.candidate({
        domain: service.id,
        kind: 'operator',
        title: `Rétablir ${service.name}`,
        objective:
          `Diagnostiquer l’état ${service.state} de ${service.name}. `
          + `Objectif produit: ${service.objective || 'rétablir le service'}. `
          + `Commencer par une vérification réversible. Ne pas effectuer d’action irréversible.`,
        rationale: service.state_detail || `Service déclaré ${service.state}.`,
        priority: Math.min(0.98, 0.66 + Number(service.criticality || 0.5) * 0.30),
        confidence: 0.9,
        requested_risks: Array.isArray(service.metadata?.allowed_risks)
          ? service.metadata.allowed_risks
          : undefined,
        signature: `service:${service.id}:${service.state}`,
      }));
    }

    const recentFailures = new Map();
    for (const row of outcomes) {
      if (Boolean(row.ok)) continue;
      const key = `${row.automation_id}:${row.signature}`;
      const current = recentFailures.get(key) || { ...row, count: 0 };
      current.count += 1;
      recentFailures.set(key, current);
    }
    for (const failure of [...recentFailures.values()].filter((item) => item.count >= 2).slice(0, 3)) {
      candidates.push(this.candidate({
        domain: 'aura',
        kind: 'operator',
        title: 'Traiter un échec récurrent',
        objective:
          `Diagnostiquer l’échec récurrent ${failure.automation_id}: ${failure.signature}. `
          + `Chercher la cause, appliquer seulement une correction réversible et vérifier le résultat.`,
        rationale: `${failure.count} occurrences récentes.`,
        priority: Math.min(0.97, 0.72 + failure.count * 0.06),
        confidence: Math.min(0.96, 0.68 + failure.count * 0.07),
        signature: `failure:${failure.automation_id}:${failure.signature}`,
      }));
    }

    const proposal = improvements.find((row) => String(row.status || '') === 'proposed');
    if (proposal) {
      candidates.push(this.candidate({
        domain: 'aura',
        kind: 'evolution',
        title: 'Faire évoluer AURA sur une faiblesse observée',
        objective:
          `Traiter l’amélioration proposée pour ${proposal.target}. `
          + `Diagnostic: ${proposal.diagnosis}. Proposition: ${proposal.proposal}. `
          + `Validation attendue: ${proposal.validation_plan}.`,
        rationale: `Amélioration persistante avec ${Number(proposal.evidence_count || 0)} preuve(s).`,
        priority: Math.min(0.96, 0.70 + Math.min(Number(proposal.evidence_count || 0), 6) * 0.04),
        confidence: Math.min(0.94, 0.65 + Math.min(Number(proposal.evidence_count || 0), 6) * 0.04),
        requested_risks: [],
        signature: `improvement:${proposal.id}`,
      }));
    }

    if (config.directorModeEnabled) {
      const portfolio = services.filter((service) => {
        const repository = String(service.repository || '').trim();
        return service.enabled
          && repository
          && !BAD_SERVICE_STATES.has(String(service.state || '').toLowerCase())
          && String(service.id || '') !== 'aura';
      });

      if (portfolio.length) {
        const slotMs = Math.max(1, config.directorPortfolioIntervalHours) * 3600_000;
        const directorSlot = Math.floor(Date.now() / slotMs);
        const directorAngles = [
          'expérience utilisateur',
          'intégration avec les autres produits Quantic',
          'fiabilité et dette technique',
          'automatisation opérationnelle',
          'confidentialité et souveraineté',
          'distribution et adoption',
          'usage intelligent du Web et des modèles',
          'réduction des frictions pour l’utilisateur',
        ];
        const width = Math.min(config.commandCenterPortfolioWorkstreams, portfolio.length);
        for (let offset = 0; offset < width; offset += 1) {
          const focusService = portfolio[(directorSlot + offset) % portfolio.length];
          const angle = directorAngles[(directorSlot + offset) % directorAngles.length];
          candidates.push(this.candidate({
            domain: focusService.id,
            kind: 'evolution',
            action_payload: {
              repository: focusService.repository,
              base_branch: 'main',
              director_mode: true,
              portfolio_angle: angle,
              product_id: focusService.id,
              workstream_slot: offset + 1,
            },
            title: `Direction · faire progresser ${focusService.name}`,
            objective:
              `En tant que Directrice opérationnelle de Quantic Sillage, auditer ${focusService.name} sur l’angle « ${angle} ». `
              + `Dépôt cible: ${focusService.repository}. Objectif produit: ${focusService.objective || 'améliorer le produit'}. `
              + 'Maintenir ce produit comme un workstream autonome du portefeuille. '
              + 'Choisir au maximum une amélioration à fort levier, mesurable et réversible. '
              + 'Inspecter les faits et le code avant de modifier quoi que ce soit. '
              + 'Si aucune amélioration sûre et suffisamment étayée n’est trouvée, conclure no-safe-patch plutôt que produire du changement artificiel.',
            rationale:
              'Director Mode maintient plusieurs workstreams produits en parallèle plutôt qu’une seule revue par dépôt.',
            priority: Number((0.73 + Math.max(0, Number(focusService.criticality || 0.5) - 0.5) * 0.12).toFixed(3)),
            confidence: 0.82,
            requested_risks: [],
            signature: `director:${focusService.id}:${directorSlot}:${angle}`,
          }));
        }
      }
    }

    const topIntention = intentions.find((row) => Number(row.priority || 0) >= 0.55);
    if (topIntention) {
      const domain = String(parseJson(topIntention.context, {})?.domain || 'aura').slice(0, 80);
      const externalNeeded = Boolean(
        this.webSubstrate?.enabled && needsExternalEvidence(topIntention.statement),
      );
      const intentionNeedle = String(topIntention.statement || '').trim().slice(0, 180).toLowerCase();
      const research = externalNeeded
        ? recentReasoning.find((row) =>
          String(row.question || '').toLowerCase().includes(intentionNeedle))
        : null;
      const researchAgeMs = research ? Date.now() - Date.parse(String(research.updated_at || '')) : Infinity;
      const researchFresh = Boolean(research && Number.isFinite(researchAgeMs) && researchAgeMs < 6 * 3600_000);
      const evidenceAllowsAction = Boolean(
        researchFresh
        && ['corroborated', 'partially-supported'].includes(String(research.epistemic_status || ''))
        && Number(research.confidence || 0) >= 0.55
        && Number(research.evidence_count || 0) >= 1
      );

      if (externalNeeded && !researchFresh) {
        candidates.push(this.candidate({
          domain,
          kind: 'research',
          title: 'Vérifier une intention avec le Web',
          objective:
            'Vérifier par sources indépendantes cette intention avant action: ' + topIntention.statement + '. '
            + 'Chercher les faits externes nécessaires, les contradictions et le niveau de confiance réel.',
          rationale: 'L’intention dépend d’informations externes ou potentiellement changeantes.',
          priority: Math.min(0.96, Math.max(0.68, Number(topIntention.priority || 0.5) + 0.08)),
          confidence: 0.92,
          requested_risks: [],
          signature: 'external-evidence:' + topIntention.id,
        }));
      } else if (externalNeeded && !evidenceAllowsAction) {
        candidates.push(this.candidate({
          domain,
          kind: 'reflection',
          title: 'Réviser une intention faute de preuves suffisantes',
          objective:
            'Les preuves externes pour cette intention sont ' + (research?.epistemic_status || 'insuffisantes')
            + ' avec confiance ' + Number(research?.confidence || 0).toFixed(2) + '. '
            + 'Réviser l’hypothèse, chercher une alternative ou attendre davantage de preuves: '
            + topIntention.statement + '.',
          rationale: 'La boucle critique interdit de transformer une hypothèse externe faible en action autonome.',
          priority: Math.min(0.90, Math.max(0.62, Number(topIntention.priority || 0.5))),
          confidence: 0.96,
          requested_risks: [],
          signature: 'evidence-block:' + topIntention.id + ':' + (research?.epistemic_status || 'none'),
        }));
      }

      if (!externalNeeded || evidenceAllowsAction) {
        candidates.push(this.candidate({
          domain,
          kind: 'operator',
          title: 'Faire avancer une intention active',
          objective:
            'Faire avancer concrètement cette intention AURA: ' + topIntention.statement + '. '
            + 'Choisir une prochaine action courte, réversible, mesurable et compatible avec les capacités réellement disponibles.',
          rationale: evidenceAllowsAction
            ? 'Preuves externes disponibles: statut=' + research.epistemic_status
              + ', confiance=' + Number(research.confidence || 0).toFixed(2) + '.'
            : 'Intention active priorité=' + Number(topIntention.priority || 0).toFixed(2) + '.',
          priority: Math.min(0.92, Math.max(0.58, Number(topIntention.priority || 0.5))),
          confidence: evidenceAllowsAction
            ? Math.max(0.72, Math.min(0.95, Number(research.confidence || 0.72)))
            : 0.72,
          signature: 'intention:' + topIntention.id,
        }));
      }
    }
    if (!bridgeStatus?.worker_online) {
      candidates.push(this.candidate({
        domain: 'aura-runtime',
        kind: 'reflection',
        title: 'Maintenir l’autonomie malgré AURA Runtime hors ligne',
        objective:
          'Évaluer ce qu’AURA peut continuer à faire côté Cloud sans AURA Runtime, '
          + 'identifier les missions locales bloquées et préparer leur reprise dès le retour du worker.',
        rationale: 'AURA Runtime n’est pas actuellement en ligne. Quantic Studio n’est pas requis pour la continuité du noyau.',
        priority: 0.64,
        confidence: 0.98,
        requested_risks: [],
        signature: 'bridge-offline',
      }));
    }

    if (!candidates.length) {
      candidates.push(this.candidate({
        domain: 'quantic-sillage',
        kind: 'reflection',
        title: 'Revue autonome de l’écosystème',
        objective:
          'Passer en revue les intentions, leçons, résultats et travaux récents de Quantic Sillage. '
          + 'Déterminer s’il existe une prochaine action utile; ne rien inventer si aucun signal concret ne le justifie.',
        rationale: 'Aucune urgence ni faiblesse prioritaire détectée.',
        priority: 0.42,
        confidence: 0.78,
        requested_risks: [],
        signature: 'ecosystem-review',
      }));
    }

    return candidates
      .filter((candidate) => candidate.objective && candidate.confidence >= config.commandCenterMinConfidence)
      .sort((a, b) => (b.priority + b.confidence * 0.15) - (a.priority + a.confidence * 0.15));
  }

  async persistInitiative(candidate) {
    const existing = await this.existingInitiative(candidate);
    if (existing) return { created: false, initiative: existing };

    const activePeers = await query(
      `SELECT id,domain,kind,title,objective,priority,confidence,status,updated_at
       FROM aura_initiatives
       WHERE domain=? AND kind=? AND status IN ('queued','running','waiting')
       ORDER BY priority DESC,confidence DESC,updated_at DESC LIMIT 40`,
      [candidate.domain, candidate.kind],
    );
    const semanticKey = initiativeSemanticKey(
      candidate.domain,
      candidate.kind,
      candidate.title,
      candidate.objective,
    );
    const semanticExisting = activePeers.find((row) =>
      initiativeSemanticKey(row.domain, row.kind, row.title, row.objective) === semanticKey
    );
    if (semanticExisting) {
      return { created: false, initiative: semanticExisting, semantic_duplicate: true };
    }

    const id = randomUUID();
    const stamp = now();
    await query(
      `INSERT INTO aura_initiatives(
        id,fingerprint,domain,kind,title,objective,rationale,priority,confidence,requested_risks,
        action_type,action_payload,status,execution_mode,result,error,attempts,last_attempt_at,created_at,updated_at
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'queued','','{}','',0,'',?,?)`,
      [
        id,
        candidate.fingerprint,
        candidate.domain,
        candidate.kind,
        candidate.title,
        candidate.objective,
        candidate.rationale,
        candidate.priority,
        candidate.confidence,
        JSON.stringify(candidate.requested_risks || []),
        candidate.action_type || '',
        JSON.stringify(candidate.action_payload || {}).slice(0, 30000),
        stamp,
        stamp,
      ],
    );
    await query(
      'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
      [id, 'initiative-created', JSON.stringify(candidate).slice(0, 30000), stamp],
    );
    return {
      created: true,
      initiative: await one('SELECT * FROM aura_initiatives WHERE id=?', [id]),
    };
  }

  async updateInitiative(id, updates = {}) {
    const allowed = {
      status: String(updates.status || '').slice(0, 40),
      execution_mode: String(updates.execution_mode || '').slice(0, 80),
      result: JSON.stringify(updates.result || {}).slice(0, 100000),
      error: String(updates.error || '').slice(0, 5000),
      last_attempt_at: String(updates.last_attempt_at || now()).slice(0, 40),
    };
    await query(
      `UPDATE aura_initiatives
       SET status=?,execution_mode=?,result=?,error=?,
           attempts=attempts+1,last_attempt_at=?,updated_at=?
       WHERE id=?`,
      [
        allowed.status,
        allowed.execution_mode,
        allowed.result,
        allowed.error,
        allowed.last_attempt_at,
        now(),
        String(id),
      ],
    );
  }

  async executeInitiative(row) {
    const admission=this.kernel.authorizeAutonomous('command-center');
    if(!admission.allowed)
      return {id:row?.id||null,status:'waiting',execution_mode:'workspace-denied',
        reason:admission.reason,executed:false};
    const initiative = {
      ...row,
      requested_risks: parseJson(row.requested_risks, []),
      action_payload: parseJson(row.action_payload, {}),
    };
    const id = initiative.id;
    const bridgeOnline = this.bridge?.enabled && await this.bridge.workerOnline().catch(() => false);

    if (!config.commandCenterAutoExecute) {
      await this.updateInitiative(id, {
        status: 'waiting',
        execution_mode: 'autonomy-disabled',
        result: { reason: 'AURA_COMMAND_CENTER_AUTO_EXECUTE=false' },
      });
      return { id, status: 'waiting', reason: 'auto execution disabled' };
    }

    // Operator execution can use AURA's typed Cloud Workspace when the local
    // worker is offline. kernel.operate() still denies arbitrary shell/network
    // effects and truth classification keeps plan-only actions in waiting.

    const targetRepository = String(initiative.action_payload?.repository || '').trim();
    const crossProductEvolution = initiative.kind === 'evolution'
      && targetRepository
      && targetRepository.toLowerCase() !== 'xdsawyerlol/auralive';
    if (crossProductEvolution && !bridgeOnline) {
      await this.updateInitiative(id, {
        status: 'waiting',
        execution_mode: 'waiting-local-worker',
        result: {
          reason: 'AURA Runtime worker offline',
          repository: targetRepository,
        },
      });
      return {
        id,
        status: 'waiting',
        execution_mode: 'waiting-local-worker',
        reason: 'worker offline',
        repository: targetRepository,
      };
    }

    await query(
      "UPDATE aura_initiatives SET status='running',updated_at=? WHERE id=?",
      [now(), id],
    );
    // Correlate one native Reflex assessment with this actual initiative.
    // These tier inputs are a conservative heuristic, NOT calibrated labels.
    const reflexDecision = this.kernel.inferenceAssessment({
      novelty: ['research', 'evolution'].includes(String(initiative.kind)) ? 0.65 : 0.2,
      risk: ['operator', 'github', 'evolution'].includes(String(initiative.kind)) ? 0.7 : 0.2,
    });

    try {
      let result;
      let executionMode;
      let usedCapabilities = [];

      if (initiative.kind === 'github') {
        const githubResult = await this.executeGithubInitiative(initiative);
        executionMode = githubResult.execution_mode;
        result = githubResult.result;
        const status = githubResult.status;
        await this.updateInitiative(id, {
          status,
          execution_mode: executionMode,
          result,
        });
        this.lastActionAt = now();
        await query(
          'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
          [id, 'initiative-result', JSON.stringify({ status, executionMode, result }).slice(0, 30000), now()],
        );
        if (status === 'completed') {
          await this.kernel.recordOutcome({
            automation_id: `command-center:${initiative.domain}`,
            event_type: 'aura.initiative.github',
            reflex_decision_id: reflexDecision.decision_id,
            ok: true,
            signature: 'success',
            report: { initiative_id: id, title: initiative.title, result },
            created_at: now(),
          });
        }
        return { id, status, execution_mode: executionMode, result };
      } else if (initiative.kind === 'research') {
        if (
          this.fabric
          && this.dagCompiler
          && this.graphExecutor
          && config.fabricEnabled
        ) {
          const safeCapabilities = this.fabric
            .list()
            .filter((item) => !item.side_effects);
          const graph = await this.dagCompiler.compile(
            initiative.objective,
            safeCapabilities,
            {
              maxNodes: Math.min(config.fabricMaxGraphNodes, 16),
              maxParallel: Math.min(config.fabricMaxParallel, 8),
              budgetMicrounits: config.fabricDefaultBudgetMicrounits,
            },
          );
          executionMode = 'aura-fabric-research-dag';
          usedCapabilities = [...new Set((graph.nodes || []).map((node) => String(node.capability || '')).filter(Boolean))];
          result = await this.graphExecutor.execute(
            graph,
            { trigger: 'command-center' },
          );
        } else {
          if (!this.webSubstrate?.enabled) {
            throw new Error('Web Substrate indisponible');
          }
          executionMode = 'web-substrate-research';
          usedCapabilities = ['web.research'];
          result = await this.webSubstrate.research(
            initiative.objective,
            { trigger: 'command-center' },
          );
        }
      } else if (initiative.kind === 'evolution') {
        const repository = String(initiative.action_payload?.repository || '').trim();
        const baseBranch = String(initiative.action_payload?.base_branch || 'main').trim() || 'main';
        executionMode = repository && repository.toLowerCase() !== 'xdsawyerlol/auralive'
          ? 'evolution-fleet'
          : (bridgeOnline ? 'evolution-hybrid' : 'evolution-cloud');
        result = await this.evolution.dispatchCycle(
          initiative.objective,
          'command-center',
          { repository, base_branch: baseBranch },
        );
      } else if (initiative.kind === 'operator') {
        executionMode = 'aura-runtime-operator';
        result = await this.kernel.operate(
          initiative.objective,
          initiative.requested_risks,
        );
      } else {
        executionMode = 'native-reflection';
        result = await this.kernel.tick({
          trigger: 'command-center',
          text: initiative.objective,
          force: true,
        });
      }

      const returnedStatus = String(result?.status || '').toLowerCase();
      if (initiative.kind === 'evolution' && returnedStatus === 'waiting-local-worker') {
        executionMode = 'waiting-local-worker';
      }
      const classification = classifyInitiativeResult(initiative.kind, result);
      if (classification.waiting_for_worker) executionMode = 'waiting-local-worker';
      const { status, executed } = classification;
      await this.updateInitiative(id, {
        status,
        execution_mode: executionMode,
        result,
      });
      this.lastActionAt = now();
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [id, 'initiative-result', JSON.stringify({ status, executionMode, result }).slice(0, 30000), now()],
      );
      if (status === 'completed' || status === 'failed') {
        await this.kernel.recordOutcome({
          reflex_decision_id: reflexDecision.decision_id,
          automation_id: `command-center:${initiative.domain}`,
          event_type: `aura.initiative.${initiative.kind}`,
          ok: status === 'completed' && Boolean(executed),
          signature: executed ? 'success' : (result?.reason || 'not-executed'),
          report: { initiative_id: id, title: initiative.title, result, capabilities: usedCapabilities },
          capabilities: usedCapabilities,
          context_key: String(initiative.domain || initiative.kind || 'command-center'),
          strategy_key: `command-center:${initiative.kind}:${usedCapabilities.join('>') || initiative.action_type || 'native'}`,
          created_at: now(),
        });
      }
      return { id, status, execution_mode: executionMode, result };
    } catch (error) {
      const message = safeOperationalError(error, 5000);
      await this.updateInitiative(id, {
        status: 'failed',
        execution_mode: initiative.kind,
        error: message,
        result: {},
      });
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [id, 'initiative-error', JSON.stringify({ error: message }).slice(0, 30000), now()],
      );
      await this.kernel.recordOutcome({
        automation_id: `command-center:${initiative.domain}`,
        event_type: `aura.initiative.${initiative.kind}`,
        reflex_decision_id: reflexDecision.decision_id,
        ok: false,
        signature: message,
        report: { initiative_id: id, title: initiative.title, error: message },
        created_at: now(),
      });
      throw error;
    }
  }

  async reconcileWaiting() {
    const rows = await query(
      `SELECT i.* FROM aura_initiatives i
       WHERE i.status='waiting'
         AND NOT EXISTS (
           SELECT 1
           FROM aura_mission_steps ms
           JOIN aura_missions m ON m.id=ms.mission_id
           WHERE ms.initiative_id=i.id
             AND m.status IN ('paused','cancelled','failed','completed')
         )
       ORDER BY i.priority DESC,i.updated_at ASC LIMIT 12`,
    );
    const reconciled = [];
    const workerOnline = this.bridge?.enabled
      && await this.bridge.workerOnline().catch(() => false);

    for (const row of rows) {
      const stored = parseJson(row.result, {});
      const jobId = String(stored?.job_id || stored?.result?.job_id || '').trim();

      if (!jobId) {
        if (row.execution_mode === 'waiting-local-worker' && workerOnline) {
          reconciled.push(await this.executeInitiative(row));
        } else if (
          row.kind === 'github'
          && row.execution_mode === 'github-readonly'
          && this.githubToken
        ) {
          reconciled.push(await this.executeInitiative(row));
        }
        continue;
      }

      const job = await this.bridge.getJob(jobId).catch(() => null);
      if (!job || ['queued', 'leased'].includes(String(job.status || ''))) continue;

      if (job.status === 'completed') {
        const payload = job.result || {};
        // Transport completion is not proof that the underlying action worked.
        const classification = classifyInitiativeResult('worker', payload);
        const executionRejected = classification.status !== 'completed';
        const payloadStatus = String(payload?.status || '').toLowerCase();
        const finalStatus = executionRejected ? 'failed' : 'completed';
        const finalError = executionRejected
          ? String(payload?.error || payload?.reason || payloadStatus || 'worker-result-failed').slice(0, 5000)
          : '';
        await query(
          `UPDATE aura_initiatives
           SET status=?,execution_mode=?,
               result=?,error=?,updated_at=?
           WHERE id=?`,
          [
            finalStatus,
            row.kind === 'evolution' ? 'evolution-fleet' : 'aura-runtime-operator',
            JSON.stringify(payload).slice(0, 100000),
            finalError,
            now(),
            row.id,
          ],
        );
        await this.kernel.recordOutcome({
          automation_id: `command-center:${row.domain}`,
          event_type: `aura.initiative.${row.kind}`,
          ok: !executionRejected,
          signature: executionRejected
            ? String(payload?.error || payload?.reason || payloadStatus || 'worker-result-failed')
            : 'success',
          report: { initiative_id: row.id, job_id: jobId, result: payload },
          created_at: now(),
        });
        reconciled.push({ id: row.id, status: finalStatus, job_id: jobId });
      } else if (['error', 'cancelled', 'canceled'].includes(String(job.status || '').toLowerCase())) {
        const message = safeOperationalError(job.error || `worker execution ${job.status}`, 5000);
        await query(
          `UPDATE aura_initiatives
           SET status='failed',error=?,updated_at=?
           WHERE id=?`,
          [message, now(), row.id],
        );
        await this.kernel.recordOutcome({
          automation_id: `command-center:${row.domain}`,
          event_type: `aura.initiative.${row.kind}`,
          ok: false,
          signature: message,
          report: { initiative_id: row.id, job_id: jobId, error: message },
          created_at: now(),
        });
        reconciled.push({ id: row.id, status: 'failed', job_id: jobId });
      }
    }
    return reconciled;
  }

  expertRemediationCandidate(row, advice, threadId = '') {
    if (!advice?.ok || advice.human_required) return null;
    if (Number(advice.confidence || 0) < config.expertBridgeMinConfidence) return null;

    const action = String(advice.action_kind || '').toLowerCase();
    if (['wait', 'human'].includes(action)) return null;
    if (String(advice.risk_level || '').toLowerCase() === 'high' && action !== 'research') {
      return null;
    }

    const originalRisks = parseJson(row.requested_risks, []);
    const originalPayload = parseJson(row.action_payload, {});
    const kind = action === 'retry'
      ? String(row.kind || 'reflection')
      : action;
    const recommended = String(advice.recommended_action || '').trim();
    const diagnosis = String(advice.diagnosis || '').trim();
    const probableCause = String(advice.probable_cause || '').trim();
    const evidence = Array.isArray(advice.evidence_needed)
      ? advice.evidence_needed.filter(Boolean).slice(0, 8)
      : [];
    const objective = [
      recommended || `Résoudre l’échec de ${String(row.title || 'cette initiative')}.`,
      diagnosis ? `Diagnostic expert: ${diagnosis}` : '',
      probableCause ? `Cause probable: ${probableCause}` : '',
      evidence.length ? `Vérifications attendues: ${evidence.join(' ; ')}` : '',
      'Vérifier le résultat et conserver un rollback si une modification est appliquée.',
    ].filter(Boolean).join(' ');

    const expertThreadId = String(threadId || originalPayload.expert_thread_id || row.id || '');
    const expertRepository = String(
      originalPayload.repository || originalPayload.expert_repository || ''
    ).trim();
    let actionType = '';
    let actionPayload = {
      expert_thread_id: expertThreadId,
      expert_repository: expertRepository,
    };
    if (action === 'retry') {
      actionType = String(row.action_type || '');
      actionPayload = {
        ...originalPayload,
        expert_thread_id: expertThreadId,
        expert_repository: expertRepository,
      };
    } else if (action === 'evolution') {
      actionPayload = {
        repository: expertRepository,
        base_branch: String(originalPayload.base_branch || 'main').trim() || 'main',
        expert_origin: String(row.id || ''),
        expert_thread_id: expertThreadId,
        expert_repository: expertRepository,
      };
    }

    return this.candidate({
      domain: String(row.domain || 'aura'),
      kind,
      title: `Expert · ${String(row.title || 'remédiation AURA')}`,
      objective,
      rationale:
        `Second avis autonome après échec de l’initiative ${row.id}. `
        + `Risque expert=${String(advice.risk_level || 'review')}. `
        + `L’expert ne possède aucun outil; AURA reste l’autorité d’exécution.`,
      priority: Math.min(0.99, Number(row.priority || 0.6) + 0.06),
      confidence: Number(advice.confidence || 0),
      requested_risks: originalRisks,
      action_type: actionType,
      action_payload: actionPayload,
      signature: `expert:${row.id}:${String(advice.fingerprint || '')}:${action}`,
    });
  }

  async consultFailedInitiatives(limit = 2) {
    if (!this.expertBridge?.status?.({ publicView: false })?.available) return [];

    const threshold = new Date(
      Date.now() - Math.max(60, config.expertBridgeCooldownSeconds) * 1000,
    ).toISOString();
    const rows = await query(
      `SELECT i.*
       FROM aura_initiatives i
       WHERE i.status='failed'
         AND NOT EXISTS (
           SELECT 1 FROM aura_command_events e
           WHERE e.initiative_id=i.id
             AND e.kind='expert-consultation'
             AND e.created_at>=?
         )
       ORDER BY i.priority DESC,i.updated_at DESC
       LIMIT ?`,
      [threshold, Math.max(1, Math.min(Number(limit || 2), 4))],
    );

    const candidates = [];
    for (const row of rows) {
      const originalPayload = parseJson(row.action_payload, {});
      const threadId = String(originalPayload.expert_thread_id || row.id || '');
      const historyRows = await query(
        `SELECT payload,created_at
         FROM aura_command_events
         WHERE initiative_id=? AND kind='expert-thread'
         ORDER BY created_at DESC
         LIMIT ?`,
        [threadId, config.expertBridgeMaxRoundsPerIncident],
      );
      if (historyRows.length >= config.expertBridgeMaxRoundsPerIncident) {
        await query(
          'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
          [
            row.id,
            'expert-consultation',
            JSON.stringify({
              ok: false,
              skipped: true,
              reason: 'incident-round-limit',
              thread_id: threadId,
              rounds: historyRows.length,
            }).slice(0, 30000),
            now(),
          ],
        );
        continue;
      }
      const dialogueHistory = [...historyRows]
        .reverse()
        .map((item) => parseJson(item.payload, {}))
        .filter((item) => item && typeof item === 'object');

      const context = {
        incident_type: 'aura-initiative-failure',
        initiative: {
          id: row.id,
          domain: row.domain,
          kind: row.kind,
          title: row.title,
          objective: row.objective,
          rationale: row.rationale,
          execution_mode: row.execution_mode,
          attempts: Number(row.attempts || 0),
          error: row.error,
          result: parseJson(row.result, {}),
          action_type: row.action_type,
          action_payload: parseJson(row.action_payload, {}),
          requested_risks: parseJson(row.requested_risks, []),
        },
        expert_dialogue: {
          thread_id: threadId,
          round: dialogueHistory.length + 1,
          previous_turns: dialogueHistory,
        },
        governance: {
          operational_role: 'AURA dirige les opérations quotidiennes',
          human_only: [
            'secrets ou credentials',
            'suppression irréversible',
            'engagement juridique ou financier',
            'autorité fondatrice',
            'élévation de privilèges',
            'décision stratégique réservée au fondateur',
          ],
        },
      };

      const advice = await this.expertBridge.consult(context);
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [
          row.id,
          'expert-consultation',
          JSON.stringify({ ...advice, thread_id: threadId }).slice(0, 30000),
          now(),
        ],
      );
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [
          threadId,
          'expert-thread',
          JSON.stringify({
            round: dialogueHistory.length + 1,
            incident_id: row.id,
            title: row.title,
            execution_mode: row.execution_mode,
            error: row.error,
            result: parseJson(row.result, {}),
            advice,
          }).slice(0, 30000),
          now(),
        ],
      );

      const candidate = this.expertRemediationCandidate(row, advice, threadId);
      if (!candidate) continue;
      candidates.push(candidate);
      await query(
        'INSERT INTO aura_command_events(initiative_id,kind,payload,created_at) VALUES(?,?,?,?)',
        [
          row.id,
          'expert-remediation-proposed',
          JSON.stringify(candidate).slice(0, 30000),
          now(),
        ],
      );
    }
    return candidates;
  }

  async promoteDirectorPullRequests() {
    if (
      !config.directorModeEnabled
      || !config.directorAutoMergeLowRisk
      || !this.githubToken
    ) return [];

    const stamp = Date.now();
    if (
      this.lastDirectorPromotionMs
      && stamp - this.lastDirectorPromotionMs < config.directorPromotionPollSeconds * 1000
    ) return [];
    this.lastDirectorPromotionMs = stamp;

    const promotions = [];
    for (const repository of config.commandCenterGithubRepos) {
      const repo = String(repository || '').trim();
      if (!repo.includes('/')) continue;

      const pullsResponse = await this.github(
        `/repos/${repo}/pulls?state=open&per_page=30`,
      ).catch(() => ({ data: [] }));
      const pulls = Array.isArray(pullsResponse.data) ? pullsResponse.data : [];

      for (const pull of pulls) {
        const headRef = String(pull?.head?.ref || '');
        const baseRef = String(pull?.base?.ref || '');
        const headRepository = String(pull?.head?.repo?.full_name || '').toLowerCase();
        const pullActor = String(pull?.user?.login || '').toLowerCase();
        const headActor = String(
          pull?.head?.user?.login
          || pull?.head?.repo?.owner?.login
          || '',
        ).toLowerCase();
        const trustedActors = config.directorTrustedGithubActors;
        const trustedProvenance = headRepository === repo.toLowerCase()
          && Boolean(pullActor)
          && trustedActors.has(pullActor)
          && (!headActor || trustedActors.has(headActor));
        const auraBranch = headRef.startsWith('aura/change-')
          || headRef.startsWith('aura-evolution/')
          || headRef.startsWith('aura-evolution-fleet/');
        if (!auraBranch || !trustedProvenance || pull?.draft || baseRef !== 'main') continue;

        const number = Number(pull?.number || 0);
        const headSha = String(pull?.head?.sha || '');
        if (!number || !headSha) continue;

        const filesResponse = await this.github(
          `/repos/${repo}/pulls/${number}/files?per_page=100`,
        ).catch(() => ({ data: [] }));
        const files = Array.isArray(filesResponse.data) ? filesResponse.data : [];
        if (!files.length || files.length > config.directorMergeMaxFiles) continue;

        const safeFiles = files.every((file) => {
          const path = String(file?.filename || '');
          const status = String(file?.status || '');
          const safe = safeGithubChangePath(path);
          const changes = Number(file?.changes || 0);
          const allowedAutomergeSurface = config.directorAutoMergePathPrefixes.some((prefix) =>
            path.startsWith(String(prefix || '')));
          const sensitivePath = /(^|\/)(auth|oauth|security|policy|permissions?|config|database|migrations?|billing|payments?|identity|vault)(\/|\.|$)/i.test(path);
          const patch = String(file?.patch || '');
          const sensitivePatch = /(process\.env|secrets?|credentials?|private[_-]?key|child_process|\bexec\s*\(|\bspawn\s*\(|subprocess|os\.system|\bDROP\s+TABLE\b|\bTRUNCATE\b)/i.test(patch);
          return Boolean(safe)
            && safe === path
            && allowedAutomergeSurface
            && !sensitivePath
            && !sensitivePatch
            && ['added', 'modified'].includes(status)
            && changes <= config.directorMergeMaxChanges;
        });
        const totalChanges = files.reduce((sum, file) => sum + Number(file?.changes || 0), 0);
        if (!safeFiles || totalChanges > config.directorMergeMaxChanges) continue;

        const reviewsResponse = await this.github(
          `/repos/${repo}/pulls/${number}/reviews?per_page=100`,
        ).catch(() => ({ data: [] }));
        const reviews = Array.isArray(reviewsResponse.data) ? reviewsResponse.data : [];
        const latestReviewByUser = new Map();
        for (const review of reviews) {
          const login = String(review?.user?.login || '');
          if (!login) continue;
          latestReviewByUser.set(login, String(review?.state || '').toUpperCase());
        }
        if ([...latestReviewByUser.values()].includes('CHANGES_REQUESTED')) continue;

        const checksResponse = await this.github(
          `/repos/${repo}/commits/${headSha}/check-runs?per_page=100`,
        ).catch(() => ({ data: { check_runs: [] } }));
        const checks = Array.isArray(checksResponse.data?.check_runs)
          ? checksResponse.data.check_runs
          : [];
        if (checks.length < config.directorMergeMinChecks) continue;
        const checksGreen = checks.every((check) =>
          String(check?.status || '') === 'completed'
          && ['success', 'neutral', 'skipped'].includes(String(check?.conclusion || ''))
        );
        if (!checksGreen) continue;

        const statusResponse = await this.github(
          `/repos/${repo}/commits/${headSha}/status`,
        ).catch(() => ({ data: { statuses: [] } }));
        const statuses = Array.isArray(statusResponse.data?.statuses)
          ? statusResponse.data.statuses
          : [];
        if (statuses.some((status) =>
          ['failure', 'error', 'pending'].includes(String(status?.state || '').toLowerCase())
        )) continue;

        const merged = await this.github(
          `/repos/${repo}/pulls/${number}/merge`,
          {
            method: 'PUT',
            body: {
              merge_method: 'squash',
              commit_title: `AURA Director: ${String(pull?.title || 'low-risk improvement').slice(0,180)}`,
              commit_message:
                'Promotion autonome faible risque après validation des fichiers, des revues et des checks GitHub.',
            },
          },
        ).catch(() => ({ data: { merged: false } }));

        if (!merged.data?.merged) continue;
        const promotion = {
          repository: repo,
          pull_request_number: number,
          pull_request_url: String(pull?.html_url || ''),
          head_sha: headSha,
          changed_files: files.map((file) => String(file.filename || '')),
          total_changes: totalChanges,
          merged_sha: String(merged.data?.sha || ''),
          policy: 'director-low-risk-green-checks-only',
          merged_at: now(),
        };
        promotions.push(promotion);
        await this.kernel.trace(
          'director-promotion',
          `Promotion autonome · ${repo}#${number}`,
          'PR AURA faible risque fusionnée après checks verts.',
          promotion,
        ).catch(() => {});
        await this.kernel.observeEvent(
          'aura.director.merge.success',
          promotion,
          'command-center',
        ).catch(() => {});
        break;
      }
      if (promotions.length >= 1) break;
    }
    return promotions;
  }

  async resumeQueuedMissionInitiative() {
    const row = await one(
      `SELECT i.*
       FROM aura_initiatives i
       JOIN aura_mission_steps ms ON ms.initiative_id=i.id
       JOIN aura_missions m ON m.id=ms.mission_id
       WHERE i.status='queued'
         AND ms.status='queued'
         AND m.status IN ('running','waiting')
       ORDER BY m.priority DESC,ms.position ASC,i.updated_at ASC
       LIMIT 1`,
    );
    if (!row) return null;
    return this.executeInitiative(row);
  }

  async resumeQueuedPortfolioInitiatives() {
    const rows = await query(
      `SELECT i.*
       FROM aura_initiatives i
       WHERE i.status='queued'
         AND NOT EXISTS (
           SELECT 1 FROM aura_mission_steps ms WHERE ms.initiative_id=i.id
         )
       ORDER BY i.priority DESC,i.confidence DESC,i.updated_at ASC
       LIMIT ?`,
      [Math.max(1, config.commandCenterPortfolioWorkstreams * 3)],
    );
    if (!rows.length) return [];

    const selected = [];
    const domains = new Set();
    const repositories = new Set();
    let sideEffectSelected = false;
    for (const row of rows) {
      if (selected.length >= config.commandCenterPortfolioWorkstreams) break;
      const domain = String(row.domain || 'aura');
      if (domains.has(domain)) continue;
      const payload = parseJson(row.action_payload, {});
      const repository = String(payload.repository || '').trim().toLowerCase();
      const sideEffecting = ['operator','github'].includes(String(row.kind || ''));
      if (repository && repositories.has(repository)) continue;
      if (sideEffecting && sideEffectSelected) continue;
      selected.push(row);
      domains.add(domain);
      if (repository) repositories.add(repository);
      if (sideEffecting) sideEffectSelected = true;
    }
    if (!selected.length) return [];

    const safe = selected.filter((row) => !['operator','github'].includes(String(row.kind || '')));
    const sideEffect = selected.find((row) => ['operator','github'].includes(String(row.kind || ''))) || null;
    const settled = await Promise.allSettled(safe.map((row) => this.executeInitiative(row)));
    const results = settled.map((item, index) =>
      item.status === 'fulfilled'
        ? item.value
        : {
          id: safe[index]?.id || '',
          status: 'failed',
          error: safeOperationalError(item.reason, 1000),
        });
    if (sideEffect) {
      try {
        results.push(await this.executeInitiative(sideEffect));
      } catch (error) {
        results.push({
          id: sideEffect.id,
          status: 'failed',
          error: safeOperationalError(error, 1000),
        });
      }
    }
    return results;
  }

  async runCycle(trigger = 'manual') {
    const admission=this.kernel.authorizeAutonomous('command-center');
    if(!admission.allowed)
      return {ok:false,skipped:true,reason:'central-workspace-denied:'+admission.reason};
    if (!config.commandCenterEnabled) {
      return { ok: false, skipped: true, reason: 'command center disabled' };
    }
    if (this.running) {
      return { ok: true, skipped: true, reason: 'command center cycle already running' };
    }
    this.running = true;
    try {
      const reconciled = await this.reconcileWaiting();
      const resumedMissionInitiative = await this.resumeQueuedMissionInitiative().catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return null;
      });
      if (resumedMissionInitiative) {
        this.lastCycleAt = now();
        return {
          ok: true,
          trigger,
          mode: 'long-horizon-resume',
          reconciled,
          initiative: resumedMissionInitiative,
        };
      }
      const resumedPortfolio = await this.resumeQueuedPortfolioInitiatives().catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return [];
      });
      if (resumedPortfolio.length) {
        this.lastCycleAt = now();
        this.lastError = '';
        return {
          ok: true,
          trigger,
          mode: 'portfolio-resume',
          reconciled,
          workstreams: resumedPortfolio,
        };
      }
      const promotions = await this.promoteDirectorPullRequests().catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return [];
      });
      if (await this.countRecentInitiatives() >= config.commandCenterMaxInitiativesPerHour) {
        this.lastCycleAt = now();
        return {
          ok: true,
          reconciled,
          promotions,
          skipped: true,
          reason: 'initiative hourly budget reached',
        };
      }
      const missionAdvance = await this.longHorizon.nextCandidate().catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return { enabled: true, error: this.lastError };
      });
      if (missionAdvance?.candidate && missionAdvance?.step?.id) {
        // Keep the atomic claim alive during slow inference, research or
        // execution. Releasing requires the original unique lease token.
        const leaseHeartbeat = setInterval(() => {
          void this.longHorizon.renewLease(missionAdvance.lease).catch((error) => {
            this.lastError = String(error?.message || error).slice(0, 1000);
          });
        }, 60_000);
        leaseHeartbeat.unref?.();
        try {
        const missionCandidate = this.candidate(missionAdvance.candidate);
        const persisted = await this.persistInitiative(missionCandidate);
        const initiative = await one(
          'SELECT * FROM aura_initiatives WHERE id=?',
          [String(persisted.initiative?.id || '')],
        );
        if (!initiative) throw new Error('initiative de mission introuvable après persistance');
        await this.longHorizon.bindInitiative(missionAdvance.step.id, initiative.id);
        const missionResult = initiative.status === 'queued'
          ? await this.executeInitiative(initiative)
          : {
            id: initiative.id,
            status: initiative.status,
            execution_mode: initiative.execution_mode || '',
            result: parseJson(initiative.result, {}),
            deduplicated: true,
          };
        this.lastCycleAt = now();
        this.lastError = '';
        return {
          ok: true,
          trigger,
          mode: 'long-horizon-mission',
          reconciled,
          promotions,
          mission: missionAdvance.mission,
          mission_step: missionAdvance.step,
          initiative: missionResult,
        };
        } finally {
          clearInterval(leaseHeartbeat);
          // The lease is held through persistence + execution, including errors.
          await this.longHorizon.releaseLease(missionAdvance.lease).catch((error) => {
            this.lastError = String(error?.message || error).slice(0, 1000);
          });
        }
      }
      const expertCandidates = await this.consultFailedInitiatives(2).catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return [];
      });
      const fleet = await this.scanGithubFleet().catch((error) => {
        this.lastError = String(error?.message || error).slice(0, 1000);
        return this.fleetSnapshot;
      });
      const candidates = [
        ...expertCandidates,
        ...this.githubCandidates(fleet),
        ...(await this.buildCandidates()),
      ].sort((a, b) => (b.priority + b.confidence * 0.15) - (a.priority + a.confidence * 0.15));
      const selected = [];
      const domains = new Set();
      for (const candidate of candidates) {
        if (selected.length >= config.commandCenterPortfolioWorkstreams) break;
        const domain = String(candidate.domain || 'aura');
        if (domains.has(domain)) continue;
        const persisted = await this.persistInitiative(candidate);
        if (!persisted.created) continue;
        selected.push(persisted.initiative);
        domains.add(domain);
      }
      this.lastCycleAt = now();
      if (!selected.length) {
        return {
          ok: true,
          reconciled,
          promotions,
          expert_candidates: expertCandidates.length,
          long_horizon: missionAdvance,
          skipped: true,
          reason: 'all candidates are cooling down',
          candidates: candidates.length,
        };
      }

      const repositoriesInFlight = new Set();
      const immediate = [];
      const queued = [];
      for (const initiative of selected) {
        const payload = parseJson(initiative.action_payload, {});
        const repository = String(payload.repository || '').toLowerCase();
        const sideEffecting = ['operator','github'].includes(String(initiative.kind || ''));
        const repositoryBusy = repository && repositoriesInFlight.has(repository);
        if (sideEffecting || repositoryBusy) {
          queued.push({
            id: initiative.id,
            domain: initiative.domain,
            kind: initiative.kind,
            status: initiative.status,
            execution_mode: 'portfolio-queued',
          });
          continue;
        }
        if (repository) repositoriesInFlight.add(repository);
        immediate.push(initiative);
      }

      const settled = await Promise.allSettled(immediate.map((initiative) =>
        this.executeInitiative(initiative)));
      const results = settled.map((item, index) =>
        item.status === 'fulfilled'
          ? item.value
          : {
            id: immediate[index]?.id || '',
            status: 'failed',
            error: safeOperationalError(item.reason, 1000),
          });
      this.lastError = '';
      return {
        ok: true,
        trigger,
        mode: 'portfolio-workstreams',
        candidate_count: candidates.length,
        reconciled,
        promotions,
        expert_candidates: expertCandidates.length,
        long_horizon: missionAdvance,
        workstreams: [...results, ...queued],
      };
    } catch (error) {
      this.lastError = String(error?.message || error).slice(0, 1000);
      throw error;
    } finally {
      this.running = false;
    }
  }

  async missions(limit = 20, status = '') {
    return this.longHorizon.list(limit, status);
  }

  async mission(id) {
    return this.longHorizon.get(id);
  }

  async createMission(input = {}) {
    return this.longHorizon.createMission({
      ...input,
      trigger: String(input.trigger || 'private-api'),
    });
  }

  async controlMission(id, action) {
    const missionId = String(id || '');
    const command = String(action || '').toLowerCase();
    if (command === 'cancel' && this.bridge?.cancelJob) {
      const rows = await query(
        `SELECT i.id,i.result
         FROM aura_mission_steps ms
         JOIN aura_initiatives i ON i.id=ms.initiative_id
         WHERE ms.mission_id=? AND i.status IN ('queued','running','waiting')`,
        [missionId],
      ).catch(() => []);
      for (const row of rows) {
        const stored = parseJson(row.result, {});
        const jobId = String(stored?.job_id || stored?.result?.job_id || '').trim();
        if (!jobId) continue;
        await this.bridge.cancelJob(jobId, `mission ${missionId} cancelled`).catch(() => {});
      }
    }
    return this.longHorizon.control(missionId, command);
  }

  async retryInitiative(id) {
    const row = await one('SELECT * FROM aura_initiatives WHERE id=?', [String(id)]);
    if (!row) throw new Error('initiative inconnue');
    if (ACTIVE_STATUSES.has(String(row.status || '')) && row.status !== 'waiting') {
      throw new Error(`initiative déjà active: ${row.status}`);
    }
    return this.executeInitiative(row);
  }

  async operationalLedger(limit = 24) {
    const bounded = Math.max(1, Math.min(Number(limit) || 24, 80));
    const rows = await query(
      `SELECT e.id,e.initiative_id,e.kind,e.created_at,
              i.domain,i.title,i.kind AS initiative_kind,i.status,i.execution_mode,i.updated_at
       FROM aura_command_events e
       LEFT JOIN aura_initiatives i ON i.id=e.initiative_id
       WHERE e.kind IN (
         'initiative-created','initiative-result','initiative-error','initiative-superseded',
         'service-observation','service-state-change','service-heartbeat-expired',
         'director-promotion','expert-remediation-proposed'
       )
       ORDER BY e.id DESC LIMIT ?`,
      [bounded],
    );
    return rows.map((row) => ({
      receipt_id: Number(row.id || 0),
      initiative_id: String(row.initiative_id || ''),
      event: String(row.kind || ''),
      domain: String(row.domain || 'quantic-sillage'),
      title: String(row.title || row.kind || 'Activité AURA').slice(0, 240),
      kind: String(row.initiative_kind || row.kind || ''),
      status: String(row.status || ''),
      execution_mode: String(row.execution_mode || ''),
      created_at: row.created_at,
      updated_at: row.updated_at || row.created_at,
    }));
  }

  async portfolioSnapshot() {
    await this.refreshProductHealth().catch(() => []);
    const [services, active] = await Promise.all([
      this.services(),
      query(
        `SELECT domain,
          COUNT(*) AS active_count,
          SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running_count,
          SUM(CASE WHEN status='waiting' THEN 1 ELSE 0 END) AS waiting_count,
          MAX(updated_at) AS last_work_at
         FROM aura_initiatives
         WHERE status IN ('queued','running','waiting')
         GROUP BY domain`,
      ),
    ]);
    const byDomain = new Map(active.map((row) => [String(row.domain || ''), row]));
    const stamp = Date.now();
    return services
      .filter((service) => ['quantic-product','product'].includes(String(service.kind || '')))
      .map((service) => {
        const work = byDomain.get(String(service.id || '')) || {};
        const observedMs = Date.parse(String(service.last_observed_at || ''));
        const ageSeconds = Number.isFinite(observedMs)
          ? Math.max(0, Math.round((stamp - observedMs) / 1000))
          : null;
        return {
          id: service.id,
          name: service.name,
          state: service.state,
          detail: String(service.state_detail || '').slice(0, 400),
          criticality: Number(service.criticality || 0),
          last_observed_at: service.last_observed_at || '',
          heartbeat_age_seconds: ageSeconds,
          active_workstreams: Number(work.active_count || 0),
          running_workstreams: Number(work.running_count || 0),
          waiting_workstreams: Number(work.waiting_count || 0),
          last_work_at: String(work.last_work_at || ''),
          repository: String(service.repository || ''),
        };
      });
  }

  companyReadiness({ services = [], portfolio = [], receipts = [], bridgeStatus = {} } = {}) {
    const products = services.filter((item) =>
      ['quantic-product','product'].includes(String(item.kind || '')));
    const observed = products.filter((item) => Boolean(item.last_observed_at));
    const observedRatio = products.length ? observed.length / products.length : 0;
    const healthyStates = new Set(['online','healthy']);
    const healthyRatio = products.length
      ? products.filter((item) => healthyStates.has(String(item.state || '').toLowerCase())).length / products.length
      : 0;
    const byId = new Map(products.map((item) => [String(item.id || ''), item]));
    const studio = byId.get('quantic-studio');
    const vault = byId.get('identity-vault');
    const expectedScoped = products.filter((item) => String(item.id || '') !== 'aura').length;
    const configuredScoped = Object.keys(config.productTokens || {}).filter((id) => byId.has(id)).length;
    const scopedRatio = expectedScoped ? Math.min(1, configuredScoped / expectedScoped) : 0;

    const lowRiskPrefixes = config.directorAutoMergePathPrefixes.every((prefix) =>
      ['docs/','test/','tests/'].includes(String(prefix || '')));
    const dimensions = {
      product_connectivity: Number(Math.min(10, 4 + observedRatio * 6).toFixed(1)),
      parallel_portfolio: Number(Math.min(10, 5 + Math.min(config.commandCenterPortfolioWorkstreams, 5)).toFixed(1)),
      product_health: Number(Math.min(
        10,
        6
          + (config.commandCenterProductStaleSeconds <= 600 ? 1 : 0)
          + (config.commandCenterProductOfflineSeconds <= 1800 ? 1 : 0)
          + Math.min(2, healthyRatio * 2),
      ).toFixed(1)),
      quantic_studio: Number((
        studio
          ? 4 + (studio.last_observed_at ? 3 : 0) + (healthyStates.has(String(studio.state || '').toLowerCase()) ? 3 : 0)
          : 0
      ).toFixed(1)),
      identity_vault: Number((
        vault
          ? 5 + (vault.last_observed_at ? 2.5 : 0) + (healthyStates.has(String(vault.state || '').toLowerCase()) ? 2.5 : 0)
          : 0
      ).toFixed(1)),
      identity_isolation: Number(Math.min(
        10,
        (!config.allowLegacyBridgeAdminToken && !config.allowLegacyProductAdminToken ? 3 : 0)
          + (config.bridgeToken ? 3 : 0)
          + scopedRatio * 4,
      ).toFixed(1)),
      csrf_admin: 9,
      autonomous_merge: Number((
        config.directorMergeMinChecks >= 2 && lowRiskPrefixes ? 9 : 6
      ).toFixed(1)),
      visible_work_evidence: Number(Math.min(10, 4 + Math.min(receipts.length, 12) / 12 * 6).toFixed(1)),
    };
    const values = Object.values(dimensions);
    const overall = values.length
      ? Number((values.reduce((sum, value) => sum + Number(value || 0), 0) / values.length).toFixed(1))
      : 0;
    return {
      scale: 10,
      overall,
      target: 8,
      target_met: overall >= 8,
      dimensions,
      evidence: {
        products_total: products.length,
        products_observed: observed.length,
        products_healthy: products.filter((item) => healthyStates.has(String(item.state || '').toLowerCase())).length,
        product_tokens_configured: configuredScoped,
        product_tokens_expected: expectedScoped,
        bridge_token_configured: Boolean(config.bridgeToken),
        runtime_worker_online: Boolean(bridgeStatus?.worker_online),
        portfolio_workstreams: config.commandCenterPortfolioWorkstreams,
        receipts_considered: receipts.length,
        live_portfolio_rows: portfolio.length,
      },
      blockers: [
        !config.bridgeToken ? 'AURA_BRIDGE_TOKEN absent' : '',
        configuredScoped < expectedScoped
          ? `Identités produit configurées: ${configuredScoped}/${expectedScoped}`
          : '',
        observedRatio < 0.8 ? `Produits observés: ${observed.length}/${products.length}` : '',
        studio && !studio.last_observed_at ? 'Quantic Studio sans télémétrie récente' : '',
        vault && !vault.last_observed_at ? 'Identity Vault sans télémétrie récente' : '',
      ].filter(Boolean),
    };
  }

  async status({ publicView = true } = {}) {
    const [counts, bridgeStatus, services, longHorizon, portfolio, receipts] = await Promise.all([
      one(
        `SELECT COUNT(*) AS total,
          SUM(CASE WHEN status='queued' THEN 1 ELSE 0 END) AS queued,
          SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running,
          SUM(CASE WHEN status='waiting' THEN 1 ELSE 0 END) AS waiting,
          SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
          SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed
         FROM aura_initiatives`,
      ),
      this.bridge?.status?.() || Promise.resolve({ enabled: false, worker_online: false }),
      this.services(),
      this.longHorizon.status().catch(() => ({ enabled: false, error: 'unavailable' })),
      this.portfolioSnapshot().catch(() => []),
      this.operationalLedger(24).catch(() => []),
    ]);
    const degraded = services.filter((item) => BAD_SERVICE_STATES.has(String(item.state || '').toLowerCase()));
    const fleet = this.fleetSnapshot || [];
    const fleetObserved = fleet.filter((item) => item.state !== 'unknown');
    const fleetScore = fleetObserved.length
      ? Math.round(fleetObserved.reduce((sum, item) => sum + Number(item.health_score || 0), 0) / fleetObserved.length)
      : null;
    const topInitiative = await one(
      `SELECT id,domain,kind,title,objective,priority,confidence,status,execution_mode,updated_at
       FROM aura_initiatives
       WHERE status IN ('queued','running','waiting')
       ORDER BY priority DESC,confidence DESC,updated_at DESC LIMIT 1`,
    );
    const companyReadiness = this.companyReadiness({
      services,
      portfolio,
      receipts,
      bridgeStatus,
    });
    const payload = {
      version: CommandCenter.VERSION,
      enabled: config.commandCenterEnabled,
      started: this.started,
      running: this.running,
      auto_execute: config.commandCenterAutoExecute,
      autonomy_mode: config.directorModeEnabled
        ? 'director-autonomous-operations'
        : 'continuous-native-initiative-with-bounded-execution',
      director_mode: config.directorModeEnabled,
      long_horizon: longHorizon,
      autonomous_low_risk_promotion: config.directorAutoMergeLowRisk,
      creator_role: 'créateur et autorité fondatrice',
      aura_role: 'directrice opérationnelle de Quantic Sillage',
      web_substrate: this.webSubstrate?.status?.() || { enabled: false },
      expert_bridge: this.expertBridge?.status?.({ publicView }) || {
        enabled: false,
        available: false,
      },
      tick_seconds: config.commandCenterTickSeconds,
      max_initiatives_per_hour: config.commandCenterMaxInitiativesPerHour,
      min_confidence: config.commandCenterMinConfidence,
      local_worker_online: Boolean(bridgeStatus?.worker_online),
      github_write_authority: Boolean(this.githubToken),
      monitored_repositories: config.commandCenterGithubRepos.length,
      portfolio_workstreams: config.commandCenterPortfolioWorkstreams,
      product_health_ttl: {
        stale_seconds: config.commandCenterProductStaleSeconds,
        offline_seconds: config.commandCenterProductOfflineSeconds,
      },
      portfolio,
      recent_receipts: receipts,
      company_readiness: companyReadiness,
      fleet: {
        score: fleetScore,
        healthy: fleet.filter((item) => item.state === 'healthy').length,
        degraded: fleet.filter((item) => item.state === 'degraded').length,
        unavailable: fleet.filter((item) => ['error','unknown'].includes(item.state)).length,
        last_scan_at: this.lastFleetPollAt,
      },
      top_initiative: topInitiative ? {
        id: topInitiative.id,
        domain: topInitiative.domain,
        kind: topInitiative.kind,
        title: topInitiative.title,
        objective: String(topInitiative.objective || '').slice(0, 500),
        priority: Number(topInitiative.priority || 0),
        confidence: Number(topInitiative.confidence || 0),
        status: topInitiative.status,
        execution_mode: topInitiative.execution_mode,
        updated_at: topInitiative.updated_at,
      } : null,
      last_cycle_at: this.lastCycleAt,
      last_action_at: this.lastActionAt,
      last_error: this.lastError,
      services: {
        total: services.length,
        degraded: degraded.length,
        observed: services.filter((item) => item.last_observed_at).length,
      },
      counts: {
        total: Number(counts?.total || 0),
        queued: Number(counts?.queued || 0),
        running: Number(counts?.running || 0),
        waiting: Number(counts?.waiting || 0),
        completed: Number(counts?.completed || 0),
        failed: Number(counts?.failed || 0),
      },
    };
    if (!publicView) {
      payload.allowed_risks = [...config.commandCenterAllowedRisks];
      payload.service_registry = services;
      payload.repository_fleet = fleet;
    }
    return payload;
  }
}
