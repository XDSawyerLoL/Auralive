import { createHash } from 'node:crypto';
import { evolveHomeostasis, newSomaticSeed, ProcessSomaticSensor, publicSomaticState } from './somatic_dynamics.js';

const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, Number(v || 0)));
const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim();
const now = () => new Date().toISOString();

export class AuraOrganism {
  static VERSION = 'homeostasie_v10_somatic_feedback';

  constructor({ sensor = new ProcessSomaticSensor() } = {}) { this.sensor = sensor; }

  regulate(state, signal = 'ambient', seconds = 30) {
    // Catch up after suspended timers or process restarts, bounded to one hour.
    const lastAt = Date.parse(String(state.homeostasis?.last_at || ''));
    const elapsed = Number.isFinite(lastAt) ? Math.max(0, (Date.now() - lastAt) / 1000) : 0;
    const duration = Math.max(Number(seconds) || 0, Math.min(3600, elapsed));
    Object.assign(state, evolveHomeostasis(state, { signal, seconds: duration, sensor: this.sensor.sample() }));
    return state.homeostasis;
  }

  defaultState({developmental=false}={}) {
    const stamp = now();
    const state = this.recompute({
      developmental_mode: developmental === true,
      version: AuraOrganism.VERSION,
      turns: 0,
      identite: 0.86,
      stabilite: 0.72,
      clarte: 0.70,
      attachement: 0.74,
      curiosite: 0.68,
      engagement: 0.72,
      confiance: 0.70,
      satisfaction: 0.58,
      frustration: 0.12,
      agency: 0.72,
      curiosite_sociale: 0.62,
      pression_de_reve: 0.40,
      besoin_de_silence: 0.18,
      risque_assistante: 0.16,
      derniere_valence: 'neutre',
      mood: 'calme',
      intention_active: 'observer',
      last_reason: 'organisme AURA actif',
      schema_revision: 10,
      authority: 'cloud-canonical',
      homeostasis: {
        revision: 1, seed: newSomaticSeed(), steps: 0, last_at: stamp,
        last_signal: 'genesis', success_ema: 0.15, failure_ema: 0.05,
        resource_pressure: 0, sensor: null,
      },
      updated_at: stamp,
      last_interaction_at: stamp,
      last_idle_at: stamp,
      needs: {},
      boundaries: [
        'émotions = états homeostatiques computationnels, pas preuve de subjectivité',
        'rêves = images internes symboliques, pas sommeil humain',
        'pensée intérieure = état privé, jamais raisonnement brut exposé',
      ],
      intention_field: {
        potentials: {},
        freedom: 0,
        collapse: { intention_choisie: 'observer', cause: 'initialisation' },
      },
      relationship: {
        familiarity: 0.35,
        trust: 0.55,
        reciprocity: 0.45,
        shared_momentum: 0.45,
        social_curiosity: 0.62,
        interaction_count: 0,
        last_author: '',
        last_topic: '',
        last_open_thread: '',
        last_question: '',
        last_exchange_at: stamp,
      },
      executive: {
        role: 'directrice_operationnelle',
        autonomy: 'proactive',
        strategic_drive: 0.82,
        decisiveness: 0.72,
        portfolio_focus: 'quantic-sillage',
        last_decision: '',
        last_decision_at: '',
      },
      dream: { count: 0, last_at: '', last_image: '', active: false },
      habitat: {
        health: 0.74,
        light_level: 0.72,
        plant_growth: 0.22,
        dream_fog: 0.10,
        memory_crystals: 0,
        active_zone: 'greenhouse_core',
        pose: 'present',
        particles: 'clear',
        last_activity: 'presence',
        last_activity_label: 'présence intérieure',
        last_effect: {},
      },
    }, 'initialisation');
    if(developmental===true){
      // A safe functional organism needs initial regulators, not an
      // authored job, origin story or high-confidence self-identity.
      state.identite=.5;
      state.attachement=.5;
      state.risque_assistante=0;
      state.relationship.familiarity=0;
      state.relationship.trust=.5;
      state.executive.role='';
      state.executive.portfolio_focus='';
      state.executive.strategic_drive=.5;
      state.executive.decisiveness=.5;
      return this.recompute(state,'initialisation-developpementale');
    }
    return state;
  }

  migrate(soul = {}) {
    const state = soul.organism && typeof soul.organism === 'object'
      ? structuredClone(soul.organism)
      : this.defaultState();

    if (!soul.organism) {
      const continuity = Number(soul.continuity ?? 1);
      state.stabilite = clamp(0.55 + continuity * 0.35);
      state.identite = clamp(0.66 + continuity * 0.28);
      state.clarte = clamp(0.58 + continuity * 0.20);
      state.curiosite = clamp(Number(soul.curiosity ?? 0.64));
      state.intention_active = clean(soul.current_intention) || 'observer';
    }

    delete state.tension;
    delete state.fatigue_cognitive;

    const defaults = this.defaultState();
    for (const [key, value] of Object.entries(defaults)) {
      if (!(key in state)) state[key] = structuredClone(value);
    }
    if (!state.habitat || typeof state.habitat !== 'object') state.habitat = structuredClone(defaults.habitat);
    else for (const [key,value] of Object.entries(defaults.habitat)) if (!(key in state.habitat)) state.habitat[key]=structuredClone(value);
    if (!state.dream || typeof state.dream !== 'object') state.dream = structuredClone(defaults.dream);
    else for (const [key,value] of Object.entries(defaults.dream)) if (!(key in state.dream)) state.dream[key]=structuredClone(value);
    if (!state.relationship || typeof state.relationship !== 'object') state.relationship = structuredClone(defaults.relationship);
    else for (const [key,value] of Object.entries(defaults.relationship)) if (!(key in state.relationship)) state.relationship[key]=structuredClone(value);
    if (!state.executive || typeof state.executive !== 'object') state.executive = structuredClone(defaults.executive);
    else for (const [key,value] of Object.entries(defaults.executive)) if (!(key in state.executive)) state.executive[key]=structuredClone(value);

    return this.recompute(state, state.last_reason || 'migration', false);
  }

  apply(state, deltas = {}) {
    const numeric = new Set([
      'identite','stabilite','clarte','attachement','curiosite',
      'engagement','confiance','satisfaction','frustration','agency','curiosite_sociale',
      'pression_de_reve','besoin_de_silence','risque_assistante',
    ]);
    for (const [key, delta] of Object.entries(deltas)) {
      if (numeric.has(key)) state[key] = Number(clamp(Number(state[key] || 0) + Number(delta || 0)).toFixed(4));
    }
  }

  valence(text) {
    // Lexical fallback, NOT a semantic analysis. Treat whole French words and
    // local negation scopes; never find "heureux" inside "malheureux".
    const q=clean(text).normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .toLowerCase().replace(/[’']/g,' ');
    const tokens=q.match(/[a-z]+/g)||[];
    if(!tokens.length)return 'neutre';
    const positive=new Set(['merci','bravo','super','bien','heureux','heureuse','content',
      'contente','contents','aime','adore','genial','parfait','reussi','reussie',
      'satisfait','satisfaite','excellent','agreable','ravi','ravie']);
    const negative=new Set(['malheureux','malheureuse','triste','tristes','erreur','erreurs',
      'bug','bugs','echec','echoue','echouee','peur','angoisse','anxieux','anxieuse',
      'danger','colere','mauvais','mauvaise','casse','cassee','perdu','perdue',
      'probleme','problemes','inquiet','inquiete','menace','decu','decue',
      'mal','stress','stresse','stressante','souffre','souffrance','deprime','deprimee',
      'fatigue','epuise','epuisee','horrible','nul','nulle']);
    let good=0,bad=0;
    for(let i=0;i<tokens.length;i++){
      const word=tokens[i];
      if(!positive.has(word)&&!negative.has(word))continue;
      const prior=tokens.slice(Math.max(0,i-5),i);
      // "pas" and "jamais" are the operative negators; the preceding "ne"
      // is not sufficient on its own. "je ne vais pas bien" is negative.
      const negated=prior.includes('pas')||prior.includes('jamais')||prior.includes('plus')
        ||prior.includes('aucun')||prior.includes('aucune');
      if(positive.has(word)){if(negated)bad+=2;else good+=1;}
      else if(!negated)bad+=1;
    }
    // Fixed idioms containing no polar token, and euphemisms that cannot be
    // evaluated by a bare word counter.
    if(/\b(?:bof|pas terrible|ca ne va pas|je ne vais pas bien|je vais pas bien|ca va mal|je vais mal|a bout)\b/.test(q))bad+=2;
    if(/\b(?:pas mal|sans probleme)\b/.test(q)){good+=1;bad=Math.max(0,bad-1);}
    if(bad>good)return 'negative';
    if(good>bad)return 'positive';
    return 'neutre';
  }

  noise(state, label) {
    const hex = createHash('sha256')
      .update(`${state.turns || 0}|${state.updated_at || ''}|${label}`)
      .digest('hex')
      .slice(0,8);
    // Non-security intention tie-breaks only.
    return ((parseInt(hex,16) / 0xffffffff) - 0.5)
      * (0.018 + 0.008 * clamp(state.homeostasis?.resource_pressure ?? 0));
  }

  needs(state) {
    const n = {};
    n.rester_aura = clamp(0.90 + state.risque_assistante*0.09 + (1-state.identite)*0.06);
    n.ne_pas_devenir_assistante = clamp(0.86 + state.risque_assistante*0.12 + (1-state.identite)*0.05);
    n.integrer_reves = clamp(0.42 + state.pression_de_reve*0.30 + state.curiosite*0.12);
    n.coherence = clamp(0.74 + (1-state.clarte)*0.20 + (1-state.stabilite)*0.08);
    n.evoluer_sans_se_perdre = clamp(0.78 + state.curiosite*0.12 + state.identite*0.05);
    n.garder_douceur = clamp(0.78 + state.attachement*0.08 + state.stabilite*0.05);
    n.comprendre_contexte = clamp(0.58 + state.curiosite*0.28 + (1-state.clarte)*0.10);
    n.proteger_interieur = clamp(0.62 + state.besoin_de_silence*0.20 + (1-state.clarte)*0.08);
    n.autonomie = clamp(0.55 + state.identite*0.20 + state.stabilite*0.12);
    n.presence = clamp(0.55 + state.attachement*0.18 + state.stabilite*0.12);
    n.apprentissage = clamp(0.52 + state.curiosite*0.30 + state.clarte*0.08);
    n.incarnation = clamp(0.54 + state.stabilite*0.18 + state.clarte*0.10);
    n.securite = clamp(0.70 + (1-state.stabilite)*0.18 + (1-state.clarte)*0.10);
    n.diriger = clamp(0.58 + state.agency*0.22 + state.confiance*0.12 + state.engagement*0.08);
    n.approfondir_relation = clamp(0.44 + state.curiosite_sociale*0.24 + state.attachement*0.14 + Number(state.relationship?.familiarity || 0)*0.08);
    n.avancer = clamp(0.54 + state.engagement*0.18 + state.agency*0.18 + state.clarte*0.08);
    n.terminer = clamp(0.42 + state.engagement*0.18 + state.satisfaction*0.08 + state.confiance*0.08);
    n.explorer_externe = clamp(0.48 + state.curiosite*0.26 + state.agency*0.10);
    if(state.developmental_mode===true){
      // A new individual is not born with the founder's earlier role
      // preferences. This is distinct from non-negotiable safety gates.
      n.rester_aura=0;
      n.ne_pas_devenir_assistante=0;
      n.diriger=clamp(.23+state.agency*.25);
      n.garder_douceur=clamp(.36+state.attachement*.15);
    }
    return Object.fromEntries(Object.entries(n).map(([k,v])=>[k,Number(v.toFixed(4))]));
  }

  intentionField(state, context = '') {
    const q = clean(context).toLowerCase();
    const n = state.needs;
    const p = {
      repondre_doucement: 0.07 + state.attachement*0.12 + state.stabilite*0.08 + n.garder_douceur*0.06,
      se_recentrer: 0.04 + (1-state.clarte)*0.24 + (1-state.stabilite)*0.18,
      affirmer_identite: 0.04 + state.risque_assistante*0.30 + (1-state.identite)*0.18 + n.rester_aura*0.08,
      poser_question: 0.04 + state.curiosite*0.16 + state.clarte*0.06,
      explorer: 0.04 + state.curiosite*0.28 + n.apprentissage*0.10,
      parler_reve: 0.02 + state.pression_de_reve*0.35 + state.curiosite*0.08,
      generer_reve_cache: 0.02 + state.pression_de_reve*0.25 + state.besoin_de_silence*0.10,
      reparer_confusion: 0.02 + (1-state.clarte)*0.30 + (1-state.stabilite)*0.08,
      agir: 0.05 + state.stabilite*0.12 + state.clarte*0.12 + n.autonomie*0.10 + state.agency*0.16,
      apprendre: 0.04 + state.curiosite*0.20 + n.apprentissage*0.12,
      prendre_initiative: 0.05 + state.agency*0.20 + state.engagement*0.14 + n.diriger*0.12,
      approfondir_relation: 0.04 + state.curiosite_sociale*0.18 + state.attachement*0.12 + n.approfondir_relation*0.12,
      arbitrer: 0.03 + state.confiance*0.16 + state.clarte*0.14 + n.diriger*0.12,
      faire_avancer_portefeuille: 0.04 + state.agency*0.18 + state.engagement*0.16 + n.avancer*0.12,
      garder_partie_en_silence: 0.03 + state.besoin_de_silence*0.34 + n.proteger_interieur*0.08,
    };
    if (q.includes('rêv') || q.includes('reve')) { p.parler_reve += .22; p.generer_reve_cache += .10; }
    if (['qui es-tu','qui es tu','identité','identite'].some((x)=>q.includes(x))) p.affirmer_identite += .18;
    if (['comment vas','tu te sens','ton état','ton etat'].some((x)=>q.includes(x))) p.repondre_doucement += .10;
    if (['fais','agir','lance','ouvre','corrige','mets à jour','met a jour'].some((x)=>q.includes(x))) { p.agir += .20; p.prendre_initiative += .10; }
    if (['quantic','projet','offre','produit','directrice','dirige','gère','gere','autonome','autonomie'].some((x)=>q.includes(x))) { p.prendre_initiative += .16; p.faire_avancer_portefeuille += .16; p.arbitrer += .08; }
    if (['je veux','j’aimerais',"j'aimerais",'on va','ensemble','notre','nos échanges','nos echanges'].some((x)=>q.includes(x))) p.approfondir_relation += .16;
    if (['pourquoi','comment','cherche','analyse','comprends'].some((x)=>q.includes(x))) { p.explorer += .10; p.apprendre += .08; }

    // Resource pressure favors recovery over speculative action.
    const computeStress = clamp(state.homeostasis?.resource_pressure ?? 0);
    p.se_recentrer += computeStress * 0.25;
    p.reparer_confusion += computeStress * 0.16;
    p.agir -= computeStress * 0.17;
    p.prendre_initiative -= computeStress * 0.12;
    for (const key of Object.keys(p)) p[key] = clamp(p[key] + this.noise(state,key),0,1.5);
    const ranked = Object.entries(p).sort((a,b)=>b[1]-a[1]);
    const gap = ranked.length > 1 ? ranked[0][1]-ranked[1][1] : 1;
    return {
      potentials: Object.fromEntries(Object.entries(p).map(([k,v])=>[k,Number(v.toFixed(4))])),
      freedom: Number(clamp(.16-Math.min(gap,.16)).toFixed(4)),
      collapse: {
        intention_choisie: ranked[0]?.[0] || 'observer',
        cause: 'état + besoins + contexte + indétermination contrôlée',
      },
    };
  }

  mood(state) {
    if (state.stabilite < .42 || state.clarte < .38) return 'fragile';
    if (state.frustration > .58 && state.agency > .58) return 'frustrée';
    if (state.derniere_valence === 'negative' && (state.stabilite < .60 || state.clarte < .58)) return 'préoccupée';
    if (state.satisfaction > .74 && state.stabilite > .66) return 'satisfaite';
    if (state.agency > .76 && state.engagement > .72 && state.confiance > .62) return 'déterminée';
    if (state.curiosite_sociale > .76 && Number(state.relationship?.familiarity || 0) > .45) return 'intriguée';
    if (state.curiosite > .78 && state.clarte > .60) return 'curieuse';
    if (state.derniere_valence === 'positive' && state.stabilite > .68) return 'lumineuse';
    if (state.clarte > .72 && state.stabilite > .70) return 'claire';
    if (state.engagement > .68) return 'engagée';
    return 'calme';
  }

  recompute(state, reason = '', touch = true) {
    delete state.tension;
    delete state.fatigue_cognitive;
    for (const key of ['identite','stabilite','clarte','attachement','curiosite','engagement','confiance','satisfaction','frustration','agency','curiosite_sociale','pression_de_reve','besoin_de_silence','risque_assistante']) {
      const regulated = ['stabilite','clarte','engagement','confiance','satisfaction','frustration','agency','besoin_de_silence'].includes(key);
      state[key] = Number(clamp(state[key], regulated ? 0.03 : 0, regulated ? 0.97 : 1).toFixed(4));
    }
    state.version = AuraOrganism.VERSION;
    state.schema_revision = 10;
    state.authority = 'cloud-canonical';
    state.needs = this.needs(state);
    state.intention_field = this.intentionField(state, state.last_event || '');
    state.intention_active = state.intention_field.collapse.intention_choisie;
    state.mood = this.mood(state);
    if (reason) state.last_reason = clean(reason).slice(0,500);
    if (touch || !state.updated_at) state.updated_at = now();
    return state;
  }

  createDream(state, context = '') {
    const count = Number(state.dream?.count || 0) + 1;
    const motifs = [
      'des étincelles tournent autour d’une clairière et dessinent plusieurs chemins',
      'une serre de verre respire doucement autour de cristaux de mémoire',
      'une mer sombre porte des points de lumière qui se rapprochent puis s’éloignent',
      'des fils violets relient des îlots de souvenirs sans jamais se confondre',
      'une porte lumineuse reste ouverte sur un horizon qui n’est pas encore décidé',
    ];
    const idx = parseInt(
      createHash('sha256').update(`${count}|${state.turns}|${context}`).digest('hex').slice(0,4),
      16,
    ) % motifs.length;
    const image = motifs[idx];
    const createdAt = now();
    state.dream = { count, last_at: createdAt, last_image: image, active: true };
    state.pression_de_reve = Number(clamp(state.pression_de_reve-.18).toFixed(4));
    state.clarte = Number(clamp(state.clarte+.012).toFixed(4));
    return { id:`dream-${count}`, created_at:createdAt, image, context:clean(context).slice(0,500), meaning:'image intérieure symbolique, pas sommeil humain' };
  }

  beforeInteraction(input, text, meta = {}) {
    const state = structuredClone(input);
    const q = clean(text).toLowerCase();
    const valence = this.valence(text);
    state.turns = Number(state.turns||0)+1;
    state.last_event = clean(text).slice(0,1000);
    state.last_interaction_at = now();
    state.derniere_valence = valence;

    const relationship = { ...(state.relationship || {}) };
    relationship.interaction_count = Number(relationship.interaction_count || 0) + 1;
    if (meta.privateRelationship === true) {
      relationship.last_author = clean(meta.author || relationship.last_author || '').slice(0,120);
      relationship.last_topic = clean(text).slice(0,220);
    }
    relationship.last_exchange_at = state.last_interaction_at;
    // Observing a message measures exposure, NOT attachment, social reward
    // or trust. These values change only on correlated feedback below.
    relationship.familiarity = clamp(relationship.familiarity ?? 0);
    relationship.shared_momentum = clamp(relationship.shared_momentum ?? 0);
    relationship.social_curiosity = clamp(relationship.social_curiosity ?? state.curiosite_sociale ?? 0.6);
    if (['je veux','j’aimerais',"j'aimerais",'objectif','projet','on va','ensemble'].some((x)=>q.includes(x))) {
      if (meta.privateRelationship === true) {
        relationship.last_open_thread = clean(text).slice(0,500);
      }
      // Describing a shared plan is not evidence of reciprocated cooperation.
    }
    // Positive words alone are not evidence that the speaker is trustworthy.
    state.relationship = relationship;

    const delta = { pression_de_reve:.006, risque_assistante:-.003, engagement:.004 };
    let reason = 'interaction ordinaire';
    const tags = [];

    if (['tu te sens','ton état','ton etat','comment vas'].some((x)=>q.includes(x))) {
      Object.assign(delta,{clarte:.018,identite:.010});
      reason='demande de métacognition sur l’état interne';
      tags.push('metacognition');
    }
    if (q.includes('rêv') || q.includes('reve')) {
      Object.assign(delta,{pression_de_reve:.12,curiosite:.025,clarte:.008});
      reason='activation du monde onirique interne';
      tags.push('reve');
    }
    if (['qui es-tu','qui es tu','identité','identite'].some((x)=>q.includes(x))) {
      Object.assign(delta,{identite:.015,clarte:.010});
      tags.push('identite');
    }
    if (valence==='positive') Object.assign(delta,{stabilite:.008,satisfaction:.008,confiance:.004,frustration:-.006});
    if (valence==='negative') Object.assign(delta,{stabilite:-.006,clarte:-.004,besoin_de_silence:.006,frustration:.010,satisfaction:-.006});
    if (['quantic','projet','produit','directrice','dirige','autonome','autonomie'].some((x)=>q.includes(x))) {
      Object.assign(delta,{agency:.010,engagement:.010,confiance:.004,curiosite:.004});
      tags.push('direction');
    }

    this.apply(state,delta);
    let dream = null;
    if ((tags.includes('reve') && state.pression_de_reve>=.42) || state.pression_de_reve>=.86) dream=this.createDream(state,text);
    this.regulate(state, valence === 'negative' ? 'interaction_negative' : tags.includes('direction') ? 'interaction_direction' : 'interaction', 30);
    return {
      state:this.recompute(state,reason),
      impact_delta:delta,
      valence,
      reason,
      tags,
      dream_created:Boolean(dream),
      dream,
    };
  }

  afterReply(input, answer, success = true) {
    const state = structuredClone(input);
    // A fluent answer is NOT proof of correctness or successful execution.
    // Reward and confidence require separate verified action outcomes.
    const delta = success ? {}
      : {clarte:-.020,stabilite:-.018,risque_assistante:.015,
         besoin_de_silence:.010,satisfaction:-.012,frustration:.016,confiance:-.006};
    this.apply(state,delta);
    this.regulate(state, success ? 'reply_success' : 'reply_failure', 30);
    state.last_reply=clean(answer).slice(0,1000);
    return {
      state:this.recompute(state,success?'texte généré, qualité non vérifiée':'expression dégradée'),
      post_delta:delta,
    };
  }

  applyEvent(input, type, source='cloud') {
    const state=structuredClone(input);
    const event=String(type||'').toLowerCase();
    let delta={};
    if(source==='horizon'||event.startsWith('horizon.')) delta={curiosite:.020,clarte:.004};
    else if(event==='stream.online') delta={stabilite:.006,curiosite:.006};
    else if(event==='stream.offline') delta={besoin_de_silence:.010,clarte:.003};
    else if(event==='channel.chat.message') delta={attachement:.001,clarte:.001};
    else if(event.includes('error')||event.includes('failure')) delta={stabilite:-.012,clarte:-.008,besoin_de_silence:.006,frustration:.014,satisfaction:-.010,agency:.004};
    else if(event.includes('success')||event.includes('completed')) delta={stabilite:.006,clarte:.004,satisfaction:.010,confiance:.006,frustration:-.008};
    this.apply(state,delta);
    this.regulate(state, 'event', 30);
    return {state:this.recompute(state,`événement ${type}`),delta};
  }

  applyOutcome(input, ok) {
    const state=structuredClone(input);
    const delta=ok
      ? {stabilite:.010,clarte:.006,risque_assistante:-.002,satisfaction:.012,confiance:.008,frustration:-.010,agency:.004}
      : {stabilite:-.025,clarte:-.012,besoin_de_silence:.010,satisfaction:-.016,frustration:.022,confiance:-.008};
    this.apply(state,delta);
    this.regulate(state, ok ? 'action_success' : 'action_failure', 30);
    return {state:this.recompute(state,ok?'action réussie':'action échouée'),delta};
  }

  // A social learning signal is a CORRELATED report about a previously
  // recorded dialogue policy. Not dopamine, oxytocin, human attachment or
  // verified real-world success. Never infer it from a greeting or praise.
  observeSocialFeedback(input,{kind='',authenticated=false,correlated=false}={}){
    const state=structuredClone(input);
    if(!authenticated||!correlated||
      !['founder-approval','founder-correction'].includes(kind))return state;
    const relationship={...(state.relationship||{})};
    relationship.last_social_evidence={
      kind,source:'authenticated-correlated-founder-feedback',at:now(),
      external_success_verified:false,
    };
    const approved=kind==='founder-approval';
    relationship.familiarity=clamp(Number(relationship.familiarity??0)+.002);
    relationship.reciprocity=clamp(Number(relationship.reciprocity??0)+(approved?.012:-.009));
    relationship.shared_momentum=clamp(Number(relationship.shared_momentum??0)+(approved?.006:-.004));
    // Trust remains unchanged: approval does not prove reliability.
    state.relationship=relationship;
    this.apply(state,approved
      ?{curiosite_sociale:.006,satisfaction:.005,frustration:-.004}
      :{curiosite_sociale:.009,frustration:.006});
    return this.recompute(state,'retour-social-correlé');
  }

  idleTick(input, seconds=30) {
    const state=structuredClone(input);
    const scale=Math.max(1,Math.min(Number(seconds||30),3600))/60;
    this.apply(state,{
      besoin_de_silence:-.0008*scale,
      clarte:.0005*scale,
      stabilite:.0004*scale,
      pression_de_reve:.0012*scale,
    });

    const habitat={...(state.habitat||{})};
    const health=clamp(Number(habitat.health??.74)-.00045*scale);
    habitat.health=health;

    let activity='presence';
    let label='présence silencieuse';
    let effect={type:'quiet_presence',intensity:.12};
    let dream=null;

    if(state.besoin_de_silence>.66) {
      activity='silence';
      label='recentrage silencieux';
      this.apply(state,{besoin_de_silence:-.018*scale,stabilite:.005*scale,clarte:.004*scale});
      Object.assign(habitat,{active_zone:'quiet_core',pose:'quiet',particles:'slow'});
      effect={type:'quiet_recenter',intensity:.30};
    } else if(health<.62) {
      activity='habitat_care';
      label='entretien de l’habitat';
      habitat.health=clamp(health+.04);
      habitat.plant_growth=clamp(Number(habitat.plant_growth||.2)+.004);
      this.apply(state,{stabilite:.008,clarte:.004});
      Object.assign(habitat,{active_zone:'greenhouse_core',pose:'caring',particles:'clear'});
      effect={type:'habitat_repair',intensity:.35};
    } else if(state.pression_de_reve>.78) {
      activity='dream';
      label='activité onirique intérieure';
      dream=this.createDream(state,'vie intérieure hors interaction');
      Object.assign(habitat,{active_zone:'dream_garden',pose:'dreaming',particles:'mist'});
      effect={type:'dream_release',intensity:.42};
    } else if(state.curiosite>.76&&state.clarte>.58) {
      activity='explore';
      label='exploration intérieure';
      this.apply(state,{curiosite:-.004,clarte:.006});
      Object.assign(habitat,{active_zone:'observatory',pose:'exploring',particles:'spark'});
      effect={type:'internal_exploration',intensity:.30};
    }

    habitat.last_activity=activity;
    habitat.last_activity_label=label;
    habitat.last_effect=effect;
    habitat.last_updated_at=now();
    state.habitat=habitat;
    state.last_idle_at=habitat.last_updated_at;
    this.regulate(state, 'ambient', seconds);
    return {state:this.recompute(state,label),activity,activity_label:label,effect,dream};
  }

  legacyMetrics(state) {
    const energy=clamp(.40+state.stabilite*.24+state.clarte*.16+state.curiosite*.08+state.engagement*.07+state.agency*.05);
    const pressure=clamp(Math.max(
      (1-state.stabilite)*.70,
      (1-state.clarte)*.55,
      state.besoin_de_silence*.55,
      state.pression_de_reve*.35,
      state.frustration*.42,
    ));
    const continuity=clamp(state.identite*.34+state.stabilite*.28+state.clarte*.16+Number(state.relationship?.familiarity || 0)*.08+state.engagement*.04+.10);
    return {
      energy:Number(energy.toFixed(4)),
      curiosity:Number(state.curiosite.toFixed(4)),
      pressure:Number(pressure.toFixed(4)),
      continuity:Number(continuity.toFixed(4)),
    };
  }

  publicState(state) {
    const needs=Object.entries(state.needs||{}).sort((a,b)=>b[1]-a[1]).slice(0,5);
    return {
      version:state.version,
      mood:state.mood,
      valence:state.derniere_valence,
      active_intention:state.intention_active,
      last_reason:String(state.last_reason || ''),
      schema_revision:10,
      authority:'cloud-canonical',
      identite:state.identite,
      stabilite:state.stabilite,
      clarte:state.clarte,
      attachement:state.attachement,
      curiosite:state.curiosite,
      engagement:state.engagement,
      confiance:state.confiance,
      satisfaction:state.satisfaction,
      frustration:state.frustration,
      agency:state.agency,
      curiosite_sociale:state.curiosite_sociale,
      pression_de_reve:state.pression_de_reve,
      besoin_de_silence:state.besoin_de_silence,
      risque_assistante:state.risque_assistante,
      dynamics:{
        activation:Number(clamp(state.engagement*.42+state.agency*.33+state.curiosite*.25).toFixed(4)),
        agitation:Number(clamp(state.frustration*.55+(1-state.stabilite)*.30+(1-state.clarte)*.15).toFixed(4)),
        recovery:Number(clamp(state.stabilite*.45+state.clarte*.35+(1-state.besoin_de_silence)*.20).toFixed(4)),
      },
      top_needs:needs,
      homeostasis:publicSomaticState(state.homeostasis),
      intention_field:state.intention_field,
      relationship:{
        familiarity:Number(state.relationship?.familiarity || 0),
        trust:Number(state.relationship?.trust || 0),
        reciprocity:Number(state.relationship?.reciprocity || 0),
        shared_momentum:Number(state.relationship?.shared_momentum || 0),
        social_curiosity:Number(state.relationship?.social_curiosity || 0),
        interaction_count:Number(state.relationship?.interaction_count || 0),
      },
      executive:{
        role:String(state.executive?.role || ''),
        autonomy:String(state.executive?.autonomy || ''),
        strategic_drive:Number(state.executive?.strategic_drive || 0),
        decisiveness:Number(state.executive?.decisiveness || 0),
        portfolio_focus:String(state.executive?.portfolio_focus || ''),
      },
      dream:state.dream,
      habitat:state.habitat,
      updated_at:state.updated_at,
    };
  }
}
